package com.farmdiary.app

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.SaleLineEntity
import com.farmdiary.app.domain.Dashboard
import java.time.YearMonth
import org.junit.Assert.assertEquals
import org.junit.Test

class DashboardTest {
    private fun report(date: String, water: Double) = DailyReportEntity(
        date = date, trayQty = 10.0, trayRate = 20.0, labour = 500.0, light = 100.0,
        stoneQty = 2.0, stoneRate = 50.0, eggSell = 0.0, confirmed = true,
        confirmedFeedUsed = 0.0, openingFeed = 0.0, closingFeed = 0.0, createdAt = 0, updatedAt = 0,
        waterTanks = water
    )

    @Test fun monthlyTotalsAndDailyBars() {
        val m = YearMonth.of(2026, 10)
        val s = Dashboard.build(
            m,
            reports = listOf(report("2026-10-02", 2.0), report("2026-10-05", 1.0)),
            lines = listOf(
                FarmLineEntity(reportDate = "2026-10-02", position = 0, name = "A", feedBags = 10.0, feedRate = 100.0, trays = 40.0, mortality = 2),
                FarmLineEntity(reportDate = "2026-10-05", position = 0, name = "A", feedBags = 5.0, feedRate = 100.0, trays = 20.0, mortality = 1)
            ),
            extras = listOf(ExtraItemEntity(reportDate = "2026-10-02", position = 0, name = "Diesel", amount = 300.0)),
            sales = listOf(
                SaleLineEntity(reportDate = "2026-10-02", position = 0, name = "L", trays = 30.0, rate = 300.0),
                SaleLineEntity(reportDate = "2026-10-05", position = 0, name = "L", trays = 10.0, rate = 300.0)
            ),
            eggSales = listOf(
                EggSaleEntity("2026-10-02", cashReceived = 5000.0, onlineReceived = 2000.0, updatedAt = 0),
                EggSaleEntity("2026-10-05", cashReceived = 3000.0, onlineReceived = 0.0, updatedAt = 0)
            )
        )
        // each report: 200 + 500 + 100 + 100 = 900 fixed; feed 1000 and 500; extra 300
        assertEquals(31, s.days.size)
        assertEquals(900.0 + 1000.0 + 300.0, s.days[1].expenditure, 0.001)
        assertEquals(900.0 + 500.0, s.days[4].expenditure, 0.001)
        assertEquals(9000.0, s.days[1].income, 0.001)
        assertEquals(12000.0, s.income, 0.001)
        assertEquals(3600.0, s.expenditure, 0.001)
        assertEquals(8400.0, s.profit, 0.001)
        assertEquals(2000.0, s.balanceToReceive, 0.001)
        assertEquals(60.0, s.traysProduced, 0.001)
        assertEquals(40.0, s.traysSold, 0.001)
        assertEquals(3, s.birdsDied)
        assertEquals(3.0, s.waterTanks, 0.001)
    }

    @Test fun saleWithoutReportStillCountsAsIncome() {
        val m = YearMonth.of(2026, 10)
        val s = Dashboard.build(
            m, reports = emptyList(), lines = emptyList(), extras = emptyList(),
            sales = listOf(SaleLineEntity(reportDate = "2026-10-09", position = 0, name = "L", trays = 5.0, rate = 200.0)),
            eggSales = emptyList()
        )
        assertEquals(1000.0, s.income, 0.001)
        assertEquals(1000.0, s.days[8].income, 0.001)
    }
}
