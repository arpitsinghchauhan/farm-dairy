package com.farmdiary.app

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.SaleLineEntity
import com.farmdiary.app.domain.Dashboard
import java.time.YearMonth
import org.junit.Assert.assertEquals
import org.junit.Test

class DashboardTest {
    private fun report(date: String, sale: Double, cash: Double, online: Double) = DailyReportEntity(
        date = date, trayQty = 10.0, trayRate = 20.0, labour = 500.0, light = 100.0,
        stoneQty = 2.0, stoneRate = 50.0, eggSell = sale, confirmed = true,
        confirmedFeedUsed = 0.0, openingFeed = 0.0, closingFeed = 0.0, createdAt = 0, updatedAt = 0,
        cashReceived = cash, onlineReceived = online
    )

    @Test fun monthlyTotalsAndDailyBars() {
        val m = YearMonth.of(2026, 10)
        val s = Dashboard.build(
            m,
            reports = listOf(report("2026-10-02", 9000.0, 5000.0, 2000.0), report("2026-10-05", 3000.0, 3000.0, 0.0)),
            lines = listOf(
                FarmLineEntity(reportDate = "2026-10-02", position = 0, name = "A", feedBags = 10.0, feedRate = 100.0, trays = 40.0),
                FarmLineEntity(reportDate = "2026-10-05", position = 0, name = "A", feedBags = 5.0, feedRate = 100.0, trays = 20.0)
            ),
            extras = listOf(ExtraItemEntity(reportDate = "2026-10-02", position = 0, name = "Diesel", amount = 300.0)),
            sales = listOf(SaleLineEntity(reportDate = "2026-10-02", position = 0, name = "L", trays = 30.0, rate = 300.0))
        )
        // each report: 200 + 500 + 100 + 100 = 900 fixed; feed 1000 and 500; extra 300
        assertEquals(31, s.days.size)
        assertEquals(900.0 + 1000.0 + 300.0, s.days[1].expenditure, 0.001)
        assertEquals(900.0 + 500.0, s.days[4].expenditure, 0.001)
        assertEquals(12000.0, s.income, 0.001)
        assertEquals(3600.0, s.expenditure, 0.001)
        assertEquals(8400.0, s.profit, 0.001)
        assertEquals(2000.0, s.balanceToReceive, 0.001)
        assertEquals(60.0, s.traysProduced, 0.001)
        assertEquals(30.0, s.traysSold, 0.001)
    }
}
