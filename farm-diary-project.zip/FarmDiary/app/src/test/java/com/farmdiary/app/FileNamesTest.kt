package com.farmdiary.app

import com.farmdiary.app.domain.FileNames
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class FileNamesTest {
    private val day = LocalDate.of(2026, 10, 17)

    @Test fun farmNameAndDate() {
        assertEquals("Green_Valley_Farm_17-Oct-2026.pdf", FileNames.pdf("Green Valley Farm", day))
    }

    @Test fun suffixGoesBeforeTheDate() {
        assertEquals("Sharma_Poultry_EggSale_17-Oct-2026.pdf", FileNames.pdf("Sharma Poultry", day, "EggSale"))
    }

    @Test fun unsafeCharactersAreRemoved() {
        assertEquals("A_B_Farm_17-Oct-2026.pdf", FileNames.pdf("  A/B: *Farm*  ", day))
    }

    @Test fun blankNameFallsBack() {
        assertEquals("Farm_Diary_17-Oct-2026.pdf", FileNames.pdf("   ", day))
        assertEquals("Farm_Diary_FeedReport_17-Oct-2026.pdf", FileNames.pdf("///", day, "FeedReport"))
    }

    @Test fun hindiNamesKeepTheirLetters() {
        assertEquals("हरि_फार्म_17-Oct-2026.pdf", FileNames.pdf("हरि फार्म", day))
    }

    @Test fun longNamesAreShortened() {
        val name = FileNames.pdf("A".repeat(100), day)
        assertEquals(40 + "_17-Oct-2026.pdf".length, name.length)
    }
}
