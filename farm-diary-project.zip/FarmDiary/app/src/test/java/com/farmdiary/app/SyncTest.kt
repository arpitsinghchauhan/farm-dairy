package com.farmdiary.app

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.data.SaleLineEntity
import com.farmdiary.app.sync.Counts
import com.farmdiary.app.sync.MergeAction
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import com.farmdiary.app.sync.SyncFormatException
import com.farmdiary.app.sync.SyncMerge
import com.farmdiary.app.sync.SyncSummary
import com.farmdiary.app.sync.MergeResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncTest {
    private fun sample() = SyncData(
        farmName = "Green Valley हरि Farm",
        exportedAt = 1_760_000_000_000L,
        reports = listOf(
            DailyReportEntity(
                date = "2026-10-12", trayQty = 1500.0, trayRate = 4.5, labour = 500.0, light = 120.5,
                stoneQty = 2.0, stoneRate = 50.0, eggSell = 9000.0, cashReceived = 5000.0, onlineReceived = 2000.0,
                waterTanks = 2.5, confirmedTrayUsed = 1500.0, openingTrays = 3000.0, closingTrays = 1500.0,
                confirmed = true, confirmedFeedUsed = 50.0, openingFeed = 100.0, closingFeed = 50.0,
                createdAt = 10, updatedAt = 20
            )
        ),
        lines = listOf(
            FarmLineEntity(reportDate = "2026-10-12", position = 0, name = "S.No. 1", feedBags = 24.0, feedRate = 1665.0, trays = 40.5, mortality = 2),
            FarmLineEntity(reportDate = "2026-10-12", position = 1, name = "S.No. \"2\"", feedBags = 26.0, feedRate = 1665.0, trays = 38.0, mortality = 0)
        ),
        extras = listOf(ExtraItemEntity(reportDate = "2026-10-12", position = 0, name = "Diesel", amount = 300.0)),
        eggSales = listOf(
            EggSaleEntity("2026-10-12", 5000.0, 2000.0, 30, previousBalance = 1500.0, advancePaid = 250.0, closingBalance = 2250.0)
        ),
        saleLines = listOf(
            SaleLineEntity(reportDate = "2026-10-12", position = 0, name = "Large", trays = 30.0, rate = 300.0, revisedRate = 310.0)
        ),
        feedTxns = listOf(
            FeedTxnEntity("11111111-aaaa", "2026-10-10", "BUY", 50.0, 1665.0, 20.0, 82250.0, "Bill 12\nSharma", false, 5, 6),
            FeedTxnEntity("22222222-bbbb", "2026-10-11", "CASH", 0.0, 0.0, 0.0, 10000.0, "", true, 7, 8),
            FeedTxnEntity("33333333-cccc", "2026-09-01", "OPENING", 0.0, 0.0, 0.0, 120000.0, "Old bills", false, 1, 1)
        ),
        stock = FarmStockEntity(1, 150.5, 3000, 12, 99)
    )

    @Test fun roundTripKeepsEverything() {
        val original = sample()
        val back = SyncCodec.fromJson(SyncCodec.toJson(original))
        assertEquals(original, back)
    }

    @Test fun missingStockStaysMissing() {
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample().copy(stock = null)))
        assertEquals(null, back.stock)
    }

    @Test fun deletedFeedEntriesTravelButAreNotCounted() {
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample()))
        assertEquals(3, back.feedTxns.size)
        assertEquals(2, back.feedEntryCount)
    }

    @Test fun notAFarmDiaryFileIsRejected() {
        var failed = false
        try { SyncCodec.fromJson("{\"hello\": 1}") } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
        failed = false
        try { SyncCodec.fromJson("this is not json at all") } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun newerFormatIsRejected() {
        var failed = false
        try { SyncCodec.fromJson("{\"app\":\"FarmDiary\",\"format\":99}") } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun badDateIsRejected() {
        val json = SyncCodec.toJson(sample()).replace("2026-10-12", "12/10/2026")
        var failed = false
        try { SyncCodec.fromJson(json) } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun unknownFeedTypeIsRejected() {
        val json = SyncCodec.toJson(sample()).replace("\"BUY\"", "\"STEAL\"")
        var failed = false
        try { SyncCodec.fromJson(json) } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun oldFileWithFewerFieldsStillLoads() {
        val json = "{\"app\":\"FarmDiary\",\"format\":1,\"eggSales\":[{\"date\":\"2026-10-01\",\"updatedAt\":5}]}"
        val d = SyncCodec.fromJson(json)
        assertEquals(1, d.eggSales.size)
        assertEquals(0.0, d.eggSales[0].advancePaid, 0.0)
        assertEquals("", d.farmName)
    }

    @Test fun newerVersionWins() {
        assertEquals(MergeAction.ADD, SyncMerge.decide(5, null))
        assertEquals(MergeAction.UPDATE, SyncMerge.decide(6, 5))
        assertEquals(MergeAction.KEEP, SyncMerge.decide(5, 5))
        assertEquals(MergeAction.KEEP, SyncMerge.decide(4, 5))
    }

    @Test fun countsAddUp() {
        val c = Counts().with(MergeAction.ADD).with(MergeAction.ADD).with(MergeAction.UPDATE).with(MergeAction.KEEP)
        assertEquals(2, c.added); assertEquals(1, c.updated); assertEquals(1, c.kept); assertEquals(3, c.changed)
        assertFalse(Counts().changed > 0)
    }

    @Test fun previewMentionsFarmAndCounts() {
        val t = SyncSummary.preview(sample(), java.time.ZoneOffset.UTC)
        assertTrue(t.contains("From: "))
        assertTrue(t.contains("daily reports"))
    }

    @Test fun describeSaysWhenStockKept() {
        val r = MergeResult(Counts(1, 2, 3), Counts(), Counts(), false, null)
        val lines = SyncSummary.describe(r)
        assertTrue(lines[0].contains("1 added, 2 updated, 3 kept"))
        assertTrue(lines[1].contains("none in the file"))
        assertTrue(lines.last().contains("kept yours"))
    }
}
