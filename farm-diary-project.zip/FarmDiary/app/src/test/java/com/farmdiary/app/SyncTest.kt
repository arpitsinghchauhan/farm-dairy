package com.farmdiary.app

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.data.ScheduleItemEntity
import com.farmdiary.app.data.SaleLineEntity
import com.farmdiary.app.sync.Counts
import com.farmdiary.app.sync.SyncDelta
import com.farmdiary.app.sync.MergeAction
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import com.farmdiary.app.sync.SyncFormatException
import com.farmdiary.app.sync.SyncMerge
import com.farmdiary.app.sync.SyncSummary
import com.farmdiary.app.sync.MergeResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncTest {
    private fun sample() = SyncData(
        farmName = "Green Valley हरि Farm",
        exportedAt = 1_760_000_000_000L,
        reports = listOf(
            DailyReportEntity(
                date = "2026-10-12", trayQty = 1500.0, trayRate = 4.5, labour = 500.0, light = 120.5,
                stoneQty = 2.0, stoneRate = 50.0, eggSell = 9000.0, cashReceived = 5000.0, onlineReceived = 2000.0,
                waterTanks = 2.5, confirmedTrayUsed = 1500.0, openingTrays = 3000.0, closingTrays = 1500.0,
                confirmed = true, confirmedFeedUsed = 50.0, openingFeed = 100.0, closingFeed = 50.0, closingEggTrays = 7,
                createdAt = 10, updatedAt = 20
            )
        ),
        lines = listOf(
            FarmLineEntity(reportDate = "2026-10-12", position = 0, name = "S.No. 1", feedBags = 24.0, feedRate = 1665.0, trays = 40.5, mortality = 2),
            FarmLineEntity(reportDate = "2026-10-12", position = 1, name = "S.No. \"2\"", feedBags = 26.0, feedRate = 1665.0, trays = 38.0, mortality = 0)
        ),
        extras = listOf(ExtraItemEntity(reportDate = "2026-10-12", position = 0, name = "Diesel", amount = 300.0)),
        eggSales = listOf(
            EggSaleEntity("2026-10-12", 5000.0, 2000.0, 30, previousBalance = 1500.0, advancePaid = 250.0, closingBalance = 2250.0, buyer = "Ravi")
        ),
        saleLines = listOf(
            SaleLineEntity(reportDate = "2026-10-12", position = 0, name = "Large", trays = 30.0, rate = 10.0, revisedRate = 0.5, subsidy = 0.25, buyer = "Ravi")
        ),
        feedTxns = listOf(
            FeedTxnEntity("11111111-aaaa", "2026-10-10", "BUY", 50.0, 1665.0, 20.0, 82250.0, "Bill 12\nSharma", false, 5, 6),
            FeedTxnEntity("22222222-bbbb", "2026-10-11", "CASH", 0.0, 0.0, 0.0, 10000.0, "", true, 7, 8),
            FeedTxnEntity("33333333-cccc", "2026-09-01", "OPENING", 0.0, 0.0, 0.0, 120000.0, "Old bills", false, 1, 1)
        ),
        attendance = listOf(com.farmdiary.app.data.EmployeeAttendanceEntity("e1|2026-10-12", "e1", "2026-10-12", "HALF", false, 5)),
        illnesses = listOf(com.farmdiary.app.data.IllnessEntity("i1", "2026-10-12", "Cold", 245, "S.No. 1", "Dr. Rao", "Tylosin\t0.5 ml", false, 1, 2)),
        stock = FarmStockEntity(1, 150.5, 3000, 12, 99),
        birdRecords = listOf(
            BirdRecordEntity(0, "2026-10-12", 0, "Shed A", 245, 112.5, 24.0, 2.0, 40.5, 3, 12, 2.5, "Vitamin\nCalcium", "Rain \"today\"", 55),
            BirdRecordEntity(0, "2026-10-12", 1, "Shed B", 120, 95.0, 10.0, 1.0, 20.0, 0, 4, 1.0, "", "", 55)
        )
    )

    @Test fun roundTripKeepsEverything() {
        val original = sample()
        val back = SyncCodec.fromJson(SyncCodec.toJson(original))
        assertEquals(original, back)
    }

    @Test fun dataSplitsIntoMonths() {
        val d = sample()
        val months = com.farmdiary.app.sync.SyncMonths.monthsOf(d)
        assertEquals(listOf("2026-09", "2026-10"), months)
        val oct = com.farmdiary.app.sync.SyncMonths.forMonth(d, "2026-10")
        assertEquals(1, oct.reports.size)
        assertEquals(2, oct.lines.size)
        assertEquals(2, oct.feedTxns.size)
        assertEquals(2, oct.birdRecords.size)
        val sep = com.farmdiary.app.sync.SyncMonths.forMonth(d, "2026-09")
        assertEquals(0, sep.reports.size)
        assertEquals(1, sep.feedTxns.size)
        assertEquals(d.stock, sep.stock)
    }

    @Test fun deltaHoldsOnlyWhatChanged() {
        val d = sample()
        val all = com.farmdiary.app.sync.SyncDelta.since(d, 0L)
        assertEquals(1, all.reports.size)
        assertEquals(2, all.lines.size)
        val later = com.farmdiary.app.sync.SyncDelta.since(d, 1000L)
        assertTrue(com.farmdiary.app.sync.SyncDelta.isEmpty(later))
        assertEquals(0, later.lines.size)
        val one = com.farmdiary.app.sync.SyncDelta.since(d, 20L)
        assertEquals(1, one.reports.size)
        assertEquals(0, one.feedTxns.size)
        assertEquals("", one.farmName)
        assertEquals(0L, one.scheduleUpdatedAt)
    }

    @Test fun liveConfigIsCheckedAndRoundTrips() {
        val code = com.farmdiary.app.sync.LiveConfig.newCode()
        assertEquals(24, code.length)
        val c = com.farmdiary.app.sync.LiveConfig("layer-diary-1a2b3", "AIzaSyA1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6Q", code)
        assertEquals(c, com.farmdiary.app.sync.LiveConfig.parse(c.encode()))
        assertEquals(null, com.farmdiary.app.sync.LiveConfig.parse("LD1|x|y|z"))
        assertEquals(null, com.farmdiary.app.sync.LiveConfig.parse("hello"))
        assertTrue(com.farmdiary.app.sync.LiveConfig.problems("Bad Name", "short").size == 2)
    }

    @Test fun firestoreJsonCarriesAPieceBothWays() {
        val body = com.farmdiary.app.sync.FirestoreJson.commitBody("proj-1", "abc", "doc1", "dev1", "{\"a\":1}")
        assertTrue(body.contains("REQUEST_TIME"))
        assertTrue(body.contains("farms/abc/changes/doc1"))
        val answer = """[{"document":{"name":"projects/p/databases/(default)/documents/farms/abc/changes/doc1",
            "fields":{"deviceId":{"stringValue":"dev1"},"payload":{"stringValue":"{\"a\":1}"},"ts":{"timestampValue":"2026-10-28T10:15:30.123456Z"}}},"readTime":"x"},
            {"readTime":"y"}]"""
        val got = com.farmdiary.app.sync.FirestoreJson.parseQuery(answer)
        assertEquals(1, got.size)
        assertEquals("dev1", got[0].deviceId)
        assertEquals("{\"a\":1}", got[0].payload)
        assertEquals("2026-10-28T10:15:30.123456Z", got[0].ts)
        val t = com.farmdiary.app.sync.FirestoreJson.parseToken("""{"idToken":"i","refreshToken":"r","expiresIn":"3600"}""")
        assertEquals("i", t?.first)
        assertEquals(3600L, t?.third)
    }

    @Test fun inviteAndAccountRules() {
        val id = com.farmdiary.app.sync.FarmInvite.newFarmId()
        val inv = com.farmdiary.app.sync.FarmInvite(id, com.farmdiary.app.sync.FarmInvite.newSecret())
        assertEquals(inv, com.farmdiary.app.sync.FarmInvite.parse(" " + inv.encode() + " "))
        assertEquals(null, com.farmdiary.app.sync.FarmInvite.parse("LDF-bad"))
        assertEquals(null, com.farmdiary.app.sync.FarmInvite.parse("LD1|a|b|c"))
        assertTrue(com.farmdiary.app.sync.AccountRules.validate("a@b.co", "secret1").isEmpty())
        assertEquals(2, com.farmdiary.app.sync.AccountRules.validate("nope", "123").size)
        assertTrue(com.farmdiary.app.sync.AccountRules.validFarmName("Sadhana Poultry Farm"))
    }

    @Test fun firestoreDocumentsAreWrittenAndRead() {
        val body = com.farmdiary.app.sync.FirestoreJson.commitDocBody(
            "p1", "farms/f1/members/u1", mapOf("role" to "owner", "email" to "a@b.co"), listOf("createdAt"), true
        )
        assertTrue(body.contains("farms/f1/members/u1"))
        assertTrue(body.contains("\"exists\":false"))
        val doc = """{"name":"x/farms/f1","fields":{"name":{"stringValue":"Green"},"n":{"integerValue":"3"}}}"""
        val m = com.farmdiary.app.sync.FirestoreJson.parseDocStrings(doc)
        assertEquals("Green", m["name"])
        assertEquals(null, m["n"])
        val list = """{"documents":[{"name":"x/members/u1","fields":{"email":{"stringValue":"a@b.co"},"role":{"stringValue":"owner"}}},
            {"name":"x/members/u2","fields":{"email":{"stringValue":"c@d.co"}}}]}"""
        val got = com.farmdiary.app.sync.FirestoreJson.parseDocList(list)
        assertEquals(listOf("u1", "u2"), got.map { it.first })
        assertEquals("owner", got[0].second["role"])
        assertEquals("u9", com.farmdiary.app.sync.FirestoreJson.parseUid("""{"localId":"u9"}"""))
        assertEquals("u8", com.farmdiary.app.sync.FirestoreJson.parseUid("""{"user_id":"u8"}"""))
    }

    @Test fun missingStockStaysMissing() {
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample().copy(stock = null)))
        assertEquals(null, back.stock)
    }

    @Test fun deletedFeedEntriesTravelButAreNotCounted() {
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample()))
        assertEquals(3, back.feedTxns.size)
        assertEquals(1, back.birdDayCount)
        assertEquals(2, back.feedEntryCount)
    }

    @Test fun notAFarmDiaryFileIsRejected() {
        var failed = false
        try { SyncCodec.fromJson("{\"hello\": 1}") } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
        failed = false
        try { SyncCodec.fromJson("this is not json at all") } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun newerFormatIsRejected() {
        var failed = false
        try { SyncCodec.fromJson("{\"app\":\"FarmDiary\",\"format\":99}") } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun badDateIsRejected() {
        val json = SyncCodec.toJson(sample()).replace("2026-10-12", "12/10/2026")
        var failed = false
        try { SyncCodec.fromJson(json) } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun unknownFeedTypeIsRejected() {
        val json = SyncCodec.toJson(sample()).replace("\"BUY\"", "\"STEAL\"")
        var failed = false
        try { SyncCodec.fromJson(json) } catch (e: SyncFormatException) { failed = true }
        assertTrue(failed)
    }

    @Test fun oldFileWithFewerFieldsStillLoads() {
        val json = "{\"app\":\"FarmDiary\",\"format\":1,\"eggSales\":[{\"date\":\"2026-10-01\",\"updatedAt\":5}]}"
        val d = SyncCodec.fromJson(json)
        assertEquals(1, d.eggSales.size)
        assertEquals(0.0, d.eggSales[0].advancePaid, 0.0)
        assertEquals("", d.farmName)
    }

    @Test fun newerVersionWins() {
        assertEquals(MergeAction.ADD, SyncMerge.decide(5, null))
        assertEquals(MergeAction.UPDATE, SyncMerge.decide(6, 5))
        assertEquals(MergeAction.KEEP, SyncMerge.decide(5, 5))
        assertEquals(MergeAction.KEEP, SyncMerge.decide(4, 5))
    }

    @Test fun countsAddUp() {
        val c = Counts().with(MergeAction.ADD).with(MergeAction.ADD).with(MergeAction.UPDATE).with(MergeAction.KEEP)
        assertEquals(2, c.added); assertEquals(1, c.updated); assertEquals(1, c.kept); assertEquals(3, c.changed)
        assertFalse(Counts().changed > 0)
    }

    @Test fun previewMentionsFarmAndCounts() {
        val t = SyncSummary.preview(sample(), java.time.ZoneOffset.UTC)
        assertTrue(t.contains("From: "))
        assertTrue(t.contains("daily reports"))
    }

    @Test fun describeSaysWhenStockKept() {
        val r = MergeResult(Counts(1, 2, 3), Counts(), Counts(), false, null)
        val lines = SyncSummary.describe(r)
        assertTrue(lines[0].contains("1 added, 2 updated, 3 kept"))
        assertTrue(lines[1].contains("none in the file"))
        assertTrue(lines.last().contains("kept yours"))
    }

    @Test fun saleLinesKeepTheirBuyerAndOldFilesTakeTheDaysBuyer() {
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample()))
        assertEquals("Ravi", back.saleLines[0].buyer)
        val old = "{\"app\":\"FarmDiary\",\"format\":3,\"eggSales\":[{\"date\":\"2026-10-01\",\"updatedAt\":5,\"buyer\":\"Amit\"}]," +
            "\"saleLines\":[{\"reportDate\":\"2026-10-01\",\"position\":0,\"name\":\"L\",\"trays\":1,\"rate\":5}]}"
        assertEquals("Amit", SyncCodec.fromJson(old).saleLines[0].buyer)
    }

    @Test fun deltaKeepsOnlyTheLinesOfTheChangedBuyer() {
        val d = sample().copy(
            eggSales = listOf(
                EggSaleEntity("2026-10-12", 0.0, 0.0, 100, buyer = "Ravi"),
                EggSaleEntity("2026-10-12", 0.0, 0.0, 1, buyer = "Amit")
            ),
            saleLines = listOf(
                SaleLineEntity(reportDate = "2026-10-12", position = 0, name = "L", trays = 1.0, rate = 5.0, buyer = "Ravi"),
                SaleLineEntity(reportDate = "2026-10-12", position = 0, name = "L", trays = 2.0, rate = 5.0, buyer = "Amit")
            )
        )
        val part = SyncDelta.since(d, 50)
        assertEquals(1, part.eggSales.size)
        assertEquals(listOf("Ravi"), part.saleLines.map { it.buyer })
    }

    @Test fun oldFormatPricePerTrayIsConvertedToPerEgg() {
        val json = SyncCodec.toJson(sample().copy(feedTxns = emptyList()))
            .replace("\"format\":3", "\"format\":1")
        val back = SyncCodec.fromJson(json)
        // The file said 10 per ... and, as a format-1 file, that was a price per tray: 10 / 30 per egg.
        assertEquals(10.0 / 30.0, back.saleLines[0].rate, 0.000001)
        // format 1 stored the new price per tray (0.5); it becomes a cut per egg: (10 - 0.5) / 30
        assertEquals((10.0 - 0.5) / 30.0, back.saleLines[0].revisedRate, 0.000001)
    }

    @Test fun format2RevisedPriceBecomesAPriceCut() {
        val json = SyncCodec.toJson(sample().copy(feedTxns = emptyList()))
            .replace("\"format\":3", "\"format\":2")
        val back = SyncCodec.fromJson(json)
        assertEquals(10.0, back.saleLines[0].rate, 0.000001)
        assertEquals(9.5, back.saleLines[0].revisedRate, 0.000001)
    }

    @Test fun medicineEntriesKeepCategoryAndNameInTheFile() {
        val med = FeedTxnEntity("m1", "2026-10-12", "BUY", 3.0, 120.0, 10.0, 330.0, "", false, 1, 2, "MEDICINE", "Vitamin")
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample().copy(feedTxns = listOf(med))))
        assertEquals("MEDICINE", back.feedTxns[0].category)
        assertEquals("Vitamin", back.feedTxns[0].item)
    }

    @Test fun oldFileWithoutFarmRecordsStillLoads() {
        val json = SyncCodec.toJson(sample().copy(birdRecords = emptyList()))
            .replace("\"birdRecords\":[],", "")
        val back = SyncCodec.fromJson(json)
        assertTrue(back.birdRecords.isEmpty())
    }

    @Test fun farmRecordCountsAreShown() {
        val r = MergeResult(Counts(), Counts(), Counts(), false, null, Counts(2, 1, 0))
        assertTrue(r.anythingChanged)
        assertTrue(SyncSummary.describe(r).any { it.startsWith("Farm records") && it.contains("2 added") })
    }

    @Test fun savedScheduleTravelsInTheFile() {
        val tasks = listOf(
            ScheduleItemEntity(1, "Feed time", "All farms", 7, 0, true),
            ScheduleItemEntity(2, "Vaccination", "Lasota", 9, 30, true, "WEEKLY", 6, 1),
            ScheduleItemEntity(3, "Pay salary", "", 18, 0, false, "MONTHLY", 1, 31)
        )
        val back = SyncCodec.fromJson(SyncCodec.toJson(sample().copy(schedule = tasks, scheduleUpdatedAt = 5000L)))
        assertEquals(5000L, back.scheduleUpdatedAt)
        assertEquals(3, back.schedule.size)
        assertEquals("WEEKLY", back.schedule[1].kind)
        assertEquals(6, back.schedule[1].dayOfWeek)
        assertEquals(31, back.schedule[2].dayOfMonth)
        assertEquals(true, back.schedule[0].reminderOn)
        assertTrue(SyncSummary.preview(back).contains("3 scheduled tasks"))
    }

    @Test fun fileWithoutScheduleDoesNotTouchTheScheduler() {
        val json = SyncCodec.toJson(sample())
            .replace("\"schedule\":[]", "\"x\":[]")
        val back = SyncCodec.fromJson(json)
        assertEquals(0L, back.scheduleUpdatedAt.coerceAtMost(0L))
        assertTrue(back.schedule.isEmpty())
    }
}
