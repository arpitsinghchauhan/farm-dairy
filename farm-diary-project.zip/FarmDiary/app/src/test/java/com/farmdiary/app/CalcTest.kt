package com.farmdiary.app

import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.domain.ReportForm
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalcTest {
    private fun form(vararg bags: String) = ReportForm(
        date = LocalDate.of(2026, 10, 3),
        lines = bags.mapIndexed { i, b -> FarmLineForm(i.toLong(), "S.No. ${i + 1}", feedBags = b, feedRate = "1665") },
        trayQty = "10", trayRate = "20", labour = "500", light = "100", stoneQty = "2", stoneRate = "50", eggSell = "9000"
    )

    @Test fun totalsAreCalculated() {
        val f = form("25", "0")
        assertEquals(25 * 1665.0 + 200 + 500 + 100 + 100, f.totalExpenditure, 0.001)
        assertEquals(9000.0, f.totalIncome, 0.001)
    }

    @Test fun feedUsageWithinStockIsValid() {
        assertTrue(Calc.validate(form("24", "26"), availableFeed = 100.0).isEmpty())
    }

    @Test fun feedUsageOverStockIsRejected() {
        assertTrue(Calc.validate(form("60", "50"), availableFeed = 100.0).isNotEmpty())
    }

    @Test fun eggTrayConversion() {
        assertEquals(1.0, Calc.eggsToTrays(30.0), 0.0001)
        assertTrue(Calc.isInvalid("-1"))
        assertTrue(Calc.isInvalid("1.2.3"))
    }
}
