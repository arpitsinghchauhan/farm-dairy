package com.farmdiary.app

import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.domain.ReportForm
import com.farmdiary.app.domain.SaleLineForm
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CalcTest {
    private fun form(vararg bags: String) = ReportForm(
        date = LocalDate.of(2026, 10, 3),
        lines = bags.mapIndexed { i, b -> FarmLineForm(i.toLong(), "S.No. ${i + 1}", feedBags = b, feedRate = "1665") },
        trayQty = "10", trayRate = "20", labour = "500", light = "100", stoneQty = "2", stoneRate = "50", sales = listOf(SaleLineForm(100, "Large", "30", "10"))
    )

    @Test fun totalsAreCalculated() {
        val f = form("25", "0")
        assertEquals(25 * 1665.0 + 200 + 500 + 100 + 100, f.totalExpenditure, 0.001)
        assertEquals(9000.0, f.totalIncome, 0.001)
    }

    @Test fun extraItemsAreAddedToTotal() {
        val base = form("0")
        val withExtra = base.copy(
            extras = listOf(
                com.farmdiary.app.domain.ExtraItemForm(1, "Diesel", "300"),
                com.farmdiary.app.domain.ExtraItemForm(2, "Repair", "150.5")
            )
        )
        assertEquals(base.totalExpenditure + 450.5, withExtra.totalExpenditure, 0.001)
    }

    @Test fun productionIsEnteredInTrays() {
        val f = form("0", "0").let {
            it.copy(lines = it.lines.mapIndexed { i, l -> l.copy(trays = if (i == 0) "12" else "8.5") })
        }
        assertEquals(20.5, f.totalTrays, 0.001)
    }

    @Test fun saleLinesAndBalanceUseRevisedRate() {
        val f = form("0").copy(
            sales = listOf(
                SaleLineForm(1, "Large", "30", "10"),
                SaleLineForm(2, "Small", "10", "8", revisedRate = "1")
            ),
            cashReceived = "5000", onlineReceived = "2000",
            previousBalance = "1500", advancePaid = "500"
        )
        // 30 trays x 30 eggs x 10 + 10 trays x 30 eggs x (8 - 1 cut) = 11100 ; balance = 1500 + 11100 - 500 - 5000 - 2000 = 5100
        assertEquals(11100.0, f.totalIncome, 0.001)
        assertEquals(40.0, f.totalTraysSold, 0.001)
        assertEquals(5100.0, f.balance, 0.001)
    }

    @Test fun payingMoreThanDueBecomesAdvanceNotAnError() {
        val f = form("0").copy(cashReceived = "20000", onlineReceived = "1")
        assertTrue(Calc.validate(f, availableFeed = 100.0).isEmpty())
        assertTrue(f.balance < 0)
    }

    @Test fun trayUsageIsCheckedAgainstBundles() {
        val f = form("0").copy(trayQty = "1500")
        assertEquals(15.0, Calc.bundles(f.trayUsed), 0.0001)
        // 20 bundles = 2000 trays in stock: fine. 10 bundles = 1000 trays: not enough.
        assertTrue(Calc.validate(f, availableFeed = 100.0, availableTrays = 2000.0).isEmpty())
        assertTrue(Calc.validate(f, availableFeed = 100.0, availableTrays = 1000.0).isNotEmpty())
    }

    @Test fun mortalityIsAddedUp() {
        val f = form("0", "0").let {
            it.copy(lines = it.lines.mapIndexed { i, l -> l.copy(mortality = if (i == 0) "3" else "2") })
        }
        assertEquals(5.0, f.totalMortality, 0.001)
    }

    @Test fun eggPriceIsPerEggAndTrayHas30Eggs() {
        // 5.2 per egg x 30 eggs = 156 per tray; 10 trays = 1560
        val line = SaleLineForm(1, "Large", "10", "5.2")
        assertEquals(156.0, line.pricePerTray, 0.0001)
        assertEquals(1560.0, line.amount, 0.0001)
        val revised = line.copy(revisedRate = "0.2") // 5.2 - 0.2 = 5.0 per egg
        assertEquals(5.0, revised.effectiveRate, 0.0001)
        assertEquals(1500.0, revised.amount, 0.0001)
    }

    @Test fun stockIsKeptDateWise() {
        // Yesterday: 238 bags in stock, 40 used -> 198 left. Today 200 bags are added -> 398 now.
        val yesterday = form("40").copy(
            confirmed = true, confirmedFeedUsed = 40.0, confirmedOpening = 238.0, confirmedClosing = 198.0,
            confirmedTrayOpening = 5000.0, confirmedTrayClosing = 5000.0
        )
        // Nothing changes for yesterday's report, whatever the stock is now.
        assertEquals(198.0, yesterday.feedBase(398.0) - yesterday.feedUsed, 0.001)
        // Editing yesterday: 40 -> 45 bags. Yesterday's closing is 193, stock now loses only the 5 extra bags.
        val edited = yesterday.copy(lines = yesterday.lines.map { it.copy(feedBags = "45") })
        val plan = Calc.planConfirm(edited, 398.0, 5000)
        assertTrue(plan.problems.isEmpty())
        assertEquals(193.0, plan.feedLeft, 0.001)
        assertEquals(393.0, plan.newFeed, 0.001)
    }

    @Test fun firstConfirmUsesStockNow() {
        val plan = Calc.planConfirm(form("40"), 238.0, 5000)
        assertTrue(plan.problems.isEmpty())
        assertEquals(198.0, plan.feedLeft, 0.001)
        assertEquals(198.0, plan.newFeed, 0.001)
    }

    @Test fun editingAnOldReportCannotTakeMoreThanItsDayHadOrWhatIsLeft() {
        // On that day only 238 bags existed, so 300 cannot be used even though 400 are in stock now.
        val old = form("40").copy(confirmedFeedUsed = 40.0, confirmedOpening = 238.0, confirmedClosing = 198.0, confirmed = true)
        val tooMuch = old.copy(lines = old.lines.map { it.copy(feedBags = "300") })
        assertTrue(Calc.planConfirm(tooMuch, 400.0, 5000).problems.isNotEmpty())
        // Stock now is only 2 bags, so 5 more bags cannot be taken out of it.
        val more = old.copy(lines = old.lines.map { it.copy(feedBags = "45") })
        assertTrue(Calc.planConfirm(more, 2.0, 5000).problems.isNotEmpty())
    }

    @Test fun eggStockOfAReportIsOnlyShownWhenRecorded() {
        assertEquals(12, form("0").eggStock(12))
        val old = form("10").copy(confirmed = true, confirmedFeedUsed = 10.0, confirmedOpening = 50.0, confirmedClosing = 40.0)
        assertEquals(null, old.eggStock(99))
        assertEquals(7, old.copy(confirmedEggTrays = 7).eggStock(99))
    }

    @Test fun eggSaleFormTotalsAndNil() {
        val empty = com.farmdiary.app.domain.EggSaleForm(java.time.LocalDate.of(2026, 10, 8), listOf(SaleLineForm(1)))
        assertTrue(empty.isNil)
        assertTrue(empty.realLines().isEmpty())
        val sale = empty.copy(
            sales = listOf(SaleLineForm(1, "Large", "20", "10"), SaleLineForm(2), SaleLineForm(3, "Small", "10", "8")),
            cashReceived = "4000", onlineReceived = "1000"
        )
        assertEquals(8400.0, sale.totalIncome, 0.001)
        assertEquals(2, sale.realLines().size)
        assertEquals(3400.0, sale.balance, 0.001)
        assertTrue(Calc.validateSale(sale).isEmpty())
        assertTrue(Calc.validateSale(sale.copy(cashReceived = "-1")).isNotEmpty())
        // previous balance and advance
        val withOld = sale.copy(previousBalance = "1000", advancePaid = "250")
        assertEquals(4150.0, withOld.balance, 0.001)
        assertFalse(withOld.isCredit)
        assertTrue(sale.copy(cashReceived = "9000").isCredit)
    }

    @Test fun feedUsageWithinStockIsValid() {
        assertTrue(Calc.validate(form("24", "26"), availableFeed = 100.0).isEmpty())
    }

    @Test fun feedUsageOverStockIsRejected() {
        assertTrue(Calc.validate(form("60", "50"), availableFeed = 100.0).isNotEmpty())
    }

    @Test fun eggTrayConversion() {
        assertEquals(1.0, Calc.eggsToTrays(30.0), 0.0001)
        assertTrue(Calc.isInvalid("-1"))
        assertTrue(Calc.isInvalid("1.2.3"))
    }

    @org.junit.Test
    fun lowStockLimits() {
        val l = com.farmdiary.app.domain.LowStock
        org.junit.Assert.assertTrue(l.feedLow(129.0))
        org.junit.Assert.assertTrue(!l.feedLow(130.0))
        org.junit.Assert.assertTrue(l.traysLow(3999))
        org.junit.Assert.assertTrue(!l.traysLow(4000))
        org.junit.Assert.assertTrue(l.messages(200.0, 5000).isEmpty())
        org.junit.Assert.assertTrue(l.messages(100.0, 3000).size == 2)
    }
}
