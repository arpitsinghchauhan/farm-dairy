package com.farmdiary.app

import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.domain.ReportForm
import com.farmdiary.app.domain.SaleLineForm
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalcTest {
    private fun form(vararg bags: String) = ReportForm(
        date = LocalDate.of(2026, 10, 3),
        lines = bags.mapIndexed { i, b -> FarmLineForm(i.toLong(), "S.No. ${i + 1}", feedBags = b, feedRate = "1665") },
        trayQty = "10", trayRate = "20", labour = "500", light = "100", stoneQty = "2", stoneRate = "50", sales = listOf(SaleLineForm(100, "Large", "30", "300"))
    )

    @Test fun totalsAreCalculated() {
        val f = form("25", "0")
        assertEquals(25 * 1665.0 + 200 + 500 + 100 + 100, f.totalExpenditure, 0.001)
        assertEquals(9000.0, f.totalIncome, 0.001)
    }

    @Test fun extraItemsAreAddedToTotal() {
        val base = form("0")
        val withExtra = base.copy(
            extras = listOf(
                com.farmdiary.app.domain.ExtraItemForm(1, "Diesel", "300"),
                com.farmdiary.app.domain.ExtraItemForm(2, "Repair", "150.5")
            )
        )
        assertEquals(base.totalExpenditure + 450.5, withExtra.totalExpenditure, 0.001)
    }

    @Test fun productionIsEnteredInTrays() {
        val f = form("0", "0").let {
            it.copy(lines = it.lines.mapIndexed { i, l -> l.copy(trays = if (i == 0) "12" else "8.5") })
        }
        assertEquals(20.5, f.totalTrays, 0.001)
        assertEquals(615.0, f.totalEggs, 0.001)
    }

    @Test fun saleLinesAndBalance() {
        val f = form("0").copy(
            sales = listOf(SaleLineForm(1, "Large", "30", "300"), SaleLineForm(2, "Small", "10", "250")),
            cashReceived = "5000", onlineReceived = "2000"
        )
        assertEquals(11500.0, f.totalIncome, 0.001)
        assertEquals(40.0, f.totalTraysSold, 0.001)
        assertEquals(4500.0, f.balance, 0.001)
    }

    @Test fun receivedMoreThanSaleIsRejected() {
        val f = form("0").copy(cashReceived = "9000", onlineReceived = "1")
        assertTrue(Calc.validate(f, availableFeed = 100.0).isNotEmpty())
    }

    @Test fun feedUsageWithinStockIsValid() {
        assertTrue(Calc.validate(form("24", "26"), availableFeed = 100.0).isEmpty())
    }

    @Test fun feedUsageOverStockIsRejected() {
        assertTrue(Calc.validate(form("60", "50"), availableFeed = 100.0).isNotEmpty())
    }

    @Test fun eggTrayConversion() {
        assertEquals(1.0, Calc.eggsToTrays(30.0), 0.0001)
        assertTrue(Calc.isInvalid("-1"))
        assertTrue(Calc.isInvalid("1.2.3"))
    }
}
