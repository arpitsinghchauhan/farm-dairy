package com.farmdiary.app

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.domain.BirdFarmForm
import com.farmdiary.app.domain.BirdRecords
import com.farmdiary.app.domain.MAX_BIRD_FARMS
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BirdRecordTest {
    private var k = 0L
    private val key: () -> Long = { k++ }
    private val date = LocalDate.of(2026, 10, 19)

    private fun full() = BirdFarmForm(
        key = 1, name = "Shed A", day = "245", feedPerBird = "112.5", feedBags = "24", stoneBags = "2",
        production = "40.5", mortality = "3", breakage = "12", waterTanks = "2.5",
        medicines = listOf("Vitamin", "  ", "Calcium"), notes = "  Rain in the evening "
    )

    @Test fun savedRowsComeBackIntoTheForm() {
        val rows = BirdRecords.toEntities(date, listOf(full()), now = 99)
        assertEquals(1, rows.size)
        val r = rows[0]
        assertEquals("2026-10-19", r.date)
        assertEquals(245, r.dayNo)
        assertEquals(112.5, r.feedPerBirdGrams, 0.0001)
        assertEquals(3, r.mortality)
        assertEquals(12, r.breakage)
        assertEquals("Vitamin\nCalcium", r.medicines)
        assertEquals("Rain in the evening", r.notes)
        assertEquals(99L, r.updatedAt)
        val back = BirdRecords.toForms(rows, key).single()
        assertEquals("Shed A", back.name)
        assertEquals("245", back.day)
        assertEquals("112.5", back.feedPerBird)
        assertEquals(listOf("Vitamin", "Calcium"), back.medicines)
    }

    @Test fun emptyFarmsAreNotSavedAndGetDefaultNames() {
        val empty = BirdFarmForm(1, name = "Shed Z")
        assertFalse(empty.hasData)
        val noName = BirdFarmForm(2, mortality = "1")
        val rows = BirdRecords.toEntities(date, listOf(empty, noName), 1)
        assertEquals(1, rows.size)
        assertEquals("Farm 1", rows[0].name)
    }

    @Test fun atMostFiveFarmsAndFiveMedicinesAreSaved() {
        val farms = (1..7).map { BirdFarmForm(it.toLong(), day = "$it", medicines = (1..8).map { m -> "M$m" }) }
        val rows = BirdRecords.toEntities(date, farms, 1)
        assertEquals(MAX_BIRD_FARMS, rows.size)
        assertEquals(5, rows[0].medicines.split("\n").size)
    }

    @Test fun invalidNumbersAreRejected() {
        assertTrue(BirdRecords.validate(listOf(full())).isEmpty())
        assertTrue(BirdRecords.validate(listOf(full().copy(feedBags = "-1"))).isNotEmpty())
        assertTrue(BirdRecords.validate(listOf(full().copy(mortality = "2x"))).isNotEmpty())
    }

    @Test fun newDayStartsWithNamesAndDayCountedForward() {
        val prev = listOf(
            BirdRecordEntity(1, "2026-10-17", 0, "Shed A", 243, 110.0, 24.0, 2.0, 40.0, 1, 5, 2.0, "", "", 1),
            BirdRecordEntity(2, "2026-10-17", 1, "Shed B", 0, 0.0, 0.0, 0.0, 0.0, 0, 0, 0.0, "", "", 1)
        )
        val forms = BirdRecords.prefill(prev, LocalDate.of(2026, 10, 17), date, key)
        assertEquals(2, forms.size)
        assertEquals("Shed A", forms[0].name)
        assertEquals("245", forms[0].day)
        assertEquals("", forms[1].day)
        assertEquals("", forms[0].feedBags)
        assertFalse(forms[0].medicines.isNotEmpty())
        assertTrue(BirdRecords.prefill(emptyList(), date, date, key).isEmpty())
    }

    @Test fun historyHasOneLinePerDateNewestFirstWithTotals() {
        fun row(d: String, pos: Int, prod: Double, dead: Int) =
            BirdRecordEntity(0, d, pos, "S${pos + 1}", 100, 100.0, 10.0, 1.0, prod, dead, 2, 1.0, "", "", 1)
        val h = BirdRecords.summarize(
            listOf(row("2026-10-17", 0, 40.0, 1), row("2026-10-19", 0, 30.0, 2), row("2026-10-19", 1, 20.5, 3))
        )
        assertEquals(listOf("2026-10-19", "2026-10-17"), h.map { it.date })
        assertEquals(50.5, h[0].production, 0.001)
        assertEquals(5, h[0].mortality)
        assertEquals(4, h[0].breakage)
        assertEquals(20.0, h[0].feedBags, 0.001)
        assertEquals(listOf("S1", "S2"), h[0].farmNames)
    }

    @Test fun longNotesAreWrappedForThePdf() {
        val lines = BirdRecords.wrap("one two three four five six seven", 10)
        assertTrue(lines.all { it.length <= 10 })
        assertEquals("one two three four five six seven", lines.joinToString(" "))
        assertEquals(listOf("abcde", "fghij", "k"), BirdRecords.wrap("abcdefghijk", 5))
        assertEquals(listOf("a", "b"), BirdRecords.wrap("a\nb", 10))
        assertEquals(listOf(""), BirdRecords.wrap("", 10))
    }

    @Test fun weekOfAgeCountsSevenDaysPerWeek() {
        assertEquals(0, BirdRecords.weekOf(0))
        assertEquals(1, BirdRecords.weekOf(1))
        assertEquals(1, BirdRecords.weekOf(7))
        assertEquals(2, BirdRecords.weekOf(8))
        assertEquals(3, BirdRecords.weekOf(15))
    }

    @Test fun monthlySummaryAddsMortalityAndKeepsBirdCount() {
        fun row(d: String, birds: Int, dead: Int, prod: Double) =
            BirdRecordEntity(0, d, 0, "Farm A", 1, 100.0, 2.0, 0.0, prod, dead, 0, 0.0, "", "", 1L, birds)
        val all = listOf(
            row("2026-10-01", 1000, 3, 10.0),
            row("2026-10-02", 997, 2, 11.0),
            row("2026-09-30", 1003, 3, 9.0)
        )
        val m = com.farmdiary.app.domain.BirdMonthly.build(all, java.time.YearMonth.of(2026, 10))
        assertEquals(1, m.size)
        assertEquals(1000, m[0].birdsAtStart)
        assertEquals(5, m[0].mortality)
        assertEquals(995, m[0].birdsAtEnd)
        assertEquals(21.0, m[0].production, 0.001)
        assertEquals(2, m[0].days)
    }
}
