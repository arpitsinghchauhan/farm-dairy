package com.farmdiary.app

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.SaleLineEntity
import com.farmdiary.app.domain.EggSaleHistory
import java.time.LocalDate
import com.farmdiary.app.domain.StockHistory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryTest {
    private fun report(date: String, confirmed: Boolean, closingFeed: Double) = DailyReportEntity(
        date = date, trayQty = 0.0, trayRate = 0.0, labour = 0.0, light = 0.0, stoneQty = 0.0, stoneRate = 0.0,
        eggSell = 0.0, confirmed = confirmed, confirmedFeedUsed = 40.0, openingFeed = closingFeed + 40.0,
        closingFeed = closingFeed, createdAt = 1L, updatedAt = 1L
    )

    @Test fun stockIsShownOnlyForTheExactConfirmedDate() {
        val all = listOf(report("2026-10-18", true, 198.0), report("2026-10-19", false, 150.0))
        assertEquals(198.0, StockHistory.onExact(all, "2026-10-18")!!.feedLeft, 0.001)
        assertTrue(StockHistory.onExact(all, "2026-10-19") == null) // draft: no confirmed record
        assertTrue(StockHistory.onExact(all, "2026-10-20") == null) // other day: no record (not carried forward)
    }

    @Test fun historyListsConfirmedDaysNewestFirst() {
        val all = listOf(report("2026-10-17", true, 1.0), report("2026-10-19", true, 3.0), report("2026-10-18", false, 2.0))
        assertEquals(listOf("2026-10-19", "2026-10-17"), StockHistory.rows(all).map { it.date })
        assertTrue(StockHistory.on(all, "2026-10-20") != null)
    }

    @Test fun daysWithoutASavedSaleCountAsZeroAndKeepTheBalance() {
        val sales = listOf(
            EggSaleEntity("2026-10-10", 0.0, 0.0, 0, previousBalance = 0.0, advancePaid = 0.0, closingBalance = 500.0),
            EggSaleEntity("2026-10-13", 0.0, 0.0, 0, previousBalance = 500.0, advancePaid = 0.0, closingBalance = 300.0)
        )
        val lines = listOf(SaleLineEntity(reportDate = "2026-10-10", position = 0, name = "L", trays = 10.0, rate = 5.0))
        val rows = EggSaleHistory.build(sales, lines, LocalDate.of(2026, 10, 14))
        assertEquals(listOf("2026-10-14", "2026-10-13", "2026-10-12", "2026-10-11", "2026-10-10"), rows.map { it.date })
        assertEquals(1500.0, rows[4].total, 0.001)
        assertEquals(0.0, rows[3].total, 0.001)
        assertEquals(500.0, rows[3].balance, 0.001)
        assertTrue(!rows[2].recorded)
        assertEquals(300.0, rows[1].balance, 0.001)
        assertEquals(300.0, rows[0].balance, 0.001) // today, nothing saved: balance carried
    }
}

class PastStockTest {
    private fun m(date: String, feed: Double, tray: Int, egg: Int) =
        com.farmdiary.app.data.StockDayEntity(date, feed, tray, egg, 1L)

    @org.junit.Test
    fun manualRecordAndLatest() {
        val manual = listOf(m("2026-10-01", 5.0, 200, -1))
        val r = StockHistory.record(emptyList(), manual, "2026-10-01")!!
        org.junit.Assert.assertTrue(r.feedLeft == 5.0)
        org.junit.Assert.assertTrue(r.trayBundlesLeft == 2.0)
        org.junit.Assert.assertTrue(r.eggTrays == null)
        org.junit.Assert.assertTrue(StockHistory.record(emptyList(), manual, "2026-10-02") == null)
        org.junit.Assert.assertTrue(StockHistory.latestDate(emptyList(), manual) == "2026-10-01")
        org.junit.Assert.assertTrue(StockHistory.latestDate(emptyList(), emptyList()) == null)
    }
}
