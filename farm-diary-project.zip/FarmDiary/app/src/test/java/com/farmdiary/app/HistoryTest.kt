package com.farmdiary.app

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.domain.StockHistory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryTest {
    private fun report(date: String, confirmed: Boolean, closingFeed: Double) = DailyReportEntity(
        date = date, trayQty = 0.0, trayRate = 0.0, labour = 0.0, light = 0.0, stoneQty = 0.0, stoneRate = 0.0,
        eggSell = 0.0, confirmed = confirmed, confirmedFeedUsed = 40.0, openingFeed = closingFeed + 40.0,
        closingFeed = closingFeed, createdAt = 1L, updatedAt = 1L
    )

    @Test fun stockIsShownOnlyForTheExactConfirmedDate() {
        val all = listOf(report("2026-10-18", true, 198.0), report("2026-10-19", false, 150.0))
        assertEquals(198.0, StockHistory.onExact(all, "2026-10-18")!!.feedLeft, 0.001)
        assertTrue(StockHistory.onExact(all, "2026-10-19") == null) // draft: no confirmed record
        assertTrue(StockHistory.onExact(all, "2026-10-20") == null) // other day: no record (not carried forward)
    }

    @Test fun historyListsConfirmedDaysNewestFirst() {
        val all = listOf(report("2026-10-17", true, 1.0), report("2026-10-19", true, 3.0), report("2026-10-18", false, 2.0))
        assertEquals(listOf("2026-10-19", "2026-10-17"), StockHistory.rows(all).map { it.date })
        assertTrue(StockHistory.on(all, "2026-10-20") != null)
    }
}
