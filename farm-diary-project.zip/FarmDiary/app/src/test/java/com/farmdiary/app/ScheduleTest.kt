package com.farmdiary.app

import com.farmdiary.app.domain.formatTime
import com.farmdiary.app.domain.nextTriggerMillis
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Test

class ScheduleTest {
    @Test fun timeIsShownOnA12HourClock() {
        assertEquals("7:05 AM", formatTime(7, 5))
        assertEquals("12:00 PM", formatTime(12, 0))
        assertEquals("12:30 AM", formatTime(0, 30))
        assertEquals("3:00 PM", formatTime(15, 0))
    }

    @Test fun nextTriggerIsTodayOrTomorrow() {
        val zone = ZoneId.of("Asia/Kolkata")
        val now = ZonedDateTime.of(2026, 10, 8, 10, 0, 0, 0, zone)
        val later = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTriggerMillis(15, 0, now)), zone)
        assertEquals(8, later.dayOfMonth)
        assertEquals(15, later.hour)
        val passed = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTriggerMillis(7, 0, now)), zone)
        assertEquals(9, passed.dayOfMonth)
        assertEquals(7, passed.hour)
    }
}
