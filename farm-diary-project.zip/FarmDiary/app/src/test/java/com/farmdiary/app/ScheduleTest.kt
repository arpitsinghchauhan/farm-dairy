package com.farmdiary.app

import com.farmdiary.app.domain.formatTime
import com.farmdiary.app.domain.nextTriggerMillis
import com.farmdiary.app.domain.nextReminderMillis
import com.farmdiary.app.domain.occursOn
import com.farmdiary.app.domain.ScheduleKind
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Test

class ScheduleTest {
    @Test fun timeIsShownOnA12HourClock() {
        assertEquals("7:05 AM", formatTime(7, 5))
        assertEquals("12:00 PM", formatTime(12, 0))
        assertEquals("12:30 AM", formatTime(0, 30))
        assertEquals("3:00 PM", formatTime(15, 0))
    }

    @Test fun nextTriggerIsTodayOrTomorrow() {
        val zone = ZoneId.of("Asia/Kolkata")
        val now = ZonedDateTime.of(2026, 10, 8, 10, 0, 0, 0, zone)
        val later = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTriggerMillis(15, 0, now)), zone)
        assertEquals(8, later.dayOfMonth)
        assertEquals(15, later.hour)
        val passed = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(nextTriggerMillis(7, 0, now)), zone)
        assertEquals(9, passed.dayOfMonth)
        assertEquals(7, passed.hour)
    }

    private val zone = ZoneId.of("Asia/Kolkata")
    private fun at(ms: Long) = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(ms), zone)

    @Test fun dailyReminderRingsFiveMinutesBefore() {
        val now = ZonedDateTime.of(2026, 10, 8, 6, 0, 0, 0, zone)
        val r = at(nextReminderMillis(ScheduleKind.DAILY, 7, 0, 1, 1, now))
        assertEquals(8, r.dayOfMonth); assertEquals(6, r.hour); assertEquals(55, r.minute)
    }

    @Test fun dailyReminderMovesToTomorrowWhenTheFiveMinutesHavePassed() {
        val now = ZonedDateTime.of(2026, 10, 8, 6, 57, 0, 0, zone)
        val r = at(nextReminderMillis(ScheduleKind.DAILY, 7, 0, 1, 1, now))
        assertEquals(9, r.dayOfMonth); assertEquals(6, r.hour); assertEquals(55, r.minute)
    }

    @Test fun weeklyReminderRingsOneDayBefore() {
        // 8 Oct 2026 is a Thursday. Task: every Saturday (6) 9:00 -> reminder on Friday 9:00 (9 Oct).
        val now = ZonedDateTime.of(2026, 10, 8, 10, 0, 0, 0, zone)
        val r = at(nextReminderMillis(ScheduleKind.WEEKLY, 9, 0, 6, 1, now))
        assertEquals(9, r.dayOfMonth); assertEquals(9, r.hour)
    }

    @Test fun weeklyReminderForTomorrowsTaskThatAlreadyPassedGoesToNextWeek() {
        // Task is Friday 9:00; now is Thursday 10:00 -> today's reminder time (Thu 9:00) has passed -> next Thursday 9:00 (15 Oct)
        val now = ZonedDateTime.of(2026, 10, 8, 10, 0, 0, 0, zone)
        val r = at(nextReminderMillis(ScheduleKind.WEEKLY, 9, 0, 5, 1, now))
        assertEquals(15, r.dayOfMonth); assertEquals(9, r.hour)
    }

    @Test fun monthlyReminderRingsFiveDaysBefore() {
        // Task: 20th at 8:00 -> reminder 15th at 8:00
        val now = ZonedDateTime.of(2026, 10, 8, 10, 0, 0, 0, zone)
        val r = at(nextReminderMillis(ScheduleKind.MONTHLY, 8, 0, 1, 20, now))
        assertEquals(10, r.monthValue); assertEquals(15, r.dayOfMonth); assertEquals(8, r.hour)
    }

    @Test fun monthlyTaskOnThe31stFallsOnTheLastDayOfShortMonths() {
        assertEquals(true, occursOn(ScheduleKind.MONTHLY, 1, 31, LocalDate.of(2026, 11, 30)))
        assertEquals(false, occursOn(ScheduleKind.MONTHLY, 1, 31, LocalDate.of(2026, 11, 29)))
        assertEquals(true, occursOn(ScheduleKind.MONTHLY, 1, 31, LocalDate.of(2026, 10, 31)))
    }

    @Test fun monthlyReminderAfterTheDateGoesToNextMonth() {
        val now = ZonedDateTime.of(2026, 10, 22, 10, 0, 0, 0, zone)
        val r = at(nextReminderMillis(ScheduleKind.MONTHLY, 8, 0, 1, 20, now))
        assertEquals(11, r.monthValue); assertEquals(15, r.dayOfMonth)
    }
}
