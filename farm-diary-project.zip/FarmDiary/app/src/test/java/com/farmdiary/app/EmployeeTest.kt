package com.farmdiary.app

import com.farmdiary.app.data.EmployeeEntity
import com.farmdiary.app.data.EmployeePaymentEntity
import com.farmdiary.app.domain.EmployeeCalc
import com.farmdiary.app.domain.EmployeeRules
import com.farmdiary.app.domain.PayMode
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EmployeeTest {
    private fun pay(id: String, emp: String, date: String, mode: String, amt: Double, at: Long, deleted: Boolean = false) =
        EmployeePaymentEntity(id, emp, date, mode, amt, "", deleted, at, at)

    @Test fun nameRules() {
        assertTrue(EmployeeRules.validateName("  ", emptyList()).isNotEmpty())
        assertTrue(EmployeeRules.validateName("Ram", listOf("ram")).isNotEmpty())
        assertTrue(EmployeeRules.validateName("Ram", listOf("Shyam")).isEmpty())
        assertTrue(EmployeeRules.validateName("x".repeat(41), emptyList()).isNotEmpty())
    }

    @Test fun amountRules() {
        assertTrue(EmployeeRules.validateAmount("").isNotEmpty())
        assertTrue(EmployeeRules.validateAmount("0").isNotEmpty())
        assertTrue(EmployeeRules.validateAmount("-5").isNotEmpty())
        assertTrue(EmployeeRules.validateAmount("500").isEmpty())
        assertEquals(10, EmployeeRules.MAX_EMPLOYEES)
    }

    @Test fun totalsIgnoreDeleted() {
        val list = listOf(
            pay("1", "a", "2026-10-01", PayMode.CASH, 500.0, 1),
            pay("2", "a", "2026-10-01", PayMode.ONLINE, 300.0, 2),
            pay("3", "a", "2026-10-01", PayMode.CASH, 100.0, 3, deleted = true)
        )
        val t = EmployeeCalc.totals(list)
        assertEquals(500.0, t.cash, 1e-9)
        assertEquals(300.0, t.online, 1e-9)
        assertEquals(800.0, t.total, 1e-9)
    }

    @Test fun manyPaymentsOnOneDateAreGrouped() {
        val list = listOf(
            pay("1", "a", "2026-10-01", PayMode.CASH, 500.0, 1),
            pay("2", "a", "2026-10-03", PayMode.CASH, 200.0, 2),
            pay("3", "a", "2026-10-01", PayMode.ONLINE, 300.0, 3),
            pay("4", "b", "2026-10-01", PayMode.CASH, 999.0, 4)
        )
        val days = EmployeeCalc.byDate(list, "a")
        assertEquals(listOf("2026-10-03", "2026-10-01"), days.map { it.date })
        assertEquals(listOf("3", "1"), days[1].entries.map { it.id })
        assertEquals(800.0, days[1].total, 1e-9)
    }

    @Test fun employeesTravelInTheShareFile() {
        val d = SyncData(
            farmName = "F", exportedAt = 1L, reports = emptyList(), lines = emptyList(), extras = emptyList(),
            eggSales = emptyList(), saleLines = emptyList(), feedTxns = emptyList(), stock = null,
            employees = listOf(EmployeeEntity("e1", "Ram", false, 1, 2), EmployeeEntity("e2", "Old", true, 1, 3)),
            employeePayments = listOf(pay("p1", "e1", "2026-10-01", PayMode.ONLINE, 250.5, 5))
        )
        val back = SyncCodec.fromJson(SyncCodec.toJson(d))
        assertEquals(d.employees, back.employees)
        assertEquals(d.employeePayments, back.employeePayments)
        assertEquals(1, back.employeeCount)
        assertEquals(1, back.paymentCount)
    }

    @Test fun oldFilesWithoutEmployeesStillLoad() {
        val old = SyncCodec.toJson(
            SyncData("F", 1L, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), null)
        )
        val stripped = org.json.JSONObject(old).also { it.remove("employees"); it.remove("employeePayments") }.toString()
        assertTrue(SyncCodec.fromJson(stripped).employees.isEmpty())
    }

    @Test fun monthStatementLeftToPay() {
        val list = listOf(
            pay("1", "a", "2026-10-01", PayMode.CASH, 5000.0, 1),
            pay("2", "a", "2026-10-15", PayMode.ONLINE, 3000.0, 2),
            pay("3", "a", "2026-09-30", PayMode.CASH, 9999.0, 3),
            pay("4", "a", "2026-10-20", PayMode.CASH, 100.0, 4, deleted = true),
            pay("5", "b", "2026-10-02", PayMode.CASH, 777.0, 5)
        )
        val st = EmployeeCalc.statement(list, "a", 12000.0, java.time.YearMonth.of(2026, 10))
        assertEquals(5000.0, st.cash, 1e-9)
        assertEquals(3000.0, st.online, 1e-9)
        assertEquals(8000.0, st.paid, 1e-9)
        assertEquals(4000.0, st.leftToPay, 1e-9)
        assertEquals(listOf("1", "2"), st.entries.map { it.id })
        val sep = EmployeeCalc.statement(list, "a", 5000.0, java.time.YearMonth.of(2026, 9))
        assertEquals(-4999.0, sep.leftToPay, 1e-9) // paid extra
    }

    @Test fun absentDaysCutTheSalaryByDay() {
        fun att(d: String, st: String, deleted: Boolean = false) =
            com.farmdiary.app.data.EmployeeAttendanceEntity("a|$d", "a", d, st, deleted, 1)
        val days = listOf(
            att("2026-10-03", "ABSENT"), att("2026-10-04", "ABSENT"), att("2026-10-10", "HALF"),
            att("2026-10-12", "ABSENT", deleted = true), att("2026-09-30", "ABSENT")
        )
        // October has 31 days: 31000 / 31 = 1000 a day, 2.5 days cut
        val st = EmployeeCalc.statement(emptyList(), "a", 31000.0, java.time.YearMonth.of(2026, 10), days)
        assertEquals(2, st.absentDays)
        assertEquals(1, st.halfDays)
        assertEquals(1000.0, st.perDay, 1e-9)
        assertEquals(2500.0, st.deduction, 1e-9)
        assertEquals(28500.0, st.payable, 1e-9)
        assertEquals(28500.0, st.leftToPay, 1e-9)
        assertEquals(null, com.farmdiary.app.domain.Attendance.next("HALF"))
        assertEquals("ABSENT", com.farmdiary.app.domain.Attendance.next(null))
    }

    @Test fun illnessMedicinesAreKeptAndChecked() {
        val meds = listOf(
            com.farmdiary.app.domain.MedicineDose("Tylosin", "0.5 ml"),
            com.farmdiary.app.domain.MedicineDose("", ""),
            com.farmdiary.app.domain.MedicineDose("Vitamin\nC", "1\tg")
        )
        val text = com.farmdiary.app.domain.IllnessRules.encode(meds)
        val back = com.farmdiary.app.domain.IllnessRules.decode(text)
        assertEquals(2, back.size)
        assertEquals("Tylosin", back[0].name)
        assertEquals("0.5 ml", back[0].dose)
        assertEquals("Vitamin C", back[1].name)
        assertTrue(com.farmdiary.app.domain.IllnessRules.validate("", "", "", emptyList()).size == 3)
        assertTrue(com.farmdiary.app.domain.IllnessRules.validate("Cold", "245", "S.No. 1", meds).isEmpty())
    }

    @Test fun feedMakerSplitsTheBagsByPercent() {
        val items = listOf(
            com.farmdiary.app.domain.MixItem("LC", "40"), com.farmdiary.app.domain.MixItem("Bajra", "45"),
            com.farmdiary.app.domain.MixItem("Dorb", "5"), com.farmdiary.app.domain.MixItem("Pather", "10")
        )
        assertTrue(com.farmdiary.app.domain.FeedMakerCalc.validate(items).isEmpty())
        // 29.14 bags = 1457 kg: LC 582.8 kg = 11.656 bags
        val r = com.farmdiary.app.domain.FeedMakerCalc.split(items, 29.14)
        assertEquals(582.8, r.rows[0].kg, 1e-6)
        assertEquals(655.65, r.rows[1].kg, 1e-6)
        assertEquals(0.0, r.fullFeedBags, 1e-9)
        val rounded = com.farmdiary.app.domain.FeedMakerCalc.split(items, 29.14, 100.0, true)
        assertEquals(585.0, rounded.rows[0].kg, 1e-9)
        assertEquals(655.0, rounded.rows[1].kg, 1e-9)
        // 75 % made on the farm, 25 % bought full feed
        val part = com.farmdiary.app.domain.FeedMakerCalc.split(items, 20.0, 75.0)
        assertEquals(5.0, part.fullFeedBags, 1e-9)
        assertEquals(15.0 * 50 * 0.40, part.rows[0].kg, 1e-9)
        val priced = items.map { it.copy(rate = if (it.name == "LC") "30" else "20") }
        val c = com.farmdiary.app.domain.FeedMakerCalc.split(priced, 20.0) // 1000 kg: 400 kg x 30 + 600 kg x 20
        assertEquals(24000.0, c.totalCost, 1e-6)
        assertEquals(24.0, c.costPerKg, 1e-9)
        assertTrue(com.farmdiary.app.domain.FeedMakerCalc.validate(items.take(3)).isNotEmpty())
        assertEquals(items, com.farmdiary.app.domain.FeedMakerCalc.decode(com.farmdiary.app.domain.FeedMakerCalc.encode(items)))
    }

    @Test fun salaryRulesAndSync() {
        assertTrue(EmployeeRules.validateSalary("abc").isNotEmpty())
        assertTrue(EmployeeRules.validateSalary("12000").isEmpty())
        val d = SyncData(
            "F", 1L, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), null,
            employees = listOf(EmployeeEntity("e1", "Ram", false, 1, 2, 15000.0))
        )
        assertEquals(15000.0, SyncCodec.fromJson(SyncCodec.toJson(d)).employees[0].monthlySalary, 1e-9)
    }
}

class ContactTest {
    @org.junit.Test
    fun contactRules() {
        val r = com.farmdiary.app.domain.EmployeeRules
        org.junit.Assert.assertTrue(r.validateContact("", "").isEmpty())
        org.junit.Assert.assertTrue(r.validateContact("9876543210", "123456789012").isEmpty())
        org.junit.Assert.assertTrue(r.validateContact("12345", "").size == 1)
        org.junit.Assert.assertTrue(r.validateContact("", "1234").size == 1)
    }
}
