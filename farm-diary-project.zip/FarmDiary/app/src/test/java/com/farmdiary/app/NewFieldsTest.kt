package com.farmdiary.app

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.domain.Dashboard
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.YearMonth

class NewFieldsTest {
    private val month = YearMonth.of(2026, 10)

    private fun bird(date: String, pos: Int, name: String, start: Int, dead: Int, trays: Double) =
        BirdRecordEntity(0, date, pos, name, 100, 100.0, 1.0, 0.0, trays, dead, 0, 0.0, "", "", 1L, start)

    @Test fun weekFromDay() {
        assertEquals(0, FarmLineForm(1, dayNo = "").week)
        assertEquals(1, FarmLineForm(1, dayNo = "7").week)
        assertEquals(2, FarmLineForm(1, dayNo = "8").week)
        assertEquals(35, FarmLineForm(1, dayNo = "245").week)
    }

    @Test fun farmSeriesKeepsEachFarmApart() {
        val rows = listOf(
            bird("2026-10-01", 0, "S.No. 1", 1000, 10, 25.0),
            bird("2026-10-02", 0, "S.No. 1", 990, 5, 26.0),
            bird("2026-10-01", 1, "S.No. 2", 500, 0, 0.0)
        )
        val farms = Dashboard.farmSeries(month, rows)
        assertEquals(2, farms.size)
        assertEquals(990, farms[0].days[0].birdsLeft)
        assertEquals(985, farms[0].days[1].birdsLeft)
        assertEquals(0, farms[0].days[2].birdsLeft)
        assertEquals(75.0, farms[0].days[0].productionPercent, 1e-9)
        assertTrue(farms[0].hasProduction)
        assertTrue(farms[1].hasBirds)
        assertTrue(!farms[1].hasProduction)
    }

    @Test fun eggRateShowsPerDay() {
        val r = DailyReportEntity("2026-10-03", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, confirmed = false, confirmedFeedUsed = 0.0,
            openingFeed = 0.0, closingFeed = 0.0, createdAt = 1, updatedAt = 1, eggRate = 5.25)
        val s = Dashboard.build(month, listOf(r), emptyList(), emptyList(), emptyList(), emptyList())
        assertTrue(s.hasEggRate)
        assertEquals(5.25, s.days[2].eggRate, 1e-9)
        assertEquals(0.0, s.days[0].eggRate, 1e-9)
    }

    @Test fun eggRateAndAgeTravelInTheShareFile() {
        val r = DailyReportEntity("2026-10-03", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, confirmed = false, confirmedFeedUsed = 0.0,
            openingFeed = 0.0, closingFeed = 0.0, createdAt = 1, updatedAt = 1, eggRate = 5.25)
        val l = FarmLineEntity(0, "2026-10-03", 0, "S.No. 1", 1.0, 2.0, 3.0, 4, 245)
        val d = SyncData("F", 1L, listOf(r), listOf(l), emptyList(), emptyList(), emptyList(), emptyList(), null)
        val back = SyncCodec.fromJson(SyncCodec.toJson(d))
        assertEquals(5.25, back.reports[0].eggRate, 1e-9)
        assertEquals(245, back.lines[0].dayNo)
    }
}

class FarmCountSyncTest {
    @Test fun farmCountTravelsInTheShareFile() {
        val d = SyncData("F", 1L, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), null, farmCount = 3)
        assertEquals(3, SyncCodec.fromJson(SyncCodec.toJson(d)).farmCount)
    }
}
