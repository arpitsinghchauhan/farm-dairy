package com.farmdiary.app

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.domain.Dashboard
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.YearMonth

class NewFieldsTest {
    private val month = YearMonth.of(2026, 10)

    private fun bird(date: String, pos: Int, name: String, start: Int, dead: Int, trays: Double) =
        BirdRecordEntity(0, date, pos, name, 100, 100.0, 1.0, 0.0, trays, dead, 0, 0.0, "", "", 1L, start)

    @Test fun weekFromDay() {
        assertEquals(0, FarmLineForm(1, dayNo = "").week)
        assertEquals(1, FarmLineForm(1, dayNo = "7").week)
        assertEquals(2, FarmLineForm(1, dayNo = "8").week)
        assertEquals(35, FarmLineForm(1, dayNo = "245").week)
    }

    @Test fun farmSeriesKeepsEachFarmApart() {
        val rows = listOf(
            bird("2026-10-01", 0, "S.No. 1", 1000, 10, 25.0),
            bird("2026-10-02", 0, "S.No. 1", 990, 5, 26.0),
            bird("2026-10-01", 1, "S.No. 2", 500, 0, 0.0)
        )
        val farms = Dashboard.farmSeries(month, rows)
        assertEquals(2, farms.size)
        assertEquals(990, farms[0].days[0].birdsLeft)
        assertEquals(985, farms[0].days[1].birdsLeft)
        assertEquals(0, farms[0].days[2].birdsLeft)
        assertEquals(75.0, farms[0].days[0].productionPercent, 1e-9)
        assertTrue(farms[0].hasProduction)
        assertTrue(farms[1].hasBirds)
        assertTrue(!farms[1].hasProduction)
    }

    @Test fun eggRateShowsPerDay() {
        val r = DailyReportEntity("2026-10-03", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, confirmed = false, confirmedFeedUsed = 0.0,
            openingFeed = 0.0, closingFeed = 0.0, createdAt = 1, updatedAt = 1, eggRate = 5.25)
        val s = Dashboard.build(month, listOf(r), emptyList(), emptyList(), emptyList(), emptyList())
        assertTrue(s.hasEggRate)
        assertEquals(5.25, s.days[2].eggRate, 1e-9)
        assertEquals(0.0, s.days[0].eggRate, 1e-9)
    }

    @Test fun eggRateAndAgeTravelInTheShareFile() {
        val r = DailyReportEntity("2026-10-03", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, confirmed = false, confirmedFeedUsed = 0.0,
            openingFeed = 0.0, closingFeed = 0.0, createdAt = 1, updatedAt = 1, eggRate = 5.25)
        val l = FarmLineEntity(0, "2026-10-03", 0, "S.No. 1", 1.0, 2.0, 3.0, 4, 245)
        val d = SyncData("F", 1L, listOf(r), listOf(l), emptyList(), emptyList(), emptyList(), emptyList(), null)
        val back = SyncCodec.fromJson(SyncCodec.toJson(d))
        assertEquals(5.25, back.reports[0].eggRate, 1e-9)
        assertEquals(245, back.lines[0].dayNo)
    }
}

class FarmCountSyncTest {
    @Test fun farmCountTravelsInTheShareFile() {
        val d = SyncData("F", 1L, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), null, farmCount = 3)
        assertEquals(3, SyncCodec.fromJson(SyncCodec.toJson(d)).farmCount)
    }
}

class LinkTest {
    private fun bird(pos: Int, bags: Double, prod: Double, dead: Int, stone: Double) =
        BirdRecordEntity(0, "2026-10-03", pos, "S", 100, 100.0, bags, stone, prod, dead, 0, 0.0, "", "", 1L, 1000)

    private fun form(created: Long = 0L) = com.farmdiary.app.domain.ReportForm(
        java.time.LocalDate.of(2026, 10, 3),
        listOf(FarmLineForm(1, feedBags = "5", trays = "20", mortality = "1"), FarmLineForm(2)),
        createdAt = created
    )

    @Test fun farmRecordValuesFlowIntoTheReportAndStoneIsTheTotal() {
        val out = com.farmdiary.app.domain.ReportLinks.overlay(form(), listOf(bird(0, 6.0, 25.0, 3, 1.5), bird(1, 4.0, 22.0, 2, 2.0)))
        assertEquals("6", out.lines[0].feedBags)
        assertEquals("25", out.lines[0].trays)
        assertEquals("3", out.lines[0].mortality)
        assertEquals("4", out.lines[1].feedBags)
        assertEquals("3.5", out.stoneQty)
        assertTrue(out.stoneFromRecords)
        assertTrue(!out.dirty)
    }

    @Test fun aSavedReportThatChangesIsMarkedNotSaved() {
        val out = com.farmdiary.app.domain.ReportLinks.overlay(form(created = 5L), listOf(bird(0, 6.0, 25.0, 3, 0.0)))
        assertTrue(out.dirty)
        val same = com.farmdiary.app.domain.ReportLinks.overlay(form(created = 5L), listOf(bird(0, 5.0, 20.0, 1, 0.0)))
        assertTrue(!same.dirty)
    }

    @Test fun reportValuesFillEmptyFarmRecords() {
        val lines = listOf(FarmLineEntity(0, "2026-10-03", 1, "S.No. 2", 4.0, 0.0, 18.0, 2, 0))
        val forms = com.farmdiary.app.domain.ReportLinks.fillFarms(
            listOf(com.farmdiary.app.domain.BirdFarmForm(1), com.farmdiary.app.domain.BirdFarmForm(2)), lines
        )
        assertEquals("", forms[0].production)
        assertEquals("18", forms[1].production)
        assertEquals("2", forms[1].mortality)
    }

    @Test fun eggStockAddsProductionAndTakesOffSales() {
        val f = form().copy(
            sales = listOf(com.farmdiary.app.domain.SaleLineForm(1, trays = "5", rate = "5"))
        ) // production 20, sold 5
        assertEquals(15, f.netEggs)
        assertEquals(115, f.eggLeft(100))
        val noSale = form()
        assertEquals(20, noSale.netEggs)
        assertEquals(120, noSale.eggLeft(100))
    }
}

class RateTest {
    @Test fun eggPriceKeepsNineDecimals() {
        assertEquals("4.16666666", com.farmdiary.app.domain.Calc.rateText(4.16666666))
        assertEquals("4.166666667", com.farmdiary.app.domain.Calc.rateText(4.1666666666))
        assertEquals("5", com.farmdiary.app.domain.Calc.rateText(5.0))
        assertEquals("5.2", com.farmdiary.app.domain.Calc.rateText(5.2))
        assertEquals(4.16666666, com.farmdiary.app.domain.Calc.parse("4.16666666"), 0.0)
    }
}
