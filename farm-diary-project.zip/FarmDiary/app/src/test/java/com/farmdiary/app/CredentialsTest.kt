package com.farmdiary.app

import com.farmdiary.app.domain.Credentials
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CredentialsTest {
    @Test fun samePhoneAndPinGiveSameHash() {
        assertEquals(Credentials.hash("9876543210", "1234"), Credentials.hash("9876543210", "1234"))
    }

    @Test fun differentPinOrPhoneGivesDifferentHash() {
        assertNotEquals(Credentials.hash("9876543210", "1234"), Credentials.hash("9876543210", "1235"))
        assertNotEquals(Credentials.hash("9876543210", "1234"), Credentials.hash("9876543211", "1234"))
    }

    @Test fun phoneMustBeTenDigits() {
        assertTrue(Credentials.isValidPhone("9876543210"))
        assertFalse(Credentials.isValidPhone("98765"))
        assertFalse(Credentials.isValidPhone("98765432ab"))
    }

    @Test fun pinIsFourToSixDigits() {
        assertTrue(Credentials.isValidPin("1234"))
        assertTrue(Credentials.isValidPin("123456"))
        assertFalse(Credentials.isValidPin("123"))
        assertFalse(Credentials.isValidPin("1234567"))
        assertFalse(Credentials.isValidPin("12a4"))
    }
}
