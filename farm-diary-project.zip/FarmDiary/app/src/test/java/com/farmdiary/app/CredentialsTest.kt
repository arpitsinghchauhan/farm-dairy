package com.farmdiary.app

import com.farmdiary.app.domain.Credentials
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CredentialsTest {
    private val dob = LocalDate.of(1985, 4, 12)

    @Test fun samePhoneAndDobGiveSameHash() {
        assertEquals(Credentials.hash("9876543210", dob), Credentials.hash("9876543210", dob))
    }

    @Test fun differentDobGivesDifferentHash() {
        assertNotEquals(Credentials.hash("9876543210", dob), Credentials.hash("9876543210", dob.plusDays(1)))
    }

    @Test fun phoneMustBeTenDigits() {
        assertTrue(Credentials.isValidPhone("9876543210"))
        assertFalse(Credentials.isValidPhone("98765"))
        assertFalse(Credentials.isValidPhone("98765432ab"))
    }

    @Test fun dobMustBeInThePast() {
        assertTrue(Credentials.isValidDob(dob))
        assertFalse(Credentials.isValidDob(null))
        assertFalse(Credentials.isValidDob(LocalDate.now().plusDays(1)))
    }
}
