package com.farmdiary.app

import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.domain.FeedCalc
import com.farmdiary.app.domain.FeedType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FeedLedgerTest {
    private var n = 0
    private fun buy(date: String, bags: Double, rate: Double, discount: Double, deleted: Boolean = false) =
        FeedTxnEntity(
            id = "b${n++}", date = date, type = FeedType.BUY, bags = bags, rate = rate, discount = discount,
            amount = FeedCalc.buyAmount(bags, rate, discount), note = "", deleted = deleted,
            createdAt = n.toLong(), updatedAt = n.toLong()
        )
    private fun pay(date: String, type: String, amount: Double) =
        FeedTxnEntity(
            id = "p${n++}", date = date, type = type, bags = 0.0, rate = 0.0, discount = 0.0, amount = amount,
            note = "", deleted = false, createdAt = n.toLong(), updatedAt = n.toLong()
        )

    @Test fun buyAmountUsesDiscountPerBag() {
        // 50 bags at 1665 with 20 off per bag = 50 x 1645
        assertEquals(82250.0, FeedCalc.buyAmount(50.0, 1665.0, 20.0), 0.001)
    }

    @Test fun ledgerIsDateWiseWithRunningBalance() {
        val l = FeedCalc.build(
            listOf(
                pay("2026-10-12", FeedType.CASH, 10000.0),
                buy("2026-10-10", 50.0, 1665.0, 20.0),
                pay("2026-10-10", FeedType.ONLINE, 30000.0),
                buy("2026-10-12", 20.0, 1700.0, 0.0)
            )
        )
        assertEquals(2, l.rows.size)
        assertEquals("2026-10-10", l.rows[0].date)
        assertEquals(82250.0 - 30000.0, l.rows[0].balance, 0.001)
        assertEquals(52250.0 + 34000.0 - 10000.0, l.rows[1].balance, 0.001)
        assertEquals(70.0, l.totalBags, 0.001)
        assertEquals(82250.0 + 34000.0, l.totalBought, 0.001)
        assertEquals(30000.0, l.totalOnline, 0.001)
        assertEquals(10000.0, l.totalCash, 0.001)
        assertEquals(76250.0, l.outstanding, 0.001)
    }

    @Test fun deletedEntriesAreIgnored() {
        val l = FeedCalc.build(listOf(buy("2026-10-10", 10.0, 100.0, 0.0), buy("2026-10-11", 99.0, 100.0, 0.0, deleted = true)))
        assertEquals(1, l.rows.size)
        assertEquals(1000.0, l.outstanding, 0.001)
    }

    @Test fun overPaymentShowsAsAdvance() {
        val l = FeedCalc.build(listOf(buy("2026-10-10", 10.0, 100.0, 0.0), pay("2026-10-11", FeedType.CASH, 1500.0)))
        assertEquals(-500.0, l.outstanding, 0.001)
    }

    @Test fun emptyLedger() {
        val l = FeedCalc.build(emptyList())
        assertTrue(l.rows.isEmpty())
        assertEquals(0.0, l.outstanding, 0.001)
    }

    @Test fun buyValidation() {
        assertTrue(FeedCalc.validateBuy("50", "1665", "20").isEmpty())
        assertTrue(FeedCalc.validateBuy("", "1665", "").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("50", "", "").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("50", "1000", "1001").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("-5", "1000", "0").isNotEmpty())
        assertFalse(FeedCalc.validateBuy("50", "1000", "1000").isNotEmpty())
    }

    @Test fun paymentValidation() {
        assertTrue(FeedCalc.validatePayment("5000").isEmpty())
        assertTrue(FeedCalc.validatePayment("").isNotEmpty())
        assertTrue(FeedCalc.validatePayment("0").isNotEmpty())
        assertTrue(FeedCalc.validatePayment("12a").isNotEmpty())
    }

    private fun opening(date: String, amount: Double) = pay(date, FeedType.OPENING, amount)

    @Test fun oldBalanceCountsInOutstandingAndRunningBalance() {
        val l = FeedCalc.build(
            listOf(
                opening("2026-10-01", 120000.0),
                buy("2026-10-10", 10.0, 100.0, 0.0),
                pay("2026-10-11", FeedType.CASH, 20000.0)
            )
        )
        assertEquals(120000.0, l.totalOpening, 0.001)
        assertEquals(120000.0, l.rows[0].balance, 0.001)
        assertEquals(121000.0, l.rows[1].balance, 0.001)
        assertEquals(101000.0, l.outstanding, 0.001)
        assertEquals(0.0, l.totalBought - 1000.0, 0.001)
        assertEquals(10.0, l.totalBags, 0.001)
    }

    @Test fun oldBalanceCanBePaidOff() {
        val l = FeedCalc.build(listOf(opening("2026-10-01", 5000.0), pay("2026-10-02", FeedType.ONLINE, 5000.0)))
        assertEquals(0.0, l.outstanding, 0.001)
    }

    @Test fun openingValidation() {
        assertTrue(FeedCalc.validateOpening("120000").isEmpty())
        assertTrue(FeedCalc.validateOpening("").isNotEmpty())
        assertTrue(FeedCalc.validateOpening("0").isNotEmpty())
        assertTrue(FeedCalc.validateOpening("-4").isNotEmpty())
    }

    @Test fun medicineAndFeedLedgersAreSeparate() {
        val feedBuy = buy("2026-10-01", 10.0, 100.0, 0.0)
        val medBuy = buy("2026-10-01", 2.0, 50.0, 0.0).copy(category = "MEDICINE", item = "Vitamin")
        val all = listOf(feedBuy, medBuy)
        assertEquals(1000.0, FeedCalc.build(all).outstanding, 0.001)
        assertEquals(100.0, FeedCalc.build(all, "MEDICINE").outstanding, 0.001)
    }

    @Test fun changingAnEntryKeepsItsIdAndRecalculatesBalance() {
        val first = buy("2026-10-01", 10.0, 100.0, 0.0)
        val changed = first.copy(bags = 12.0, amount = FeedCalc.buyAmount(12.0, 100.0, 0.0), updatedAt = 99)
        val l = FeedCalc.build(listOf(changed))
        assertEquals(1, l.rows[0].entries.size)
        assertEquals(1200.0, l.outstanding, 0.001)
    }

    @Test fun medicineNameIsRequiredOnlyForMedicine() {
        assertTrue(FeedCalc.validateBuy("2", "50", "0", "").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("2", "50", "0", "Vitamin").isEmpty())
        assertTrue(FeedCalc.validateBuy("2", "50", "0").isEmpty())
    }

    @Test
    fun ledgerCanBeFilteredByVendor() {
        fun t(id: String, type: String, amount: Double, vendor: String) = FeedTxnEntity(
            id = id, date = "2026-10-01", type = type, bags = 0.0, rate = 0.0, discount = 0.0, amount = amount,
            note = "", deleted = false, createdAt = 1, updatedAt = 1, vendor = vendor
        )
        val all = listOf(t("1", FeedType.BUY, 1000.0, "Ram"), t("2", FeedType.BUY, 500.0, "Shyam"), t("3", FeedType.CASH, 200.0, "Ram"), t("4", FeedType.BUY, 50.0, ""))
        assertEquals(1550.0 - 200.0, FeedCalc.build(all).outstanding, 1e-9)
        assertEquals(800.0, FeedCalc.build(all, vendor = "Ram").outstanding, 1e-9)
        assertEquals(500.0, FeedCalc.build(all, vendor = "Shyam").outstanding, 1e-9)
        assertEquals(50.0, FeedCalc.build(all, vendor = "").outstanding, 1e-9)
    }

    @Test
    fun vendorRules() {
        val r = com.farmdiary.app.domain.VendorRules
        assertTrue(r.validateName("", emptyList()).isNotEmpty())
        assertTrue(r.validateName("ram", listOf("Ram")).isNotEmpty())
        assertTrue(r.validateName("Shyam", listOf("Ram")).isEmpty())
        assertTrue(r.validateChoice("", 0).isEmpty())
        assertTrue(r.validateChoice("", 2).isNotEmpty())
        assertTrue(r.validateChoice("Ram", 2).isEmpty())
    }

    @Test
    fun specialDiscountTotalsAndRules() {
        val c = com.farmdiary.app.domain.SpecialDiscountCalc
        assertEquals(250.0, c.total(100.0, 2.5), 1e-9)
        assertTrue(c.validate("100", "2", "Ram", 2).isEmpty())
        assertTrue(c.validate("100", "2", "", 2).isNotEmpty())
        assertTrue(c.validate("0", "2", "", 0).isNotEmpty())
        assertTrue(c.validate("10", "", "", 0).isNotEmpty())
        fun e(id: String, v: String, t: Double, del: Boolean = false) =
            com.farmdiary.app.data.SpecialDiscountEntity(id, "2026-10-01", v, 1.0, t, t, del, 1, 1)
        val live = c.live(listOf(e("1", "Ram", 100.0), e("2", "Ram", 50.0), e("3", "Shyam", 20.0), e("4", "Ram", 999.0, true)))
        assertEquals(170.0, c.grandTotal(live), 1e-9)
        assertEquals(150.0, c.byVendor(live).first { it.first == "Ram" }.second, 1e-9)
    }
}
