package com.farmdiary.app

import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.domain.FeedCalc
import com.farmdiary.app.domain.FeedType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FeedLedgerTest {
    private var n = 0
    private fun buy(date: String, bags: Double, rate: Double, discount: Double, deleted: Boolean = false) =
        FeedTxnEntity(
            id = "b${n++}", date = date, type = FeedType.BUY, bags = bags, rate = rate, discount = discount,
            amount = FeedCalc.buyAmount(bags, rate, discount), note = "", deleted = deleted,
            createdAt = n.toLong(), updatedAt = n.toLong()
        )
    private fun pay(date: String, type: String, amount: Double) =
        FeedTxnEntity(
            id = "p${n++}", date = date, type = type, bags = 0.0, rate = 0.0, discount = 0.0, amount = amount,
            note = "", deleted = false, createdAt = n.toLong(), updatedAt = n.toLong()
        )

    @Test fun buyAmountUsesDiscountPerBag() {
        // 50 bags at 1665 with 20 off per bag = 50 x 1645
        assertEquals(82250.0, FeedCalc.buyAmount(50.0, 1665.0, 20.0), 0.001)
    }

    @Test fun ledgerIsDateWiseWithRunningBalance() {
        val l = FeedCalc.build(
            listOf(
                pay("2026-10-12", FeedType.CASH, 10000.0),
                buy("2026-10-10", 50.0, 1665.0, 20.0),
                pay("2026-10-10", FeedType.ONLINE, 30000.0),
                buy("2026-10-12", 20.0, 1700.0, 0.0)
            )
        )
        assertEquals(2, l.rows.size)
        assertEquals("2026-10-10", l.rows[0].date)
        assertEquals(82250.0 - 30000.0, l.rows[0].balance, 0.001)
        assertEquals(52250.0 + 34000.0 - 10000.0, l.rows[1].balance, 0.001)
        assertEquals(70.0, l.totalBags, 0.001)
        assertEquals(82250.0 + 34000.0, l.totalBought, 0.001)
        assertEquals(30000.0, l.totalOnline, 0.001)
        assertEquals(10000.0, l.totalCash, 0.001)
        assertEquals(76250.0, l.outstanding, 0.001)
    }

    @Test fun deletedEntriesAreIgnored() {
        val l = FeedCalc.build(listOf(buy("2026-10-10", 10.0, 100.0, 0.0), buy("2026-10-11", 99.0, 100.0, 0.0, deleted = true)))
        assertEquals(1, l.rows.size)
        assertEquals(1000.0, l.outstanding, 0.001)
    }

    @Test fun overPaymentShowsAsAdvance() {
        val l = FeedCalc.build(listOf(buy("2026-10-10", 10.0, 100.0, 0.0), pay("2026-10-11", FeedType.CASH, 1500.0)))
        assertEquals(-500.0, l.outstanding, 0.001)
    }

    @Test fun emptyLedger() {
        val l = FeedCalc.build(emptyList())
        assertTrue(l.rows.isEmpty())
        assertEquals(0.0, l.outstanding, 0.001)
    }

    @Test fun buyValidation() {
        assertTrue(FeedCalc.validateBuy("50", "1665", "20").isEmpty())
        assertTrue(FeedCalc.validateBuy("", "1665", "").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("50", "", "").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("50", "1000", "1001").isNotEmpty())
        assertTrue(FeedCalc.validateBuy("-5", "1000", "0").isNotEmpty())
        assertFalse(FeedCalc.validateBuy("50", "1000", "1000").isNotEmpty())
    }

    @Test fun paymentValidation() {
        assertTrue(FeedCalc.validatePayment("5000").isEmpty())
        assertTrue(FeedCalc.validatePayment("").isNotEmpty())
        assertTrue(FeedCalc.validatePayment("0").isNotEmpty())
        assertTrue(FeedCalc.validatePayment("12a").isNotEmpty())
    }
}
