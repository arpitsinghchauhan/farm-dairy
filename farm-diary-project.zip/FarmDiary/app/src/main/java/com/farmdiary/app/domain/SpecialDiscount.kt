package com.farmdiary.app.domain

import com.farmdiary.app.data.SpecialDiscountEntity

/** Special discount from a feed vendor: bags bought x discount per bag. Kept apart from the feed report. */
object SpecialDiscountCalc {
    fun total(bags: Double, perBag: Double): Double = bags * perBag

    fun validate(bags: String, perBag: String, vendor: String, vendorsAdded: Int): List<String> {
        val out = mutableListOf<String>()
        out += VendorRules.validateChoice(vendor, vendorsAdded)
        if (Calc.isInvalid(bags) || Calc.isInvalid(perBag)) {
            out += "Please enter a valid quantity (numbers only, not negative)."
            return out
        }
        if (Calc.parse(bags) <= 0.0) out += "Please enter the number of new bags purchased."
        if (Calc.parse(perBag) <= 0.0) out += "Please enter the special discount per bag."
        return out
    }

    /** Live records only, newest date first. */
    fun live(all: List<SpecialDiscountEntity>): List<SpecialDiscountEntity> =
        all.filter { !it.deleted }.sortedWith(compareByDescending<SpecialDiscountEntity> { it.date }.thenByDescending { it.createdAt })

    fun grandTotal(list: List<SpecialDiscountEntity>): Double = list.sumOf { it.total }

    /** Total per vendor name ("" = no vendor), in the order the vendors first appear. */
    fun byVendor(list: List<SpecialDiscountEntity>): List<Pair<String, Double>> =
        list.groupBy { it.vendor }.map { (v, l) -> v to l.sumOf { it.total } }
}
