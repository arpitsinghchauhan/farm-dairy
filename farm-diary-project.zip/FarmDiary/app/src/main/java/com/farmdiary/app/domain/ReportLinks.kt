package com.farmdiary.app.domain

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.FarmLineEntity

/** Links between the Daily Report and Farm Records: bags used, production, mortality and stone bags. */
object ReportLinks {
    private fun txt(d: Double) = if (d == 0.0) "" else Calc.fmt(d)

    /**
     * Daily Report values follow what is written in Farm Records of the same date (when a value is written there).
     * The stone quantity is the total of the stone bags of all farms. A report that was already saved and now differs
     * is marked as not saved, so it is saved (and confirmed) again.
     */
    fun overlay(f: ReportForm, birds: List<BirdRecordEntity>): ReportForm {
        if (birds.isEmpty()) return f
        val byPos = birds.associateBy { it.position }
        var changed = false
        val lines = f.lines.mapIndexed { i, l ->
            val r = byPos[i] ?: return@mapIndexed l
            var n = l
            if (r.feedBags > 0 && Calc.parse(l.feedBags) != r.feedBags) { n = n.copy(feedBags = txt(r.feedBags)); changed = true }
            if (r.production > 0 && Calc.parse(l.trays) != r.production) { n = n.copy(trays = txt(r.production)); changed = true }
            if (r.mortality > 0 && Calc.parse(l.mortality).toInt() != r.mortality) { n = n.copy(mortality = r.mortality.toString()); changed = true }
            n
        }
        var out = f.copy(lines = lines)
        val stone = birds.sumOf { it.stoneBags }
        if (stone > 0) {
            if (Calc.parse(f.stoneQty) != stone) changed = true
            out = out.copy(stoneQty = txt(stone), stoneFromRecords = true)
        }
        return if (changed && f.createdAt != 0L) out.copy(dirty = true) else out
    }

    /** Farm Records of a date that has none yet start with the bags, production and mortality of the Daily Report. */
    fun fillFarms(forms: List<BirdFarmForm>, lines: List<FarmLineEntity>): List<BirdFarmForm> {
        if (lines.isEmpty()) return forms
        val byPos = lines.associateBy { it.position }
        return forms.mapIndexed { i, f ->
            val l = byPos[i] ?: return@mapIndexed f
            f.copy(
                feedBags = if (l.feedBags > 0) txt(l.feedBags) else f.feedBags,
                production = if (l.trays > 0) txt(l.trays) else f.production,
                mortality = if (l.mortality > 0) l.mortality.toString() else f.mortality
            )
        }
    }
}
