package com.farmdiary.app.live

import android.content.Context
import androidx.room.InvalidationTracker
import androidx.room.RoomDatabase
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.farmdiary.app.AppLog
import com.farmdiary.app.Reminders
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.sync.AccountRules
import com.farmdiary.app.sync.FarmInvite
import com.farmdiary.app.sync.FirestoreJson
import com.farmdiary.app.sync.LiveConfig
import com.farmdiary.app.sync.MergeResult
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncDelta
import com.farmdiary.app.sync.SyncFormatException
import com.farmdiary.app.sync.SyncMonths
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

/** What the Live sync card shows. */
data class LiveStatus(
    /** The Firebase project is known (built in, or typed once). */
    val projectSet: Boolean = false,
    val signedIn: Boolean = false,
    val email: String = "",
    val farmId: String = "",
    val farmName: String = "",
    val isOwner: Boolean = false,
    val busy: Boolean = false,
    val lastSync: String = "",
    val error: String = ""
) {
    val connected: Boolean get() = signedIn && farmId.isNotEmpty()
}

/**
 * Live sync between the phones of one farm through Firebase (REST, no extra library).
 * Each person signs in with their own email and password. A farm has an owner and members; the database rules let only
 * the members of a farm read and write its data, so farms never see each other. Each phone sends the records it changed
 * as small pieces and merges the pieces of the other phones; the merge keeps the newest copy of every record.
 */
object LiveSync {
    private const val PREFS = "livesync"
    private const val PAGE = 30
    private const val NEWS_ID = 2_000_000_201L
    private val whenFmt = DateTimeFormatter.ofPattern("dd MMM, h:mm a", Locale.ENGLISH)

    /** The tables whose change makes this phone send its data soon. */
    private val TABLES = arrayOf(
        "daily_report", "farm_line", "farm_stock", "extra_item", "sale_line", "egg_sale", "feed_txn", "bird_record",
        "employee", "employee_payment", "employee_attendance", "illness_record", "stock_day", "vendor", "special_discount"
    )

    private val _status = MutableStateFlow(LiveStatus())
    val status: StateFlow<LiveStatus> = _status.asStateFlow()

    private val _news = MutableStateFlow<String?>(null)
    val news: StateFlow<String?> = _news.asStateFlow()

    private val mutex = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var pushJob: Job? = null
    private var observer: InvalidationTracker.Observer? = null
    private var observed: RoomDatabase? = null

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- state ----------

    private fun project(ctx: Context): Pair<String, String>? {
        val p = prefs(ctx)
        val id = p.getString("project", "")?.takeIf { it.isNotBlank() } ?: FirebaseDefaults.PROJECT_ID
        val key = p.getString("api", "")?.takeIf { it.isNotBlank() } ?: FirebaseDefaults.API_KEY
        return if (id.isNotBlank() && key.isNotBlank()) id to key else null
    }

    private fun refreshStatus(ctx: Context, busy: Boolean = false, error: String = "") {
        val p = prefs(ctx)
        _status.value = LiveStatus(
            projectSet = project(ctx) != null,
            signedIn = !p.getString("refresh_token", "").isNullOrEmpty(),
            email = p.getString("email", "") ?: "",
            farmId = p.getString("farm_id", "") ?: "",
            farmName = p.getString("farm_name", "") ?: "",
            isOwner = p.getString("role", "") == "owner",
            busy = busy,
            lastSync = p.getString("last_sync", "") ?: "",
            error = error
        )
    }

    fun init(ctx: Context) {
        _news.value = prefs(ctx).getString("news", null)
        refreshStatus(ctx)
    }

    private fun connected(ctx: Context): Boolean {
        val p = prefs(ctx)
        return !p.getString("refresh_token", "").isNullOrEmpty() && !p.getString("farm_id", "").isNullOrEmpty() && project(ctx) != null
    }

    fun saveProject(ctx: Context, projectId: String, apiKey: String): List<String> {
        val problems = LiveConfig.problems(projectId, apiKey)
        if (problems.isNotEmpty()) return problems
        prefs(ctx).edit().putString("project", projectId.trim()).putString("api", apiKey.trim()).apply()
        refreshStatus(ctx)
        return emptyList()
    }

    fun dismissNews(ctx: Context) {
        _news.value = null
        prefs(ctx).edit().remove("news").apply()
    }

    private fun deviceId(ctx: Context): String {
        val p = prefs(ctx)
        p.getString("device", null)?.let { return it }
        val id = UUID.randomUUID().toString()
        p.edit().putString("device", id).apply()
        return id
    }

    // ---------- network ----------

    private fun request(method: String, url: String, body: String?, contentType: String, bearer: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private fun post(url: String, body: String, contentType: String, bearer: String? = null) = request("POST", url, body, contentType, bearer)

    private fun root(projectId: String) = "https://firestore.googleapis.com/v1/" + FirestoreJson.docsRoot(projectId)

    private fun explain(code: Int, text: String, what: String): String {
        val msg = FirestoreJson.errorText(text)
        return when {
            msg.contains("EMAIL_EXISTS") -> "This email already has an account. Please sign in."
            msg.contains("INVALID_LOGIN_CREDENTIALS") || msg.contains("INVALID_PASSWORD") || msg.contains("EMAIL_NOT_FOUND") ->
                "The email or password is not right."
            msg.contains("WEAK_PASSWORD") -> "The password is too weak. Use at least 6 characters."
            msg.contains("TOO_MANY_ATTEMPTS") -> "Too many tries. Please wait a few minutes."
            msg.contains("OPERATION_NOT_ALLOWED") ->
                "Email and password sign-in is not turned on in Firebase (Authentication > Sign-in method > Email/Password)."
            msg.contains("API key") || msg.contains("API_KEY") -> "The Web API key is not right."
            code == 403 || msg.contains("PERMISSION_DENIED") ->
                "Firebase refused this. You may not be a member of this farm, or the security rules are not published."
            code == 404 -> "Not found. Check the Project ID, and that the Firestore database is created."
            else -> "Could not $what (code $code${if (msg.isNotEmpty()) ": $msg" else ""})."
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is java.net.UnknownHostException, is java.net.SocketTimeoutException, is java.net.ConnectException ->
            "No internet right now. It will try again."
        else -> e.message?.takeIf { it.isNotBlank() } ?: "Something went wrong (${e.javaClass.simpleName})."
    }

    private fun isOffline(e: Exception) =
        e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException

    private fun saveSession(ctx: Context, answer: String, email: String) {
        val t = FirestoreJson.parseToken(answer) ?: throw IOException("The sign-in answer was not understood.")
        val uid = FirestoreJson.parseUid(answer)
        val e = prefs(ctx).edit()
            .putString("id_token", t.first).putString("refresh_token", t.second)
            .putLong("id_exp", System.currentTimeMillis() + t.third * 1000L)
        if (uid.isNotEmpty()) e.putString("uid", uid)
        if (email.isNotEmpty()) e.putString("email", email)
        e.apply()
    }

    private fun token(ctx: Context): String {
        val p = prefs(ctx)
        val (_, key) = project(ctx) ?: throw IOException("The Firebase project is not set.")
        val id = p.getString("id_token", "") ?: ""
        if (id.isNotEmpty() && p.getLong("id_exp", 0L) > System.currentTimeMillis() + 60_000L) return id
        val refresh = p.getString("refresh_token", "") ?: ""
        if (refresh.isEmpty()) throw IOException("Please sign in again.")
        val (code, text) = post(
            "https://securetoken.googleapis.com/v1/token?key=$key",
            FirestoreJson.refreshBody(refresh), "application/x-www-form-urlencoded"
        )
        if (code != 200) {
            if (code == 400 || code == 401) throw IOException("Your sign-in has ended. Please sign in again.")
            throw IOException(explain(code, text, "renew the sign-in"))
        }
        saveSession(ctx, text, "")
        return p.getString("id_token", "") ?: ""
    }

    private fun uid(ctx: Context) = prefs(ctx).getString("uid", "") ?: ""

    // ---------- account ----------

    private suspend fun guarded(ctx: Context, work: suspend () -> Unit): String? {
        val app = ctx.applicationContext
        refreshStatus(app, busy = true)
        return try {
            withContext(Dispatchers.IO) { work() }
            refreshStatus(app)
            null
        } catch (e: Exception) {
            if (!isOffline(e)) AppLog.e("live sync account step failed", e)
            val msg = friendly(e)
            refreshStatus(app, error = msg)
            msg
        }
    }

    /** Creates an account (when [create]) or signs in. Then finds the farm of this user, if any. */
    suspend fun signIn(ctx: Context, email: String, password: String, create: Boolean): String? {
        val problems = AccountRules.validate(email, password)
        if (problems.isNotEmpty()) return problems.joinToString(" ").also { refreshStatus(ctx, error = it) }
        val app = ctx.applicationContext
        return guarded(app) {
            val (_, key) = project(app) ?: throw IOException("The Firebase project is not set.")
            val endpoint = if (create) "signUp" else "signInWithPassword"
            val (code, text) = post(
                "https://identitytoolkit.googleapis.com/v1/accounts:$endpoint?key=$key",
                FirestoreJson.authBody(email, password), "application/json"
            )
            if (code != 200) throw IOException(explain(code, text, "sign in"))
            saveSession(app, text, email.trim())
            if (!create) findFarm(app)
        }
    }

    suspend fun resetPassword(ctx: Context, email: String): String? {
        if (email.isBlank()) return "Write your email first."
        val app = ctx.applicationContext
        return guarded(app) {
            val (_, key) = project(app) ?: throw IOException("The Firebase project is not set.")
            val (code, text) = post(
                "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$key", FirestoreJson.resetBody(email), "application/json"
            )
            if (code != 200) throw IOException(explain(code, text, "send the email"))
        }
    }

    /** Looks for the farm this user belongs to (kept in userFarms/<uid>). */
    private fun findFarm(app: Context) {
        val (pid, _) = project(app) ?: return
        val tok = token(app)
        val (code, text) = request("GET", root(pid) + "/userFarms/" + uid(app), null, "", tok)
        if (code == 404) return
        if (code != 200) throw IOException(explain(code, text, "find your farm"))
        val m = FirestoreJson.parseDocStrings(text)
        val farmId = m["farmId"] ?: return
        val role = request("GET", root(pid) + "/farms/$farmId/members/" + uid(app), null, "", tok)
        val owner = role.first == 200 && FirestoreJson.parseDocStrings(role.second)["role"] == "owner"
        useFarm(app, farmId, m["farmName"] ?: "", if (owner) "owner" else "member")
    }

    private fun useFarm(app: Context, farmId: String, name: String, role: String) {
        val p = prefs(app)
        if (p.getString("farm_id", "") != farmId) {
            p.edit().remove("last_push").remove("cursor").remove("cursor_names").apply()
        }
        p.edit().putString("farm_id", farmId).putString("farm_name", name).putString("role", role).apply()
        schedulePeriodic(app)
        scope.launch { sync(app, notify = false) }
    }

    suspend fun createFarm(ctx: Context, name: String): String? {
        if (!AccountRules.validFarmName(name)) return "Write the farm name (2 to 40 letters)."
        val app = ctx.applicationContext
        return guarded(app) {
            val (pid, _) = project(app) ?: throw IOException("The Firebase project is not set.")
            val tok = token(app)
            val uid = uid(app)
            val email = prefs(app).getString("email", "") ?: ""
            val farmId = FarmInvite.newFarmId()
            fun commit(path: String, fields: Map<String, String>, times: List<String>, new: Boolean, what: String) {
                val (c, t) = post("${root(pid)}:commit", FirestoreJson.commitDocBody(pid, path, fields, times, new), "application/json", tok)
                if (c !in 200..299) throw IOException(explain(c, t, what))
            }
            commit("farms/$farmId", mapOf("name" to name.trim(), "ownerUid" to uid), listOf("createdAt"), true, "create the farm")
            commit("farms/$farmId/members/$uid", mapOf("role" to "owner", "email" to email), listOf("joinedAt"), true, "add you to the farm")
            commit("userFarms/$uid", mapOf("farmId" to farmId, "farmName" to name.trim()), emptyList(), false, "save your farm")
            useFarm(app, farmId, name.trim(), "owner")
        }
    }

    suspend fun joinFarm(ctx: Context, inviteText: String): String? {
        val invite = FarmInvite.parse(inviteText) ?: return "This is not an invite code. It looks like LDF-..."
        val app = ctx.applicationContext
        return guarded(app) {
            val (pid, _) = project(app) ?: throw IOException("The Firebase project is not set.")
            val tok = token(app)
            val uid = uid(app)
            val email = prefs(app).getString("email", "") ?: ""
            val mine = request("GET", root(pid) + "/farms/${invite.farmId}/members/$uid", null, "", tok)
            if (mine.first != 200) {
                val (c, t) = post(
                    "${root(pid)}:commit",
                    FirestoreJson.commitDocBody(
                        pid, "farms/${invite.farmId}/members/$uid",
                        mapOf("role" to "member", "email" to email, "code" to invite.secret), listOf("joinedAt"), true
                    ),
                    "application/json", tok
                )
                if (c !in 200..299) throw IOException("This invite did not work. Ask the owner for a new one. (${explain(c, t, "join")})")
            }
            val farm = request("GET", root(pid) + "/farms/${invite.farmId}", null, "", tok)
            if (farm.first != 200) throw IOException(explain(farm.first, farm.second, "open the farm"))
            val name = FirestoreJson.parseDocStrings(farm.second)["name"] ?: "Farm"
            val (c2, t2) = post(
                "${root(pid)}:commit",
                FirestoreJson.commitDocBody(pid, "userFarms/$uid", mapOf("farmId" to invite.farmId, "farmName" to name)),
                "application/json", tok
            )
            if (c2 !in 200..299) throw IOException(explain(c2, t2, "save your farm"))
            useFarm(app, invite.farmId, name, "member")
        }
    }

    /** The owner makes an invite code for one staff member. */
    suspend fun createInvite(ctx: Context): Pair<String?, String?> {
        val app = ctx.applicationContext
        var out: String? = null
        val err = guarded(app) {
            val (pid, _) = project(app) ?: throw IOException("The Firebase project is not set.")
            val farmId = prefs(app).getString("farm_id", "") ?: ""
            val tok = token(app)
            val secret = FarmInvite.newSecret()
            val (c, t) = post(
                "${root(pid)}:commit",
                FirestoreJson.commitDocBody(pid, "farms/$farmId/invites/$secret", mapOf("createdBy" to uid(app)), listOf("createdAt"), true),
                "application/json", tok
            )
            if (c !in 200..299) throw IOException(explain(c, t, "make the invite"))
            out = FarmInvite(farmId, secret).encode()
        }
        return out to err
    }

    /** Members of the farm: user id, email and role. */
    suspend fun members(ctx: Context): List<Triple<String, String, String>> {
        val app = ctx.applicationContext
        return try {
            withContext(Dispatchers.IO) {
                val (pid, _) = project(app) ?: return@withContext emptyList()
                val farmId = prefs(app).getString("farm_id", "") ?: ""
                val (c, t) = request("GET", root(pid) + "/farms/$farmId/members?pageSize=50", null, "", token(app))
                if (c != 200) return@withContext emptyList()
                FirestoreJson.parseDocList(t).map { Triple(it.first, it.second["email"] ?: "", it.second["role"] ?: "member") }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun removeMember(ctx: Context, memberUid: String): String? {
        val app = ctx.applicationContext
        return guarded(app) {
            val (pid, _) = project(app) ?: throw IOException("The Firebase project is not set.")
            val farmId = prefs(app).getString("farm_id", "") ?: ""
            val (c, t) = request("DELETE", root(pid) + "/farms/$farmId/members/$memberUid", null, "", token(app))
            if (c !in 200..299) throw IOException(explain(c, t, "remove the member"))
        }
    }

    /** Signs out of the sync account. The data on this phone stays. */
    fun signOut(ctx: Context) {
        val app = ctx.applicationContext
        val p = prefs(app)
        val project = p.getString("project", null)
        val api = p.getString("api", null)
        val device = p.getString("device", null)
        val e = p.edit().clear()
        project?.let { e.putString("project", it) }
        api?.let { e.putString("api", it) }
        device?.let { e.putString("device", it) }
        e.apply()
        _news.value = null
        try { WorkManager.getInstance(app).cancelUniqueWork("live_sync") } catch (ex: Exception) { AppLog.e("cancel live sync work failed", ex) }
        refreshStatus(app)
    }

    // ---------- background and foreground ----------

    fun schedulePeriodic(ctx: Context) {
        if (!connected(ctx)) return
        try {
            val req = PeriodicWorkRequestBuilder<LiveSyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniquePeriodicWork("live_sync", ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (e: Exception) {
            AppLog.e("schedule live sync work failed", e)
        }
    }

    /** While the app is open: sync now, every 30 seconds, and 3 seconds after any record is saved. */
    fun startForeground(ctx: Context) {
        val app = ctx.applicationContext
        if (loop?.isActive != true) {
            loop = scope.launch {
                while (isActive) {
                    if (connected(app)) sync(app, notify = false)
                    delay(30_000)
                }
            }
        }
        if (observer == null) {
            try {
                val db = AppDatabase.get(app)
                val o = object : InvalidationTracker.Observer(TABLES) {
                    override fun onInvalidated(tables: Set<String>) { pushSoon(app) }
                }
                db.invalidationTracker.addObserver(o)
                observer = o
                observed = db
            } catch (e: Exception) {
                AppLog.e("live sync observer failed", e)
            }
        }
    }

    fun stopForeground() {
        loop?.cancel()
        loop = null
        pushJob?.cancel()
        observer?.let { o -> try { observed?.invalidationTracker?.removeObserver(o) } catch (e: Exception) { AppLog.e("live sync observer remove failed", e) } }
        observer = null
        observed = null
    }

    private fun pushSoon(app: Context) {
        pushJob?.cancel()
        pushJob = scope.launch {
            delay(3_000)
            if (connected(app)) sync(app, notify = false)
        }
    }

    // ---------- the sync ----------

    /** Sends this phone's changes and takes in the other phones' changes. Returns the error text, or null when all went well. */
    suspend fun sync(ctx: Context, notify: Boolean): String? = mutex.withLock {
        val app = ctx.applicationContext
        if (!connected(app)) return@withLock null
        refreshStatus(app, busy = true)
        var error: String? = null
        var results: List<MergeResult> = emptyList()
        try {
            results = withContext(Dispatchers.IO) { doSync(app) }
        } catch (e: Exception) {
            error = friendly(e)
            if (!isOffline(e)) AppLog.e("live sync failed", e)
        }
        val p = prefs(app)
        if (error == null) p.edit().putString("last_sync", LocalDateTime.now().format(whenFmt)).apply()
        refreshStatus(app, error = error ?: "")
        val text = newsText(results)
        if (text != null) {
            _news.value = text
            p.edit().putString("news", text).apply()
            if (notify) Reminders.show(app, NEWS_ID, "Farm data updated", text)
        }
        error
    }

    private suspend fun doSync(app: Context): List<MergeResult> {
        val (pid, _) = project(app) ?: throw IOException("The Firebase project is not set.")
        val repo = FarmRepository(AppDatabase.get(app))
        val p = prefs(app)
        val me = deviceId(app)
        val farmId = p.getString("farm_id", "") ?: ""
        val startedAt = System.currentTimeMillis()
        val tok = token(app)
        val root = root(pid)

        // 1. Send what changed here since the last time.
        val all = repo.exportAll("", startedAt, 0L, 0)
        val delta = SyncDelta.since(all, p.getLong("last_push", 0L))
        if (!SyncDelta.isEmpty(delta)) {
            val json = SyncCodec.toJson(delta)
            val pieces = if (json.length <= 600_000) {
                listOf(json)
            } else {
                SyncMonths.monthsOf(delta).map { SyncCodec.toJson(SyncMonths.forMonth(delta, it)) }.ifEmpty { listOf(json) }
            }
            pieces.forEach { piece ->
                val id = me.take(8) + "-" + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().take(6)
                val (code, text) = post(
                    "$root:commit", FirestoreJson.commitBody(pid, farmId, id, me, piece),
                    "application/json", tok
                )
                if (code !in 200..299) throw IOException(explain(code, text, "send the data"))
            }
        }
        p.edit().putLong("last_push", startedAt).apply()

        // 2. Take in what the other phones sent.
        var cursor = p.getString("cursor", "") ?: ""
        if (cursor.isEmpty()) cursor = "1970-01-01T00:00:00Z"
        var atCursor: MutableSet<String> = (p.getStringSet("cursor_names", emptySet()) ?: emptySet()).toMutableSet()
        val results = ArrayList<MergeResult>()
        for (page in 1..100) {
            val (code, text) = post(
                "$root/farms/$farmId:runQuery", FirestoreJson.queryBody(cursor, PAGE),
                "application/json", tok
            )
            if (code != 200) throw IOException(explain(code, text, "get the data"))
            val items = FirestoreJson.parseQuery(text)
            val fresh = items.filter { !(it.ts == cursor && it.name in atCursor) }
            if (fresh.isEmpty()) break
            fresh.forEach { ch ->
                if (ch.deviceId != me) {
                    try {
                        val data = SyncCodec.fromJson(ch.payload)
                        results += repo.merge(data, 0L)
                    } catch (e: SyncFormatException) {
                        AppLog.e("live sync: a piece could not be read", e)
                    }
                }
            }
            val newCursor = items.last().ts
            val namesAtNew = items.filter { it.ts == newCursor }.map { it.name }
            atCursor = if (newCursor == cursor) (atCursor + namesAtNew).toMutableSet() else namesAtNew.toMutableSet()
            cursor = newCursor
            p.edit().putString("cursor", cursor).putStringSet("cursor_names", atCursor).apply()
            if (items.size < PAGE) break
        }
        return results
    }

    /** A short line about what came in, or null when nothing changed here. */
    fun newsText(results: List<MergeResult>): String? {
        if (results.none { it.anythingChanged }) return null
        fun sum(f: (MergeResult) -> Int) = results.sumOf(f)
        val parts = listOf(
            "daily reports" to sum { it.reports.changed },
            "egg sales" to sum { it.eggSales.changed },
            "feed and medicine entries" to sum { it.feed.changed },
            "farm record days" to sum { it.birds.changed },
            "employee records" to sum { it.employees.changed + it.employeePayments.changed + it.attendance.changed },
            "illness records" to sum { it.illnesses.changed },
            "other records" to sum { it.stockDays.changed + it.vendors.changed + it.specialDiscounts.changed }
        ).filter { it.second > 0 }
        val stock = results.any { it.stockReplaced }
        val list = parts.joinToString(", ") { "${it.second} ${it.first}" } + (if (stock) (if (parts.isEmpty()) "stock" else ", stock") else "")
        return "Data updated from another phone: $list."
    }
}

/** Runs a quiet sync about every 15 minutes in the background, and tells the user when new data came in. */
class LiveSyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        LiveSync.sync(applicationContext, notify = true)
        return Result.success()
    }
}
