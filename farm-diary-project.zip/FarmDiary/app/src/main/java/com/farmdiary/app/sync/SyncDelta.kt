package com.farmdiary.app.sync

/** The part of the data that changed since a time, so live sync sends small pieces instead of everything. */
object SyncDelta {
    /**
     * Records saved or changed at or after [ts] (the time kept in each record's updatedAt). A day of daily-report lines, egg sale
     * lines or farm records goes together with its day. The Scheduler, farm name and farm count are not part of live sync.
     */
    fun since(d: SyncData, ts: Long): SyncData {
        val reports = d.reports.filter { it.updatedAt >= ts }
        val reportDates = reports.map { it.date }.toSet()
        val eggSales = d.eggSales.filter { it.updatedAt >= ts }
        val saleKeys = eggSales.map { it.date to it.buyer }.toSet()
        val birdDates = d.birdRecords.filter { it.updatedAt >= ts }.map { it.date }.toSet()
        return SyncData(
            farmName = "",
            exportedAt = d.exportedAt,
            reports = reports,
            lines = d.lines.filter { it.reportDate in reportDates },
            extras = d.extras.filter { it.reportDate in reportDates },
            eggSales = eggSales,
            saleLines = d.saleLines.filter { (it.reportDate to it.buyer) in saleKeys },
            feedTxns = d.feedTxns.filter { it.updatedAt >= ts },
            stock = d.stock?.takeIf { it.updatedAt >= ts },
            birdRecords = d.birdRecords.filter { it.date in birdDates },
            schedule = emptyList(),
            scheduleUpdatedAt = 0L,
            employees = d.employees.filter { it.updatedAt >= ts },
            employeePayments = d.employeePayments.filter { it.updatedAt >= ts },
            farmCount = 0,
            stockDays = d.stockDays.filter { it.updatedAt >= ts },
            vendors = d.vendors.filter { it.updatedAt >= ts },
            specialDiscounts = d.specialDiscounts.filter { it.updatedAt >= ts },
            attendance = d.attendance.filter { it.updatedAt >= ts },
            illnesses = d.illnesses.filter { it.updatedAt >= ts }
        )
    }

    fun isEmpty(d: SyncData): Boolean =
        d.reports.isEmpty() && d.eggSales.isEmpty() && d.feedTxns.isEmpty() && d.stock == null && d.birdRecords.isEmpty() &&
            d.employees.isEmpty() && d.employeePayments.isEmpty() && d.stockDays.isEmpty() && d.vendors.isEmpty() &&
            d.specialDiscounts.isEmpty() && d.attendance.isEmpty() && d.illnesses.isEmpty()
}
