package com.farmdiary.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.domain.Calc
import java.time.LocalDate

@Composable
fun HomeScreen(
    vm: FarmViewModel,
    onDailyReport: () -> Unit,
    onStock: () -> Unit,
    onSaved: () -> Unit,
    onLogout: () -> Unit
) {
    val date by vm.date.collectAsState()
    val context = LocalContext.current
    val farmName by vm.farmName.collectAsState()
    var editName by remember { mutableStateOf<String?>(null) }

    editName?.let { text ->
        AlertDialog(
            onDismissRequest = { editName = null },
            title = { Text("Farm name") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= 40) editName = it },
                    label = { Text("Name of your farm") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.setFarmName(text)
                    editName = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editName = null }) { Text("Cancel") } }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Selected report date, tap to change
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDatePicker(context, date) { vm.setDate(it) } },
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Report date (tap to change)", fontSize = 16.sp)
                Text(date.format(displayDateFormat), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = FarmRed)
            }
        }

        Spacer(Modifier.height(32.dp))
        FarmLogo()
        Spacer(Modifier.height(12.dp))
        Text(
            farmName.ifBlank { "FARM DIARY" },
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = FarmRed
        )
        TextButton(onClick = { editName = farmName }) {
            Text(if (farmName.isBlank()) "Set farm name" else "Change farm name", fontSize = 18.sp)
        }
        Spacer(Modifier.height(32.dp))

        Button(
            onClick = onDailyReport,
            modifier = Modifier.fillMaxWidth().height(68.dp)
        ) { Text("Daily Report", fontSize = 20.sp) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = onStock,
            modifier = Modifier.fillMaxWidth().height(68.dp)
        ) { Text("In-Stock", fontSize = 20.sp) }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onSaved) { Text("Saved Reports", fontSize = 20.sp) }
        TextButton(onClick = onLogout) { Text("Logout", fontSize = 20.sp) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmTopBar(title: String, onBack: () -> Unit) {
    TopAppBar(
        title = { Text(title) },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = FarmRed,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White
        )
    )
}

@Composable
fun SavedReportsScreen(vm: FarmViewModel, onOpen: (LocalDate) -> Unit, onBack: () -> Unit) {
    val reports by vm.reports.collectAsState()
    Scaffold(topBar = { FarmTopBar("Saved Reports", onBack) }) { pad ->
        if (reports.isEmpty()) {
            Column(Modifier.padding(pad).padding(24.dp)) {
                Text("No reports saved yet.", fontSize = 18.sp)
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }
                items(reports, key = { it.date }) { r ->
                    val d = LocalDate.parse(r.date)
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(d) },
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(d.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (r.confirmed) "Confirmed" else "Draft", fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StockScreen(vm: FarmViewModel, onBack: () -> Unit) {
    val stock by vm.stock.collectAsState()
    val message by vm.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    var feed by remember(stock) { mutableStateOf(Calc.fmt(stock.feedBags)) }
    var trays by remember(stock) { mutableStateOf(stock.blankTrays.toString()) }
    var eggTrays by remember(stock) { mutableStateOf(stock.eggTrays.toString()) }

    Scaffold(
        topBar = { FarmTopBar("In-Stock", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Feed") {
                NumField("Feed in stock (bags)", feed, { feed = it }, Modifier.fillMaxWidth())
                Text(
                    "Feed stock reduces automatically when a Daily Report is confirmed.",
                    fontSize = 16.sp
                )
            }
            SectionCard("Blank / New Trays") {
                NumField("Trays", trays, { trays = it }, Modifier.fillMaxWidth(), integer = true)
            }
            SectionCard("Egg Stock") {
                NumField("Egg stock (trays)", eggTrays, { eggTrays = it }, Modifier.fillMaxWidth(), integer = true)
                val eggs = Calc.parse(eggTrays).toLong() * Calc.EGGS_PER_TRAY
                CalcRow("Total eggs (1 tray = ${Calc.EGGS_PER_TRAY} eggs)", "$eggs eggs", bold = true)
            }
            Button(
                onClick = { vm.saveStock(feed, trays, eggTrays) },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Save Stock", fontSize = 20.sp) }
        }
    }
}
