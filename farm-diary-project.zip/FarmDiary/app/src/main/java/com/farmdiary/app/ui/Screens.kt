package com.farmdiary.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.SchedulerViewModel
import com.farmdiary.app.domain.formatTime
import com.farmdiary.app.domain.Calc
import java.time.LocalDate

@Composable
fun HomeScreen(
    vm: FarmViewModel,
    onDailyReport: () -> Unit,
    onStock: () -> Unit,
    onSaved: () -> Unit,
    onLogout: () -> Unit,
    onDashboard: () -> Unit,
    onEggSell: () -> Unit,
    onScheduler: () -> Unit,
    onFeed: () -> Unit,
    onMedicine: () -> Unit,
    onShare: () -> Unit,
    onBirds: () -> Unit,
    sched: SchedulerViewModel
) {
    val date by vm.date.collectAsState()
    val context = LocalContext.current
    val farmName by vm.farmName.collectAsState()
    var editName by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    val themeContext = androidx.compose.ui.platform.LocalContext.current

    editName?.let { text ->
        AlertDialog(
            onDismissRequest = { editName = null },
            title = { Text("Farm name") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= 40) editName = it },
                    label = { Text("Name of your farm") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.setFarmName(text)
                    editName = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editName = null }) { Text("Cancel") } }
        )
    }

    val stock by vm.stock.collectAsState()
    val tasks by sched.saved.collectAsState()
    val now = java.time.LocalTime.now()
    val hour = now.hour
    val todayTasks = tasks.filter { com.farmdiary.app.domain.occursOn(it.kind, it.dayOfWeek, it.dayOfMonth, java.time.LocalDate.now()) }
    val nextTask = todayTasks.firstOrNull { it.hour * 60 + it.minute >= now.hour * 60 + now.minute } ?: todayTasks.firstOrNull()
    val greeting = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Greeting + date pill
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("$greeting \uD83D\uDC4B", fontSize = 18.sp, color = TextLo)
                Text(
                    farmName.ifBlank { "Layer Diary" },
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextHi
                )
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Sun, modifier = Modifier.size(30.dp))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text(if (farmName.isBlank()) "Set farm name" else "Change farm name", fontSize = 18.sp) },
                        onClick = { menuOpen = false; editName = farmName }
                    )
                    DropdownMenuItem(
                        text = { Text("Share Data", fontSize = 18.sp) },
                        onClick = { menuOpen = false; onShare() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (Palette.light) "Dark theme (green)" else "Light theme (white)", fontSize = 18.sp) },
                        onClick = { menuOpen = false; Palette.setLight(themeContext, !Palette.light) }
                    )
                    DropdownMenuItem(
                        text = { Text("Logout", fontSize = 18.sp) },
                        onClick = { menuOpen = false; onLogout() }
                    )
                }
            }
        }

        // Hero card: logo + main action
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(SunBrush)
                .clickable(onClick = onDailyReport)
                .padding(18.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FarmLogo(height = 130.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Daily Report", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0B2A12))
                Text("Write today\u2019s farm entry", fontSize = 16.sp, color = Color(0xFF0B2A12).copy(alpha = 0.8f))
                Text(
                    "Open  \u2192",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF0B2A12))
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }
        }

        // Quick stock view
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatChip("\uD83C\uDF3E", Calc.fmt(stock.feedBags), "Feed bags", Modifier.weight(1f))
            StatChip("\uD83E\uDDFA", Calc.fmt(Calc.bundles(stock.blankTrays.toDouble())), "Tray bundles", Modifier.weight(1f))
            StatChip("\uD83E\uDD5A", "${stock.eggTrays}", "Egg trays", Modifier.weight(1f))
        }

        // Next scheduled task
        nextTask?.let { t ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Panel)
                    .border(1.dp, LineSoft, RoundedCornerShape(24.dp))
                    .clickable(onClick = onScheduler)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⏰", fontSize = 30.sp)
                Column(Modifier.weight(1f)) {
                    Text("Next task", fontSize = 14.sp, color = TextLo)
                    Text(t.title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextHi)
                }
                Text(formatTime(t.hour, t.minute), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
            }
        }

        // Tiles
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            BigTile("🥚", "Egg Sell", "Sale and PDF", EggBrush, dark = true, onClick = onEggSell, modifier = Modifier.weight(1f))
            BigTile("🌾", "Feed Purchase", "Buy, pay, report", LimeBrush, dark = true, onClick = onFeed, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            BigTile("💊", "Medicine Purchase", "Buy, pay, report", CoralBrush, dark = true, onClick = onMedicine, modifier = Modifier.weight(1f))
            BigTile("📦", "In-Stock", "Feed and trays", VioletBrush, dark = false, onClick = onStock, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            BigTile("⏰", "Scheduler", "Tasks and reminders", PinkBrush, dark = false, onClick = onScheduler, modifier = Modifier.weight(1f))
            BigTile("📊", "Dashboard", "This month", MintBrush, dark = true, onClick = onDashboard, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            BigTile("🐔", "Farm Records", "Birds, feed, medicines", SunBrush, dark = true, onClick = onBirds, modifier = Modifier.weight(1f))
            BigTile(
                "🗂️", "Saved Reports", "Old days",
                Brush.linearGradient(listOf(PanelHi, Panel)), dark = Palette.light, onClick = onSaved,
                modifier = Modifier.weight(1f)
            )
        }


    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmTopBar(title: String, onBack: () -> Unit) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.ExtraBold) },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Ink,
            titleContentColor = TextHi,
            navigationIconContentColor = Sun
        )
    )
}

@Composable
fun SavedReportsScreen(vm: FarmViewModel, onOpen: (LocalDate) -> Unit, onBack: () -> Unit) {
    val reports by vm.reports.collectAsState()
    Scaffold(topBar = { FarmTopBar("Saved Reports", onBack) }) { pad ->
        if (reports.isEmpty()) {
            Column(Modifier.padding(pad).padding(24.dp)) {
                Text("No reports saved yet.", fontSize = 18.sp)
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)) }
                items(reports, key = { it.date }) { r ->
                    val d = LocalDate.parse(r.date)
                    val tone = if (r.confirmed) Mint else Sun
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(d) },
                        colors = CardDefaults.cardColors(
                            containerColor = tone.copy(alpha = 0.12f).compositeOver(Panel)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, tone.copy(alpha = 0.6f))
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(d.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = tone)
                            Text(
                                if (r.confirmed) "✅ Confirmed" else "✏️ Draft",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = tone
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StockScreen(vm: FarmViewModel, onBack: () -> Unit) {
    val stock by vm.stock.collectAsState()
    val message by vm.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    var addFeed by remember { mutableStateOf("") }
    var addTrays by remember { mutableStateOf("") }
    var feed by remember(stock) { mutableStateOf(Calc.fmt(stock.feedBags)) }
    var trays by remember(stock) { mutableStateOf(Calc.fmt(Calc.bundles(stock.blankTrays.toDouble()))) }
    var eggTrays by remember(stock) { mutableStateOf(stock.eggTrays.toString()) }

    Scaffold(
        topBar = { FarmTopBar("In-Stock", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StockReportSection(vm)
            SectionCard("Feed", "\uD83C\uDF3E") {
                CalcRow("In stock now", "${Calc.fmt(stock.feedBags)} bags", bold = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    NumField("New bags bought", addFeed, { addFeed = it }, Modifier.weight(1f))
                    Button(onClick = { vm.addFeedStock(addFeed); addFeed = "" }) { Text("Add") }
                }
                Text(
                    "New bags are added to the stock. Feed used reduces the stock when a Daily Report is confirmed. Feed Purchase is separate and does not change this stock, so add bags you buy here yourself.",
                    fontSize = 16.sp
                )
                NumField("Fix stock number (only if wrong)", feed, { feed = it }, Modifier.fillMaxWidth())
            }
            SectionCard("Blank / New Trays (bundles)", "🧺") {
                CalcRow("In stock now", "${Calc.fmt(Calc.bundles(stock.blankTrays.toDouble()))} bundles", bold = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    NumField("New bundles bought", addTrays, { addTrays = it }, Modifier.weight(1f), integer = true)
                    Button(onClick = { vm.addTrayStock(addTrays); addTrays = "" }) { Text("Add") }
                }
                Text(
                    "New bundles are added to the stock. The trays used in a Daily Report are taken out of this stock when you confirm the report.",
                    fontSize = 16.sp
                )
                NumField("Fix stock in bundles (only if wrong)", trays, { trays = it }, Modifier.fillMaxWidth())
            }
            SectionCard("Egg Stock", "\uD83E\uDD5A") {
                NumField("Egg stock (trays)", eggTrays, { eggTrays = it }, Modifier.fillMaxWidth(), integer = true)
            }
            Button(
                onClick = { vm.saveStock(feed, trays, eggTrays) },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Save Stock", fontSize = 20.sp) }
        }
    }
}
