package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.data.IllnessEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.IllnessRules
import com.farmdiary.app.domain.MedicineDose
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.UUID

/** Illness and treatment records of the farms. */
class IllnessViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val records: StateFlow<List<IllnessEntity>> = repo.observeIllnesses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** The farms to choose from: the farm names of the newest Farm Records day, otherwise S.No. 1, 2, ... and "All farms". */
    val farms: StateFlow<List<String>> = repo.observeBirdRecords()
        .map { rows ->
            val latest = rows.maxByOrNull { it.date }?.date
            val names = if (latest == null) emptyList() else rows.filter { it.date == latest }.sortedBy { it.position }.map { it.name.trim() }.filter { it.isNotEmpty() }
            val base = names.ifEmpty { (1..prefs.getInt("farm_count", 2).coerceIn(1, 5)).map { "S.No. $it" } }
            base + "All farms"
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("S.No. 1", "S.No. 2", "All farms"))

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()
    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()

    fun clearMessage() { _message.value = null }
    fun clearErrors() { _errors.value = emptyList() }
    fun clearOpenPdf() { _openPdf.value = null }

    private var saving = false

    fun save(
        date: LocalDate, illness: String, age: String, farm: String, doctor: String,
        medicines: List<MedicineDose>, existing: IllnessEntity?, onSaved: () -> Unit
    ) {
        val problems = IllnessRules.validate(illness, age, farm, medicines)
        if (problems.isNotEmpty()) { _errors.value = problems; return }
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                repo.saveIllness(
                    IllnessEntity(
                        id = existing?.id ?: UUID.randomUUID().toString(),
                        date = date.toString(), illness = illness.trim(), birdAge = Calc.parse(age).toInt(),
                        farm = farm, doctor = doctor.trim(), medicines = IllnessRules.encode(medicines),
                        deleted = false, createdAt = existing?.createdAt ?: now, updatedAt = now
                    )
                )
                _errors.value = emptyList()
                _message.value = if (existing != null) "Record updated." else "Record saved."
                onSaved()
            } catch (e: Exception) {
                AppLog.e("illness save failed", e)
                _message.value = "Unable to save. Please try again."
            } finally {
                saving = false
            }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            try {
                val r = repo.getIllness(id) ?: return@launch
                repo.saveIllness(r.copy(deleted = true, updatedAt = System.currentTimeMillis()))
                _message.value = "Record deleted."
            } catch (e: Exception) {
                AppLog.e("illness delete failed", e)
                _message.value = "Unable to delete. Please try again."
            }
        }
    }

    fun downloadPdf(only: IllnessEntity? = null) {
        val farmName = prefs.getString("farm_name", "") ?: ""
        val list = if (only != null) listOf(only) else records.value
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) { PdfExporter.createIllness(getApplication(), list, farmName, LocalDate.now(), only != null) }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}
