package com.farmdiary.app.live

/**
 * The Firebase project of the app, built into the app so that farm owners and staff never type it.
 * While these are empty, the Share Data screen asks for them once (set-up for the person who runs the service).
 */
object FirebaseDefaults {
    const val PROJECT_ID = ""
    const val API_KEY = ""
}
