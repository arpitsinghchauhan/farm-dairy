package com.farmdiary.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.EmployeeEntity
import com.farmdiary.app.data.EmployeePaymentEntity
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.EmployeeCalc
import com.farmdiary.app.domain.EmployeeRules
import com.farmdiary.app.domain.MonthStatement
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

class EmployeeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))

    val employees: StateFlow<List<EmployeeEntity>> = repo.observeEmployees()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<EmployeePaymentEntity>> = repo.observeEmployeePayments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()

    private val _openPdf = MutableStateFlow<android.net.Uri?>(null)
    val openPdf: StateFlow<android.net.Uri?> = _openPdf.asStateFlow()
    fun clearOpenPdf() { _openPdf.value = null }

    fun setSalary(id: String, salary: String, onDone: () -> Unit) {
        val problems = EmployeeRules.validateSalary(salary)
        if (problems.isNotEmpty()) { _errors.value = problems; return }
        viewModelScope.launch {
            try {
                val e = repo.getEmployee(id) ?: return@launch
                repo.saveEmployee(e.copy(monthlySalary = Calc.parse(salary), updatedAt = System.currentTimeMillis()))
                _errors.value = emptyList()
                _message.value = "Salary saved: ${Calc.money(Calc.parse(salary))} per month."
                onDone()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "setSalary failed", e)
                _message.value = "Unable to save the salary. Please try again."
            }
        }
    }

    fun downloadMonthPdf(employeeName: String, statement: MonthStatement) {
        val farmName = getApplication<Application>().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
            .getString("farm_name", "") ?: ""
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.createEmployeeMonth(getApplication(), employeeName, statement, farmName)
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }

    private var saving = false

    fun clearMessage() { _message.value = null }
    fun clearErrors() { _errors.value = emptyList() }

    fun addEmployee(name: String, onDone: () -> Unit) {
        val problems = EmployeeRules.validateName(name, employees.value.map { it.name })
        if (problems.isNotEmpty()) { _errors.value = problems; return }
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val ok = repo.addEmployee(
                    EmployeeEntity(UUID.randomUUID().toString(), name.trim(), false, now, now),
                    EmployeeRules.MAX_EMPLOYEES
                )
                if (ok) {
                    _errors.value = emptyList()
                    _message.value = "Employee added: ${name.trim()}."
                    onDone()
                } else {
                    _errors.value = listOf("You can add up to ${EmployeeRules.MAX_EMPLOYEES} employees. Remove one first.")
                }
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "addEmployee failed", e)
                _message.value = "Unable to add the employee. Please try again."
            }
        }
    }

    fun rename(id: String, name: String, onDone: () -> Unit) {
        val others = employees.value.filter { it.id != id }.map { it.name }
        val problems = EmployeeRules.validateName(name, others)
        if (problems.isNotEmpty()) { _errors.value = problems; return }
        viewModelScope.launch {
            try {
                val e = repo.getEmployee(id) ?: return@launch
                repo.saveEmployee(e.copy(name = name.trim(), updatedAt = System.currentTimeMillis()))
                _errors.value = emptyList()
                _message.value = "Name changed."
                onDone()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "rename failed", e)
                _message.value = "Unable to save the name. Please try again."
            }
        }
    }

    /** Removes the employee from the list. Payments stay in the database (hidden) so a share still carries them. */
    fun removeEmployee(id: String, onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                val e = repo.getEmployee(id) ?: return@launch
                repo.saveEmployee(e.copy(deleted = true, updatedAt = System.currentTimeMillis()))
                _message.value = "Employee removed."
                onDone()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "removeEmployee failed", e)
                _message.value = "Unable to remove the employee. Please try again."
            }
        }
    }

    fun savePayment(
        employeeId: String, date: LocalDate, mode: String, amount: String, note: String,
        existing: EmployeePaymentEntity?, onSaved: () -> Unit
    ) {
        val problems = EmployeeRules.validateAmount(amount)
        if (problems.isNotEmpty()) { _errors.value = problems; return }
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val p = EmployeePaymentEntity(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    employeeId = employeeId, date = date.toString(), mode = mode,
                    amount = Calc.parse(amount), note = note.trim(), deleted = false,
                    createdAt = existing?.createdAt ?: now, updatedAt = now
                )
                repo.saveEmployeePayment(p)
                _errors.value = emptyList()
                _message.value = (if (existing != null) "Payment updated: " else "Payment saved: ") +
                    Calc.money(p.amount) + (if (mode == "ONLINE") " online." else " cash.")
                onSaved()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "savePayment failed", e)
                _message.value = "Unable to save the payment. Please try again."
            } finally {
                saving = false
            }
        }
    }

    fun deletePayment(id: String) {
        viewModelScope.launch {
            try {
                val p = repo.getEmployeePayment(id)
                if (p == null || p.deleted) { _message.value = "This entry was already deleted."; return@launch }
                repo.saveEmployeePayment(p.copy(deleted = true, updatedAt = System.currentTimeMillis()))
                _message.value = "Entry deleted."
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "deletePayment failed", e)
                _message.value = "Unable to delete. Please try again."
            }
        }
    }
}
