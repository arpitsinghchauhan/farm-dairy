package com.farmdiary.app.domain

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** File names for the PDFs: the farm name the user set, then the date, e.g. Green_Valley_Farm_17-Oct-2026.pdf */
object FileNames {
    private val dateFmt = DateTimeFormatter.ofPattern("dd-MMM-yyyy", Locale.ENGLISH)

    /** Letters (any language) and numbers only; everything else becomes one underscore. */
    fun safePart(text: String): String =
        text.trim()
            .replace(Regex("[^\\p{L}\\p{M}\\p{N}]+"), "_")
            .trim('_')
            .take(40)
            .trim('_')

    fun named(farmName: String, date: LocalDate, suffix: String, extension: String): String {
        val base = safePart(farmName).ifEmpty { "Farm_Diary" }
        val tail = if (suffix.isBlank()) "" else "_$suffix"
        return "$base${tail}_${date.format(dateFmt)}.$extension"
    }

    fun pdf(farmName: String, date: LocalDate, suffix: String = ""): String = named(farmName, date, suffix, "pdf")
}
