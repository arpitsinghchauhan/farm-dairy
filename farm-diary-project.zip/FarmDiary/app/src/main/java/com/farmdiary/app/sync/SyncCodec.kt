package com.farmdiary.app.sync

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.EmployeeEntity
import com.farmdiary.app.data.EmployeePaymentEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.data.ScheduleItemEntity
import com.farmdiary.app.data.SpecialDiscountEntity
import com.farmdiary.app.data.StockDayEntity
import com.farmdiary.app.data.VendorEntity
import com.farmdiary.app.data.SaleLineEntity
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDate

/** The file is not a Farm Diary data file, is damaged, or is from a newer version of the app. */
class SyncFormatException(message: String) : Exception(message)

/** Everything that can be shared with another phone. Login and reminders stay on each phone. */
data class SyncData(
    val farmName: String,
    val exportedAt: Long,
    val reports: List<DailyReportEntity>,
    val lines: List<FarmLineEntity>,
    val extras: List<ExtraItemEntity>,
    val eggSales: List<EggSaleEntity>,
    val saleLines: List<SaleLineEntity>,
    /** Includes deleted entries, so a delete made on one phone reaches the other phone too. */
    val feedTxns: List<FeedTxnEntity>,
    val stock: FarmStockEntity?,
    /** Farm Records. Files from older versions do not have them. */
    val birdRecords: List<BirdRecordEntity> = emptyList(),
    /** The saved Scheduler tasks (daily, weekly, monthly) and when they were last saved. 0 = never saved / not in the file. */
    val schedule: List<ScheduleItemEntity> = emptyList(),
    val scheduleUpdatedAt: Long = 0L,
    /** Employees and their payments (deleted ones included, so deletes travel too). Older files do not have them. */
    val employees: List<EmployeeEntity> = emptyList(),
    val employeePayments: List<EmployeePaymentEntity> = emptyList(),
    /** Number of farms set on Home (1 to 5). 0 = not in the file. */
    val farmCount: Int = 0,
    /** Stock left of past dates written by hand. */
    val stockDays: List<StockDayEntity> = emptyList(),
    val vendors: List<VendorEntity> = emptyList(),
    val specialDiscounts: List<SpecialDiscountEntity> = emptyList()
) {
    val feedEntryCount: Int get() = feedTxns.count { !it.deleted }
    val employeeCount: Int get() = employees.count { !it.deleted }
    val paymentCount: Int get() = employeePayments.count { !it.deleted }
    val birdDayCount: Int get() = birdRecords.map { it.date }.distinct().size
}

enum class MergeAction { ADD, UPDATE, KEEP }

object SyncMerge {
    /** The newer version wins. Same time means the same record, so the phone keeps its own. */
    fun decide(incomingUpdatedAt: Long, localUpdatedAt: Long?): MergeAction = when {
        localUpdatedAt == null -> MergeAction.ADD
        incomingUpdatedAt > localUpdatedAt -> MergeAction.UPDATE
        else -> MergeAction.KEEP
    }
}

data class Counts(val added: Int = 0, val updated: Int = 0, val kept: Int = 0) {
    fun with(action: MergeAction) = when (action) {
        MergeAction.ADD -> copy(added = added + 1)
        MergeAction.UPDATE -> copy(updated = updated + 1)
        MergeAction.KEEP -> copy(kept = kept + 1)
    }

    val changed: Int get() = added + updated
}

data class MergeResult(
    val reports: Counts,
    val eggSales: Counts,
    val feed: Counts,
    val stockReplaced: Boolean,
    val newStock: FarmStockEntity?,
    val birds: Counts = Counts(),
    /** True when the file had a newer saved Scheduler, which now replaces this phone's tasks. */
    val scheduleReplaced: Boolean = false,
    val scheduleCount: Int = 0,
    val employees: Counts = Counts(),
    val employeePayments: Counts = Counts(),
    val stockDays: Counts = Counts(),
    val vendors: Counts = Counts(),
    val specialDiscounts: Counts = Counts()
) {
    val anythingChanged: Boolean get() =
        reports.changed + eggSales.changed + feed.changed + birds.changed + employees.changed + employeePayments.changed + stockDays.changed + vendors.changed + specialDiscounts.changed > 0 || stockReplaced || scheduleReplaced
}

object SyncCodec {
    const val APP_ID = "FarmDiary"
    /** 2: egg prices are per egg (format 1 had a price per tray). */
    const val FORMAT_VERSION = 3
    private const val MAX_ROWS = 200_000

    fun toJson(d: SyncData): String {
        val root = JSONObject()
        root.put("app", APP_ID)
        root.put("format", FORMAT_VERSION)
        root.put("farmName", d.farmName)
        root.put("exportedAt", d.exportedAt)
        root.put("farmCount", d.farmCount)

        root.put("reports", JSONArray().also { a ->
            d.reports.forEach { r ->
                a.put(
                    JSONObject()
                        .put("date", r.date).put("trayQty", r.trayQty).put("trayRate", r.trayRate)
                        .put("labour", r.labour).put("light", r.light)
                        .put("stoneQty", r.stoneQty).put("stoneRate", r.stoneRate)
                        .put("eggSell", r.eggSell).put("cashReceived", r.cashReceived)
                        .put("onlineReceived", r.onlineReceived).put("waterTanks", r.waterTanks)
                        .put("confirmedTrayUsed", r.confirmedTrayUsed)
                        .put("openingTrays", r.openingTrays).put("closingTrays", r.closingTrays)
                        .put("closingEggTrays", r.closingEggTrays)
                        .put("confirmed", r.confirmed).put("confirmedFeedUsed", r.confirmedFeedUsed)
                        .put("openingFeed", r.openingFeed).put("closingFeed", r.closingFeed)
                        .put("createdAt", r.createdAt).put("updatedAt", r.updatedAt)
                        .put("eggRate", r.eggRate).put("eggNet", r.eggNet)
                )
            }
        })
        root.put("lines", JSONArray().also { a ->
            d.lines.forEach { l ->
                a.put(
                    JSONObject()
                        .put("reportDate", l.reportDate).put("position", l.position).put("name", l.name)
                        .put("feedBags", l.feedBags).put("feedRate", l.feedRate)
                        .put("trays", l.trays).put("mortality", l.mortality).put("dayNo", l.dayNo)
                )
            }
        })
        root.put("extras", JSONArray().also { a ->
            d.extras.forEach { e ->
                a.put(
                    JSONObject()
                        .put("reportDate", e.reportDate).put("position", e.position)
                        .put("name", e.name).put("amount", e.amount)
                )
            }
        })
        root.put("eggSales", JSONArray().also { a ->
            d.eggSales.forEach { e ->
                a.put(
                    JSONObject()
                        .put("date", e.date).put("cashReceived", e.cashReceived)
                        .put("onlineReceived", e.onlineReceived).put("updatedAt", e.updatedAt)
                        .put("previousBalance", e.previousBalance).put("advancePaid", e.advancePaid)
                        .put("closingBalance", e.closingBalance).put("buyer", e.buyer)
                )
            }
        })
        root.put("saleLines", JSONArray().also { a ->
            d.saleLines.forEach { s ->
                a.put(
                    JSONObject()
                        .put("reportDate", s.reportDate).put("position", s.position).put("name", s.name)
                        .put("trays", s.trays).put("rate", s.rate).put("revisedRate", s.revisedRate)
                )
            }
        })
        root.put("birdRecords", JSONArray().also { a ->
            d.birdRecords.forEach { b ->
                a.put(
                    JSONObject()
                        .put("date", b.date).put("position", b.position).put("name", b.name)
                        .put("dayNo", b.dayNo).put("feedPerBirdGrams", b.feedPerBirdGrams)
                        .put("feedBags", b.feedBags).put("stoneBags", b.stoneBags)
                        .put("production", b.production).put("mortality", b.mortality)
                        .put("breakage", b.breakage).put("waterTanks", b.waterTanks)
                        .put("medicines", b.medicines).put("notes", b.notes)
                        .put("updatedAt", b.updatedAt).put("birdsStart", b.birdsStart)
                )
            }
        })
        root.put("feedTxns", JSONArray().also { a ->
            d.feedTxns.forEach { t ->
                a.put(
                    JSONObject()
                        .put("id", t.id).put("date", t.date).put("type", t.type)
                        .put("bags", t.bags).put("rate", t.rate).put("discount", t.discount)
                        .put("amount", t.amount).put("note", t.note).put("deleted", t.deleted)
                        .put("createdAt", t.createdAt).put("updatedAt", t.updatedAt)
                        .put("category", t.category).put("item", t.item).put("vendor", t.vendor)
                )
            }
        })
        root.put("employees", JSONArray().also { a ->
            d.employees.forEach { e ->
                a.put(
                    JSONObject()
                        .put("id", e.id).put("name", e.name).put("deleted", e.deleted).put("monthlySalary", e.monthlySalary).put("mobile", e.mobile).put("aadhaar", e.aadhaar)
                        .put("createdAt", e.createdAt).put("updatedAt", e.updatedAt)
                )
            }
        })
        root.put("employeePayments", JSONArray().also { a ->
            d.employeePayments.forEach { t ->
                a.put(
                    JSONObject()
                        .put("id", t.id).put("employeeId", t.employeeId).put("date", t.date)
                        .put("mode", t.mode).put("amount", t.amount).put("note", t.note)
                        .put("deleted", t.deleted).put("createdAt", t.createdAt).put("updatedAt", t.updatedAt)
                )
            }
        })
        root.put("specialDiscounts", JSONArray().also { a ->
            d.specialDiscounts.forEach { t ->
                a.put(
                    JSONObject().put("id", t.id).put("date", t.date).put("vendor", t.vendor).put("bags", t.bags)
                        .put("discountPerBag", t.discountPerBag).put("total", t.total).put("deleted", t.deleted)
                        .put("createdAt", t.createdAt).put("updatedAt", t.updatedAt)
                )
            }
        })
        root.put("vendors", JSONArray().also { a ->
            d.vendors.forEach { v ->
                a.put(
                    JSONObject().put("id", v.id).put("category", v.category).put("name", v.name).put("deleted", v.deleted)
                        .put("createdAt", v.createdAt).put("updatedAt", v.updatedAt)
                )
            }
        })
        root.put("stockDays", JSONArray().also { a ->
            d.stockDays.forEach { t ->
                a.put(
                    JSONObject().put("date", t.date).put("feedLeft", t.feedLeft).put("trayLeft", t.trayLeft)
                        .put("eggTrays", t.eggTrays).put("updatedAt", t.updatedAt)
                )
            }
        })
        root.put("scheduleUpdatedAt", d.scheduleUpdatedAt)
        root.put("schedule", JSONArray().also { a ->
            d.schedule.forEach { t ->
                a.put(
                    JSONObject()
                        .put("title", t.title).put("details", t.details)
                        .put("hour", t.hour).put("minute", t.minute).put("reminderOn", t.reminderOn)
                        .put("kind", t.kind).put("dayOfWeek", t.dayOfWeek).put("dayOfMonth", t.dayOfMonth)
                )
            }
        })
        d.stock?.let { s ->
            root.put(
                "stock",
                JSONObject()
                    .put("feedBags", s.feedBags).put("blankTrays", s.blankTrays)
                    .put("eggTrays", s.eggTrays).put("updatedAt", s.updatedAt)
            )
        }
        return root.toString()
    }

    private fun JSONObject.list(name: String): List<JSONObject> {
        val a = optJSONArray(name) ?: return emptyList()
        if (a.length() > MAX_ROWS) throw SyncFormatException("The file is too big.")
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    private fun isoDate(s: String): String {
        LocalDate.parse(s) // throws if it is not a real date
        return s
    }

    fun fromJson(text: String): SyncData {
        try {
            // Tolerate a byte-order mark or blank space at the start, which some apps add when they save or send a file.
            val root = JSONObject(text.trim().removePrefix("\uFEFF").trim())
            val app = root.optString("app")
            val hasFarmData = listOf("reports", "lines", "eggSales", "feedTxns", "birdRecords").any { root.has(it) }
            if ((app.isNotEmpty() && app != APP_ID) || (app.isEmpty() && !hasFarmData)) {
                throw SyncFormatException("This is not a Farm Diary data file (it has no farm records in it).")
            }
            if (root.optInt("format", 0) > FORMAT_VERSION) {
                throw SyncFormatException("This file was made by a newer version of Farm Diary. Please update the app.")
            }
            val reports = root.list("reports").map {
                DailyReportEntity(
                    date = isoDate(it.getString("date")),
                    trayQty = it.optDouble("trayQty", 0.0), trayRate = it.optDouble("trayRate", 0.0),
                    labour = it.optDouble("labour", 0.0), light = it.optDouble("light", 0.0),
                    stoneQty = it.optDouble("stoneQty", 0.0), stoneRate = it.optDouble("stoneRate", 0.0),
                    eggSell = it.optDouble("eggSell", 0.0),
                    cashReceived = it.optDouble("cashReceived", 0.0),
                    onlineReceived = it.optDouble("onlineReceived", 0.0),
                    waterTanks = it.optDouble("waterTanks", 0.0),
                    confirmedTrayUsed = it.optDouble("confirmedTrayUsed", 0.0),
                    openingTrays = it.optDouble("openingTrays", 0.0),
                    closingTrays = it.optDouble("closingTrays", 0.0),
                    closingEggTrays = it.optInt("closingEggTrays", -1),
                    confirmed = it.optBoolean("confirmed", false),
                    confirmedFeedUsed = it.optDouble("confirmedFeedUsed", 0.0),
                    openingFeed = it.optDouble("openingFeed", 0.0),
                    closingFeed = it.optDouble("closingFeed", 0.0),
                    createdAt = it.optLong("createdAt", 0L), updatedAt = it.optLong("updatedAt", 0L),
                    eggRate = it.optDouble("eggRate", 0.0), eggNet = it.optDouble("eggNet", 0.0)
                )
            }
            val lines = root.list("lines").map {
                FarmLineEntity(
                    reportDate = isoDate(it.getString("reportDate")),
                    position = it.optInt("position", 0), name = it.optString("name", ""),
                    feedBags = it.optDouble("feedBags", 0.0), feedRate = it.optDouble("feedRate", 0.0),
                    trays = it.optDouble("trays", 0.0), mortality = it.optInt("mortality", 0),
                    dayNo = it.optInt("dayNo", 0)
                )
            }
            val extras = root.list("extras").map {
                ExtraItemEntity(
                    reportDate = isoDate(it.getString("reportDate")),
                    position = it.optInt("position", 0), name = it.optString("name", ""),
                    amount = it.optDouble("amount", 0.0)
                )
            }
            val eggSales = root.list("eggSales").map {
                EggSaleEntity(
                    date = isoDate(it.getString("date")),
                    cashReceived = it.optDouble("cashReceived", 0.0),
                    onlineReceived = it.optDouble("onlineReceived", 0.0),
                    updatedAt = it.optLong("updatedAt", 0L),
                    previousBalance = it.optDouble("previousBalance", 0.0),
                    advancePaid = it.optDouble("advancePaid", 0.0),
                    closingBalance = it.optDouble("closingBalance", 0.0),
                    buyer = it.optString("buyer", "")
                )
            }
            val saleLines = root.list("saleLines").map {
                SaleLineEntity(
                    reportDate = isoDate(it.getString("reportDate")),
                    position = it.optInt("position", 0), name = it.optString("name", ""),
                    trays = it.optDouble("trays", 0.0), rate = it.optDouble("rate", 0.0),
                    revisedRate = it.optDouble("revisedRate", 0.0)
                ).let { line ->
                    // Files from the first format had a price per tray; now it is per egg.
                    val perEgg = if (root.optInt("format", 1) < 2) {
                        line.copy(rate = line.rate / 30.0, revisedRate = line.revisedRate / 30.0)
                    } else {
                        line
                    }
                    // Files before format 3 stored the new price; now it is the price cut per egg.
                    if (root.optInt("format", 1) < 3 && perEgg.revisedRate > 0.0) {
                        perEgg.copy(revisedRate = Math.max(perEgg.rate - perEgg.revisedRate, 0.0))
                    } else {
                        perEgg
                    }
                }
            }
            val feed = root.list("feedTxns").map {
                val type = it.getString("type")
                if (type != "BUY" && type != "ONLINE" && type != "CASH" && type != "OPENING") {
                    throw SyncFormatException("The file has an unknown feed entry type.")
                }
                FeedTxnEntity(
                    id = it.getString("id"), date = isoDate(it.getString("date")), type = type,
                    bags = it.optDouble("bags", 0.0), rate = it.optDouble("rate", 0.0),
                    discount = it.optDouble("discount", 0.0), amount = it.optDouble("amount", 0.0),
                    note = it.optString("note", ""), deleted = it.optBoolean("deleted", false),
                    createdAt = it.optLong("createdAt", 0L), updatedAt = it.optLong("updatedAt", 0L),
                    category = if (it.optString("category", "FEED") == "MEDICINE") "MEDICINE" else "FEED",
                    item = it.optString("item", ""),
                    vendor = it.optString("vendor", "")
                )
            }
            val schedule = root.list("schedule").map {
                val kind = it.optString("kind", "DAILY")
                ScheduleItemEntity(
                    title = it.optString("title", "Farm task"), details = it.optString("details", ""),
                    hour = it.optInt("hour", 7).coerceIn(0, 23), minute = it.optInt("minute", 0).coerceIn(0, 59),
                    reminderOn = it.optBoolean("reminderOn", false),
                    kind = if (kind == "WEEKLY" || kind == "MONTHLY") kind else "DAILY",
                    dayOfWeek = it.optInt("dayOfWeek", 1).coerceIn(1, 7),
                    dayOfMonth = it.optInt("dayOfMonth", 1).coerceIn(1, 31)
                )
            }
            val birds = root.list("birdRecords").map {
                BirdRecordEntity(
                    date = isoDate(it.getString("date")), position = it.optInt("position", 0),
                    name = it.optString("name", ""), dayNo = it.optInt("dayNo", 0),
                    feedPerBirdGrams = it.optDouble("feedPerBirdGrams", 0.0),
                    feedBags = it.optDouble("feedBags", 0.0), stoneBags = it.optDouble("stoneBags", 0.0),
                    production = it.optDouble("production", 0.0), mortality = it.optInt("mortality", 0),
                    breakage = it.optInt("breakage", 0), waterTanks = it.optDouble("waterTanks", 0.0),
                    medicines = it.optString("medicines", ""), notes = it.optString("notes", ""),
                    updatedAt = it.optLong("updatedAt", 0L), birdsStart = it.optInt("birdsStart", 0)
                )
            }
            val employees = root.list("employees").map {
                EmployeeEntity(
                    id = it.getString("id"), name = it.optString("name", ""),
                    deleted = it.optBoolean("deleted", false),
                    createdAt = it.optLong("createdAt", 0L), updatedAt = it.optLong("updatedAt", 0L),
                    monthlySalary = it.optDouble("monthlySalary", 0.0),
                    mobile = it.optString("mobile", ""), aadhaar = it.optString("aadhaar", "")
                )
            }
            val employeePayments = root.list("employeePayments").map {
                val mode = it.optString("mode", "CASH")
                EmployeePaymentEntity(
                    id = it.getString("id"), employeeId = it.getString("employeeId"),
                    date = isoDate(it.getString("date")),
                    mode = if (mode == "ONLINE") "ONLINE" else "CASH",
                    amount = it.optDouble("amount", 0.0), note = it.optString("note", ""),
                    deleted = it.optBoolean("deleted", false),
                    createdAt = it.optLong("createdAt", 0L), updatedAt = it.optLong("updatedAt", 0L)
                )
            }
            val specialDiscounts = root.list("specialDiscounts").map {
                SpecialDiscountEntity(
                    id = it.getString("id"), date = isoDate(it.getString("date")), vendor = it.optString("vendor", ""),
                    bags = it.optDouble("bags", 0.0), discountPerBag = it.optDouble("discountPerBag", 0.0),
                    total = it.optDouble("total", 0.0), deleted = it.optBoolean("deleted", false),
                    createdAt = it.optLong("createdAt", 0L), updatedAt = it.optLong("updatedAt", 0L)
                )
            }
            val vendors = root.list("vendors").map {
                VendorEntity(
                    id = it.getString("id"),
                    category = it.optString("category", "FEED").let { c -> if (c == "MEDICINE" || c == "BUYER") c else "FEED" },
                    name = it.optString("name", ""), deleted = it.optBoolean("deleted", false),
                    createdAt = it.optLong("createdAt", 0L), updatedAt = it.optLong("updatedAt", 0L)
                )
            }
            val stockDays = root.list("stockDays").map {
                StockDayEntity(
                    date = isoDate(it.getString("date")), feedLeft = it.optDouble("feedLeft", -1.0),
                    trayLeft = it.optInt("trayLeft", -1), eggTrays = it.optInt("eggTrays", -1),
                    updatedAt = it.optLong("updatedAt", 0L)
                )
            }
            val stock = root.optJSONObject("stock")?.let {
                FarmStockEntity(
                    id = 1,
                    feedBags = it.optDouble("feedBags", 0.0), blankTrays = it.optInt("blankTrays", 0),
                    eggTrays = it.optInt("eggTrays", 0), updatedAt = it.optLong("updatedAt", 0L)
                )
            }
            return SyncData(
                farmName = root.optString("farmName", ""),
                exportedAt = root.optLong("exportedAt", 0L),
                reports = reports, lines = lines, extras = extras,
                eggSales = eggSales, saleLines = saleLines, feedTxns = feed, stock = stock, birdRecords = birds,
                schedule = schedule, scheduleUpdatedAt = root.optLong("scheduleUpdatedAt", 0L),
                employees = employees, employeePayments = employeePayments,
                farmCount = root.optInt("farmCount", 0).coerceIn(0, 5),
                stockDays = stockDays,
                vendors = vendors,
                specialDiscounts = specialDiscounts
            )
        } catch (e: SyncFormatException) {
            throw e
        } catch (e: JSONException) {
            throw SyncFormatException("This file is damaged or is not a Farm Diary data file. (${e.message})")
        } catch (e: java.time.format.DateTimeParseException) {
            throw SyncFormatException("This file is damaged (a date is not valid: ${e.parsedString}).")
        } catch (e: RuntimeException) {
            throw SyncFormatException("This file could not be read. (${e.javaClass.simpleName}: ${e.message})")
        }
    }
}

/** Plain-words text for the import screens. */
object SyncSummary {
    private val whenFmt = java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy, h:mm a", java.util.Locale.ENGLISH)

    /** What is inside a file that was picked, shown before anything is changed. */
    fun preview(d: SyncData, zone: java.time.ZoneId = java.time.ZoneId.systemDefault()): String {
        val from = if (d.farmName.isBlank()) "Farm Diary" else d.farmName
        val whenText = if (d.exportedAt > 0) {
            "Made on " + java.time.Instant.ofEpochMilli(d.exportedAt).atZone(zone).format(whenFmt) + "\n"
        } else {
            ""
        }
        return "From: $from\n$whenText${d.reports.size} daily reports, ${d.eggSales.size} egg sales, " +
            "${d.feedEntryCount} feed entries, ${d.birdDayCount} days of farm records, " +
            "${d.employeeCount} employees with ${d.paymentCount} payments" +
            (if (d.scheduleUpdatedAt > 0) ", ${d.schedule.size} scheduled tasks" else "") + ".\n\n" +
            "Your own records are only replaced when the file has a newer version of the same record."
    }

    private fun line(label: String, c: Counts): String =
        if (c.added + c.updated + c.kept == 0) {
            "$label: none in the file"
        } else {
            "$label: ${c.added} added, ${c.updated} updated, ${c.kept} kept (yours were the same or newer)"
        }

    fun describe(r: MergeResult): List<String> {
        val out = mutableListOf<String>()
        out += line("Daily reports", r.reports)
        out += line("Egg sales", r.eggSales)
        out += line("Feed entries", r.feed)
        out += line("Farm records (days)", r.birds)
        out += line("Employees", r.employees)
        out += line("Employee payments", r.employeePayments)
        out += line("Stock of past dates", r.stockDays)
        out += line("Vendors", r.vendors)
        out += line("Special discounts", r.specialDiscounts)
        out += if (r.scheduleReplaced) {
            "Scheduler: the file had a newer schedule, so this phone now has its ${r.scheduleCount} tasks."
        } else {
            "Scheduler: kept yours (the file had none, or yours was the same or newer)."
        }
        val s = r.newStock
        out += if (r.stockReplaced && s != null) {
            "Stock: the file had newer stock, so it is now ${s.feedBags.let { if (it == Math.floor(it)) it.toLong().toString() else it.toString() }} " +
                "feed bags, ${s.blankTrays / 100.0} tray bundles and ${s.eggTrays} egg trays. Please check In-Stock."
        } else {
            "Stock: kept yours (it was the same or newer)."
        }
        return out
    }
}
