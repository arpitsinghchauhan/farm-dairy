package com.farmdiary.app.domain

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.SaleLineEntity

/** Stock at the end of one confirmed report day. */
data class StockDayRow(
    val date: String,
    val feedLeft: Double,
    val feedUsed: Double,
    val trayBundlesLeft: Double,
    val trayBundlesUsed: Double,
    /** Null for old reports that never recorded the egg stock. */
    val eggTrays: Int?
)

object StockHistory {
    /** One row per confirmed report, newest first. Drafts are not part of the stock history. */
    fun rows(reports: List<DailyReportEntity>): List<StockDayRow> =
        reports.filter { it.confirmed }
            .sortedByDescending { it.date }
            .map {
                StockDayRow(
                    date = it.date,
                    feedLeft = it.closingFeed,
                    feedUsed = it.confirmedFeedUsed,
                    trayBundlesLeft = Calc.bundles(it.closingTrays),
                    trayBundlesUsed = Calc.bundles(it.confirmedTrayUsed),
                    eggTrays = if (it.closingEggTrays >= 0) it.closingEggTrays else null
                )
            }

    /** The stock figures of the last confirmed report on or before [date] (ISO yyyy-MM-dd), or null if there is none. */
    fun on(reports: List<DailyReportEntity>, date: String): StockDayRow? =
        rows(reports).firstOrNull { it.date <= date }
}

/** One saved egg sale day for the selling history. */
data class EggSaleDayRow(
    val date: String,
    val traysSold: Double,
    val total: Double,
    val cash: Double,
    val online: Double,
    val previous: Double,
    val advance: Double,
    val balance: Double
) {
    val isNil: Boolean get() = total <= 0.0
}

object EggSaleHistory {
    /** One row per saved egg sale, newest date first. */
    fun build(sales: List<EggSaleEntity>, lines: List<SaleLineEntity>): List<EggSaleDayRow> {
        val byDate = lines.groupBy { it.reportDate }
        return sales.sortedByDescending { it.date }.map { s ->
            val l = byDate[s.date] ?: emptyList()
            EggSaleDayRow(
                date = s.date,
                traysSold = l.sumOf { it.trays },
                total = l.sumOf { it.amount },
                cash = s.cashReceived,
                online = s.onlineReceived,
                previous = s.previousBalance,
                advance = s.advancePaid,
                balance = s.closingBalance
            )
        }
    }
}
