package com.farmdiary.app.domain

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.SaleLineEntity

/** Stock at the end of one confirmed report day. */
data class StockDayRow(
    val date: String,
    val feedLeft: Double,
    val feedUsed: Double,
    val trayBundlesLeft: Double,
    val trayBundlesUsed: Double,
    /** Null for old reports that never recorded the egg stock. */
    val eggTrays: Int?
)

object StockHistory {
    /** One row per confirmed report, newest first. Drafts are not part of the stock history. */
    fun rows(reports: List<DailyReportEntity>): List<StockDayRow> =
        reports.filter { it.confirmed }
            .sortedByDescending { it.date }
            .map {
                StockDayRow(
                    date = it.date,
                    feedLeft = it.closingFeed,
                    feedUsed = it.confirmedFeedUsed,
                    trayBundlesLeft = Calc.bundles(it.closingTrays),
                    trayBundlesUsed = Calc.bundles(it.confirmedTrayUsed),
                    eggTrays = if (it.closingEggTrays >= 0) it.closingEggTrays else null
                )
            }

    /** The stock record confirmed on exactly [date] (ISO yyyy-MM-dd), or null if that day has none. */
    fun onExact(reports: List<DailyReportEntity>, date: String): StockDayRow? =
        rows(reports).firstOrNull { it.date == date }

    /** The stock figures of the last confirmed report on or before [date] (ISO yyyy-MM-dd), or null if there is none. */
    fun on(reports: List<DailyReportEntity>, date: String): StockDayRow? =
        rows(reports).firstOrNull { it.date <= date }
}

/** One saved egg sale day for the selling history. */
data class EggSaleDayRow(
    val date: String,
    val traysSold: Double,
    val total: Double,
    val cash: Double,
    val online: Double,
    val previous: Double,
    val advance: Double,
    val balance: Double,
    /** False for a day with no saved sale: it counts as zero and carries the balance of the day before. */
    val recorded: Boolean = true
) {
    val isNil: Boolean get() = total <= 0.0
}

object EggSaleHistory {
    /**
     * One row for every day from the first saved sale up to [today], newest first.
     * A day with no saved sale is shown as zero and keeps the balance of the day before.
     */
    fun build(sales: List<EggSaleEntity>, lines: List<SaleLineEntity>, today: java.time.LocalDate = java.time.LocalDate.now()): List<EggSaleDayRow> {
        if (sales.isEmpty()) return emptyList()
        val byDate = lines.groupBy { it.reportDate }
        val saved = sales.associateBy { it.date }
        val first = java.time.LocalDate.parse(sales.minOf { it.date })
        val last = maxOf(today, java.time.LocalDate.parse(sales.maxOf { it.date }))
        val out = ArrayList<EggSaleDayRow>()
        var balance = 0.0
        var day = first
        while (!day.isAfter(last)) {
            val key = day.toString()
            val s = saved[key]
            if (s != null) {
                val l = byDate[key] ?: emptyList()
                balance = s.closingBalance
                out += EggSaleDayRow(
                    date = key,
                    traysSold = l.sumOf { it.trays },
                    total = l.sumOf { it.amount },
                    cash = s.cashReceived,
                    online = s.onlineReceived,
                    previous = s.previousBalance,
                    advance = s.advancePaid,
                    balance = s.closingBalance
                )
            } else {
                out += EggSaleDayRow(key, 0.0, 0.0, 0.0, 0.0, balance, 0.0, balance, recorded = false)
            }
            day = day.plusDays(1)
        }
        return out.asReversed()
    }
}
