package com.farmdiary.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.SpecialDiscountViewModel
import com.farmdiary.app.data.SpecialDiscountEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.SpecialDiscountCalc
import java.time.LocalDate

/** Special discount from feed vendors: date, vendor, new bags and discount per bag, with a total and a PDF. */
@Composable
fun SpecialDiscountScreen(vm: SpecialDiscountViewModel, onBack: () -> Unit) {
    val records by vm.records.collectAsState()
    val vendors by vm.vendors.collectAsState()
    val errors by vm.errors.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    OpenPdfEffect(pdfUri) { vm.clearOpenPdf() }
    DisposableEffect(Unit) { onDispose { vm.clearErrors() } }

    var date by remember { mutableStateOf(LocalDate.now()) }
    var vendor by remember { mutableStateOf("") }
    var bags by remember { mutableStateOf("") }
    var perBag by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<SpecialDiscountEntity?>(null) }
    val clearForm = { bags = ""; perBag = ""; editing = null }
    val total = SpecialDiscountCalc.total(Calc.parse(bags), Calc.parse(perBag))

    Scaffold(
        topBar = { FarmTopBar("Special Discount", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DatePill(date) { date = it; vm.clearErrors() }

            SectionCard(if (editing != null) "Change this entry" else "Special discount", "🎁") {
                if (vendors.isEmpty()) {
                    Text("Add vendors with the gear icon on the Feed Purchase page.", fontSize = 14.sp, color = TextLo)
                } else {
                    ChoiceDropdown(
                        label = "Vendor",
                        selectedText = vendor,
                        options = vendors.map { it.name to it.name },
                        onSelect = { vendor = it; vm.clearErrors() }
                    )
                }
                NumField("New bags purchased", bags, { bags = it; vm.clearErrors() }, Modifier.fillMaxWidth())
                NumField("Special discount per bag", perBag, { perBag = it; vm.clearErrors() }, Modifier.fillMaxWidth())
            }

            SectionCard("Total", "🧮") {
                CalcRow("Special discount", Calc.money(if (total > 0) total else 0.0), bold = true)
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") { errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) } }
            }

            GradientButton(
                text = if (editing != null) "✅  Update" else "✅  Save",
                onClick = { vm.save(date, vendor, bags, perBag, editing) { clearForm() } },
                modifier = Modifier.fillMaxWidth()
            )
            if (editing != null) {
                TextButton(onClick = { clearForm(); vm.clearErrors() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel change", fontSize = 18.sp)
                }
            }

            val grand = SpecialDiscountCalc.grandTotal(records)
            AccentCard("All special discounts", "📒", SunBrush, Sun) {
                CalcRow("Total till now", Calc.money(grand), bold = true)
                val perVendor = SpecialDiscountCalc.byVendor(records)
                if (perVendor.size > 1 || perVendor.any { it.first.isNotBlank() }) {
                    perVendor.forEach { (v, t) -> CalcRow(v.ifBlank { "No vendor" }, Calc.money(t)) }
                }
                if (records.isEmpty()) Text("Nothing saved yet.", fontSize = 16.sp, color = TextLo)
                records.forEach { r ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(LocalDate.parse(r.date).format(displayDateFormat), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(
                                (if (r.vendor.isNotBlank()) "${r.vendor}: " else "") + "${Calc.fmt(r.bags)} bags x ${Calc.fmt(r.discountPerBag)}",
                                fontSize = 15.sp, color = TextLo
                            )
                        }
                        Text(Calc.money(r.total), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            editing = r; date = LocalDate.parse(r.date); vendor = r.vendor
                            bags = Calc.fmt(r.bags); perBag = Calc.fmt(r.discountPerBag); vm.clearErrors()
                        }) { Text("Change", fontSize = 15.sp) }
                        IconButton(onClick = { vm.delete(r.id); if (editing?.id == r.id) clearForm() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete this entry")
                        }
                    }
                }
            }

            GradientButton(
                text = "📄  Download PDF",
                onClick = { vm.downloadPdf() },
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
