package com.farmdiary.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FeedMakerViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FeedMakerCalc
import com.farmdiary.app.domain.MixResult

private fun two(v: Double) = Calc.fmt(Math.round(v * 100) / 100.0)

/** Feed Maker: write the ingredients with their percent, say how many 50 kg bags are used, and see each ingredient in kg and bags. */
@Composable
fun FeedMakerScreen(vm: FeedMakerViewModel, onBack: () -> Unit) {
    val items by vm.items.collectAsState()
    val share by vm.share.collectAsState()
    val round by vm.round.collectAsState()
    val bags by vm.bags.collectAsState()
    val farms by vm.farms.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    OpenPdfEffect(pdfUri) { vm.clearOpenPdf() }

    val total = FeedMakerCalc.totalPercent(items)
    val problems = FeedMakerCalc.validate(items)
    val ownShare = if (share.isBlank()) 100.0 else Calc.parse(share)
    val shareBad = Calc.isInvalid(share) || ownShare > 100.0

    Scaffold(
        topBar = { FarmTopBar("Feed Maker", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Feed composition", "🧪") {
                Text("Write up to ${FeedMakerCalc.MAX_ITEMS} ingredients with their percent. Together they must make 100 %.", fontSize = 14.sp, color = TextLo)
                items.forEachIndexed { i, it ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = it.name,
                            onValueChange = { v -> if (v.length <= 30) vm.editItem(i, items[i].copy(name = v)) },
                            label = { Text("Ingredient ${i + 1}") },
                            singleLine = true,
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
                                focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
                                focusedLabelColor = Primary, unfocusedLabelColor = TextLo
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        NumField("%", it.percent, { v -> vm.editItem(i, items[i].copy(percent = v)) }, Modifier.weight(0.6f))
                        IconButton(onClick = { vm.removeItem(i) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove ingredient ${i + 1}")
                        }
                    }
                }
                if (items.size < FeedMakerCalc.MAX_ITEMS) {
                    OutlinedButton(onClick = { vm.addItem() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add ingredient")
                    }
                }
                CalcRow("Total", "${two(total)} %", bold = true, error = Math.abs(total - 100.0) > 0.005)
            }

            SectionCard("Feed to make", "⚖️") {
                NumField(
                    "Made on the farm (% of the feed)", share, { vm.setShare(it) }, Modifier.fillMaxWidth()
                )
                Text(
                    if (shareBad) "Write a percent from 0 to 100."
                    else if (ownShare < 100.0) "The other ${two(100.0 - ownShare)} % is bought full feed."
                    else "100 % means all the feed is made from your composition.",
                    fontSize = 14.sp, color = TextLo
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Switch(checked = round, onCheckedChange = { vm.setRound(it) })
                    Text("Round each ingredient to the nearest 5 kg", fontSize = 16.sp, modifier = Modifier.weight(1f))
                }
                farms.forEach { f ->
                    NumField("$f: bags used (50 kg)", bags[f] ?: "", { vm.setBags(f, it) }, Modifier.fillMaxWidth())
                }
            }

            val results = if (problems.isNotEmpty() || shareBad) emptyList() else farms.mapNotNull { f ->
                val b = Calc.parse(bags[f] ?: "")
                if (b > 0.0 && !Calc.isInvalid(bags[f] ?: "")) f to FeedMakerCalc.split(items, b, ownShare, round) else null
            }

            if (problems.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") { problems.forEach { Text(it, color = androidx.compose.material3.MaterialTheme.colorScheme.error) } }
            }

            results.forEach { (name, r) -> ResultCard(name, r) }

            if (results.size > 1) {
                val sums = FeedMakerCalc.split(items, results.sumOf { it.second.totalBags }, ownShare, round)
                ResultCard("All farms", sums)
            }
            if (results.isNotEmpty()) {
                GradientButton(
                    text = "📄  Download PDF",
                    onClick = { vm.downloadPdf(results) },
                    brush = MintBrush,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ResultCard(title: String, r: MixResult) {
    AccentCard("$title: ${two(r.totalBags)} bags of feed", "🥣", MintBrush, Mint) {
        if (r.fullFeedBags > 0.0) CalcRow("Full feed (bought)", "${two(r.fullFeedKg)} kg = ${two(r.fullFeedBags)} bags", bold = true)
        r.rows.forEach {
            CalcRow("${it.name} (${Calc.fmt(it.percent)} %)", "${two(it.kg)} kg = ${two(it.bags)} bags")
        }
    }
}
