package com.farmdiary.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FeedMakerViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FeedMakerCalc
import com.farmdiary.app.domain.FeedMakerStore
import com.farmdiary.app.domain.MixResult

private fun two(v: Double) = Calc.fmt(Math.round(v * 100) / 100.0)

/** Feed Maker: write the ingredients with their percent, say how many 50 kg bags are used, and see each ingredient in kg and bags. */
@Composable
fun FeedMakerScreen(vm: FeedMakerViewModel, onBack: () -> Unit) {
    val items by vm.items.collectAsState()
    val share by vm.share.collectAsState()
    val round by vm.round.collectAsState()
    val fullPrice by vm.fullPrice.collectAsState()
    val bags by vm.bags.collectAsState()
    val farms by vm.farms.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    OpenPdfEffect(pdfUri) { vm.clearOpenPdf() }

    val templates by vm.templates.collectAsState()
    val records by vm.records.collectAsState()
    val recordDate by vm.recordDate.collectAsState()
    val templateName by vm.templateName.collectAsState()
    var showTemplates by remember { mutableStateOf(false) }
    var naming by remember { mutableStateOf<String?>(null) } // "template" or "record"
    var nameText by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf("") }
    var removeRecordId by remember { mutableStateOf<String?>(null) }

    val total = FeedMakerCalc.totalPercent(items)
    val problems = FeedMakerCalc.validate(items)
    val ownShare = if (share.isBlank()) 100.0 else Calc.parse(share)
    val shareBad = Calc.isInvalid(share) || ownShare > 100.0

    if (showTemplates) {
        AlertDialog(
            onDismissRequest = { showTemplates = false },
            title = { Text("Saved feed templates") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (templates.isEmpty()) Text("Nothing saved yet. Write a composition and tap \"Save as template\".", fontSize = 15.sp)
                    templates.forEach { t ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { vm.useTemplate(t); showTemplates = false }, modifier = Modifier.weight(1f)) {
                                Text(t.title + " (" + t.items.size + " items)", fontSize = 17.sp)
                            }
                            IconButton(onClick = { vm.removeTemplate(t.title) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove ${t.title}")
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTemplates = false }) { Text("Close") } }
        )
    }
    if (naming != null) {
        val isRecord = naming == "record"
        AlertDialog(
            onDismissRequest = { naming = null },
            title = { Text(if (isRecord) "Save record of ${recordDate.format(displayDateFormat)}" else "Save as template") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameText,
                        onValueChange = { if (it.length <= FeedMakerStore.MAX_TITLE) { nameText = it; nameError = "" } },
                        label = { Text("Name") },
                        singleLine = true
                    )
                    if (nameError.isNotEmpty()) Text(nameError, color = androidx.compose.material3.MaterialTheme.colorScheme.error, fontSize = 14.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val err = if (isRecord) vm.saveRecord(nameText, farms.map { it to (bags[it] ?: "") }) else vm.saveTemplate(nameText)
                    if (err == null) naming = null else nameError = err
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { naming = null }) { Text("Cancel") } }
        )
    }
    removeRecordId?.let { id ->
        AlertDialog(
            onDismissRequest = { removeRecordId = null },
            title = { Text("Remove this record?") },
            confirmButton = { TextButton(onClick = { vm.removeRecord(id); removeRecordId = null }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { removeRecordId = null }) { Text("Cancel") } }
        )
    }

    Scaffold(
        topBar = {
            FarmTopBar("Feed Maker", onBack, actions = {
                IconButton(onClick = { showTemplates = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Saved feed templates", tint = Primary)
                }
            })
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Feed composition", "🧪") {
                if (templateName.isNotBlank()) Text("Template: $templateName", fontSize = 14.sp, color = TextLo)
                Text("Write up to ${FeedMakerCalc.MAX_ITEMS} ingredients with their percent. Together they must make 100 %.", fontSize = 14.sp, color = TextLo)
                items.forEachIndexed { i, it ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = it.name,
                            onValueChange = { v -> if (v.length <= 30) vm.editItem(i, items[i].copy(name = v)) },
                            label = { Text("Ingredient ${i + 1}") },
                            singleLine = true,
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
                                focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
                                focusedLabelColor = Primary, unfocusedLabelColor = TextLo
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { vm.removeItem(i) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove ingredient ${i + 1}")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("Percent (%)", it.percent, { v -> vm.editItem(i, items[i].copy(percent = v)) }, Modifier.weight(1f))
                        NumField("Rate (50kg)", it.rate, { v -> vm.editItem(i, items[i].copy(rate = v)) }, Modifier.weight(1f))
                    }
                    if (it.rate.isNotBlank() && !Calc.isInvalid(it.rate) && Calc.parse(it.rate) > 0.0) {
                        Text("= Rs ${two(Calc.parse(it.rate) / FeedMakerCalc.BAG_KG)} per kg", fontSize = 14.sp, color = TextLo)
                    }
                }
                if (items.size < FeedMakerCalc.MAX_ITEMS) {
                    OutlinedButton(onClick = { vm.addItem() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add ingredient")
                    }
                }
                CalcRow("Total", "${two(total)} %", bold = true, error = Math.abs(total - 100.0) > 0.005)
                OutlinedButton(
                    onClick = { nameText = templateName; nameError = ""; naming = "template" },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save as template") }
            }

            SectionCard("Feed to make", "⚖️") {
                NumField(
                    "Made on the farm (% of the feed)", share, { vm.setShare(it) }, Modifier.fillMaxWidth()
                )
                Text(
                    if (shareBad) "Write a percent from 0 to 100."
                    else if (ownShare < 100.0) "The other ${two(100.0 - ownShare)} % is bought full feed."
                    else "100 % means all the feed is made from your composition.",
                    fontSize = 14.sp, color = TextLo
                )
                if (ownShare < 100.0 && !shareBad) {
                    NumField("Full feed price of 1 bag (Rs)", fullPrice, { vm.setFullPrice(it) }, Modifier.fillMaxWidth())
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Switch(checked = round, onCheckedChange = { vm.setRound(it) })
                    Text("Round each ingredient to the nearest 5 kg", fontSize = 16.sp, modifier = Modifier.weight(1f))
                }
                farms.forEach { f ->
                    NumField("$f: bags used (50 kg)", bags[f] ?: "", { vm.setBags(f, it) }, Modifier.fillMaxWidth())
                }
            }

            val results = if (problems.isNotEmpty() || shareBad) emptyList() else farms.mapNotNull { f ->
                val b = Calc.parse(bags[f] ?: "")
                if (b > 0.0 && !Calc.isInvalid(bags[f] ?: "")) f to FeedMakerCalc.split(items, b, ownShare, round, Calc.parse(fullPrice)) else null
            }

            if (problems.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") { problems.forEach { Text(it, color = androidx.compose.material3.MaterialTheme.colorScheme.error) } }
            }

            results.forEach { (name, r) -> ResultCard(name, r) }

            if (results.size > 1) {
                val sums = FeedMakerCalc.split(items, results.sumOf { it.second.totalBags }, ownShare, round, Calc.parse(fullPrice))
                ResultCard("All farms", sums)
            }
            if (results.isNotEmpty()) {
                GradientButton(
                    text = "📄  Download PDF",
                    onClick = { vm.downloadPdf(results) },
                    brush = MintBrush,
                    modifier = Modifier.fillMaxWidth()
                )
                SectionCard("Save today's feed", "💾") {
                    Text("Keep this feed as a record. You can save several feeds on the same day.", fontSize = 14.sp, color = TextLo)
                    DatePill(recordDate) { vm.setRecordDate(it) }
                    GradientButton(
                        text = "Save record",
                        onClick = { nameText = vm.suggestRecordTitle(); nameError = ""; naming = "record" },
                        brush = SunBrush,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            SectionCard("Saved records", "📚") {
                if (records.isEmpty()) Text("No records saved yet.", fontSize = 14.sp, color = TextLo)
                FeedMakerStore.byDate(records).asReversed().forEach { (date, list) ->
                    Text(java.time.LocalDate.parse(date).format(displayDateFormat), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Sun)
                    list.forEach { rec ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val bagsText = rec.results().joinToString(", ") { "${it.first}: ${two(it.second.totalBags)} bags" }
                            Text("${rec.title}  -  $bagsText", fontSize = 15.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { removeRecordId = rec.id }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove ${rec.title}")
                            }
                        }
                    }
                }
                if (records.isNotEmpty()) {
                    OutlinedButton(onClick = { vm.downloadRecordsPdf() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Download all records (PDF)")
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultCard(title: String, r: MixResult) {
    AccentCard("$title: ${two(r.totalBags)} bags of feed", "🥣", MintBrush, Mint) {
        if (r.fullFeedBags > 0.0) CalcRow("Full feed (bought)", "${two(r.fullFeedKg)} kg = ${two(r.fullFeedBags)} bags", bold = true)
        r.rows.forEach {
            CalcRow("${it.name} (${Calc.fmt(it.percent)} %)", "${two(it.kg)} kg = ${two(it.bags)} bags")
        }
        if (r.hasCost) {
            CalcRow("Cost of all the feed", Calc.money(Math.round(r.totalCost * 100) / 100.0))
            CalcRow("Cost of 1 kg of feed", Calc.money(Math.round(r.costPerKg * 100) / 100.0), bold = true)
            if (r.rows.any { it.rate <= 0.0 }) {
                Text("Some ingredients have no rate, so their cost is counted as zero.", fontSize = 14.sp, color = TextLo)
            }
        }
    }
}
