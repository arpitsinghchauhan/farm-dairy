package com.farmdiary.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import android.content.Context
import android.net.Uri
import com.farmdiary.app.domain.BirdDaySummary
import com.farmdiary.app.domain.BirdFarmForm
import com.farmdiary.app.domain.BirdRecords
import com.farmdiary.app.domain.MAX_BIRD_FARMS
import com.farmdiary.app.domain.MAX_MEDICINES
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Farm Records: the birds' information of up to 5 farms, saved per date. */
class BirdViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private var keySeed = 1L

    /** Every saved date, newest first (the history list). */
    val history: StateFlow<List<BirdDaySummary>> = repo.observeBirdRecords()
        .map { BirdRecords.summarize(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** All saved farm records (for the monthly bird count). */
    val records: StateFlow<List<com.farmdiary.app.data.BirdRecordEntity>> = repo.observeBirdRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()
    fun clearOpenPdf() { _openPdf.value = null }

    private val _date = MutableStateFlow(LocalDate.now())
    val date: StateFlow<LocalDate> = _date.asStateFlow()

    private val _farms = MutableStateFlow(listOf(BirdFarmForm(0)))
    val farms: StateFlow<List<BirdFarmForm>> = _farms.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()

    private var saving = false

    fun clearMessage() { _message.value = null }

    /** Opens the screen on a date (the report date chosen on Home, or a day picked in the history). */
    fun open(date: LocalDate) = setDate(date)

    fun setDate(date: LocalDate) {
        _date.value = date
        viewModelScope.launch { load(date) }
    }

    private suspend fun load(date: LocalDate) {
        _errors.value = emptyList()
        val key = date.toString()
        val saved = repo.getBirdRecords(key)
        val forms = if (saved.isNotEmpty()) {
            BirdRecords.toForms(saved) { keySeed++ }
        } else {
            val prev = repo.getLatestBirdDayBefore(key)
            if (prev == null) {
                emptyList()
            } else {
                BirdRecords.prefill(prev.second, LocalDate.parse(prev.first), date) { keySeed++ }
            }
        }
        // The date may have been changed again while this was loading.
        if (_date.value == date) {
            _farms.value = forms.ifEmpty { listOf(BirdFarmForm(keySeed++)) }
        }
    }

    private fun change(key: Long, transform: (BirdFarmForm) -> BirdFarmForm) {
        _errors.value = emptyList()
        _farms.update { list -> list.map { if (it.key == key) transform(it) else it } }
    }

    fun edit(key: Long, transform: (BirdFarmForm) -> BirdFarmForm) = change(key, transform)

    fun addFarm() {
        if (_farms.value.size >= MAX_BIRD_FARMS) return
        _farms.update { it + BirdFarmForm(keySeed++) }
    }

    fun removeFarm(key: Long) {
        _farms.update { list ->
            val left = list.filter { it.key != key }
            left.ifEmpty { listOf(BirdFarmForm(keySeed++)) }
        }
    }

    fun addMedicine(key: Long) = change(key) {
        if (it.medicines.size >= MAX_MEDICINES) it else it.copy(medicines = it.medicines + "")
    }

    fun editMedicine(key: Long, index: Int, text: String) = change(key) { f ->
        if (index !in f.medicines.indices || text.length > 60) {
            f
        } else {
            f.copy(medicines = f.medicines.mapIndexed { i, m -> if (i == index) text else m })
        }
    }

    fun removeMedicine(key: Long, index: Int) = change(key) { f ->
        f.copy(medicines = f.medicines.filterIndexed { i, _ -> i != index })
    }

    /** Saves what is on the screen, then makes the PDF of that date from the saved data. */
    fun saveAndDownloadPdf() = save { downloadPdf(_date.value) }

    /** PDF of an already saved date (used by the history list too). */
    fun downloadPdf(date: LocalDate) {
        viewModelScope.launch {
            val rows = repo.getBirdRecords(date.toString())
            if (rows.isEmpty()) {
                _message.value = "There are no farm records on this date to make a PDF."
                return@launch
            }
            val farmName = prefs.getString("farm_name", "") ?: ""
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.createBirdDay(getApplication(), date, rows, farmName)
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }

    /** Removes all farm records of a date. */
    fun deleteDay(date: LocalDate) {
        viewModelScope.launch {
            try {
                repo.saveBirdDay(date.toString(), emptyList())
                if (_date.value == date) load(date)
                _message.value = "Records of this day were deleted."
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "delete farm records failed", e)
                _message.value = "Unable to delete. Please try again."
            }
        }
    }

    fun save(onSaved: (() -> Unit)? = null) {
        val farms = _farms.value
        val problems = BirdRecords.validate(farms)
        if (problems.isNotEmpty()) {
            _errors.value = problems
            return
        }
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val date = _date.value
                val rows = BirdRecords.toEntities(date, farms, System.currentTimeMillis())
                repo.saveBirdDay(date.toString(), rows)
                _errors.value = emptyList()
                _message.value = if (rows.isEmpty()) {
                    "Nothing was written, so this day has no farm records."
                } else {
                    "Saved ${rows.size} farm${if (rows.size == 1) "" else "s"} for this day."
                }
                if (rows.isNotEmpty()) onSaved?.invoke()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "save farm records failed", e)
                _message.value = "Unable to save. Please try again."
            } finally {
                saving = false
            }
        }
    }
}
