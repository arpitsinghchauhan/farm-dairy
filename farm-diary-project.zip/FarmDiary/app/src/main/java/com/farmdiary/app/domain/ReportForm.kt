package com.farmdiary.app.domain

import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

object Calc {
    const val EGGS_PER_TRAY = 30
    const val TRAYS_PER_BUNDLE = 100

    fun parse(s: String): Double = s.trim().toDoubleOrNull() ?: 0.0

    /** Non-empty text that is not a valid non-negative number. */
    fun isInvalid(s: String): Boolean {
        if (s.isBlank()) return false
        val v = s.trim().toDoubleOrNull() ?: return true
        return v < 0 || v.isNaN() || v.isInfinite()
    }

    /** A price per egg: exact, up to 9 decimals (nothing is rounded to 2 decimals). */
    fun rateText(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return String.format(Locale.ENGLISH, "%.9f", d).trimEnd('0').trimEnd('.')
    }

    fun fmt(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return String.format(Locale.ENGLISH, "%.2f", d).trimEnd('0').trimEnd('.')
    }

    fun money(d: Double): String {
        val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
        nf.maximumFractionDigits = 2
        nf.minimumFractionDigits = 0
        return "\u20B9" + nf.format(d)
    }

    /** 1,25,000 style number without a currency sign (used in PDF tables). */
    fun group(d: Double): String {
        val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
        nf.maximumFractionDigits = 2
        nf.minimumFractionDigits = 0
        return nf.format(d)
    }

    fun eggsToTrays(eggs: Double): Double = eggs / EGGS_PER_TRAY

    fun bundles(trays: Double): Double = trays / TRAYS_PER_BUNDLE

    /** Returns user-facing problems that block confirming the report (empty = OK). */
    fun validate(
        form: ReportForm,
        availableFeed: Double,
        availableTrays: Double = Double.MAX_VALUE
    ): List<String> {
        val errors = mutableListOf<String>()
        if (form.hasInvalidNumbers()) errors += "Please enter a valid quantity (numbers only, not negative)."
        if (form.feedUsed > availableFeed + 1e-9) {
            errors += "You used ${fmt(form.feedUsed)} bags of feed, but only ${fmt(availableFeed)} bags " +
                "are in stock. Please correct the bags used."
        }
        if (form.trayUsed > availableTrays + 1e-9) {
            errors += "You used ${fmt(form.trayUsed)} trays (${fmt(bundles(form.trayUsed))} bundles), but only " +
                "${fmt(availableTrays)} trays (${fmt(bundles(availableTrays))} bundles) are in stock. " +
                "Please correct the trays used or add tray stock."
        }
        return errors
    }

    /** Result of confirming a report: what is left on that day, and the new stock now. */
    data class StockPlan(
        val problems: List<String>,
        val feedLeft: Double,
        val trayLeft: Int,
        val newFeed: Double,
        val newTrays: Int
    )

    /**
     * Stock is kept date-wise. A report that is confirmed for the first time uses the stock now.
     * A report that is edited later keeps the stock figure of its own day, so bags or trays added
     * after that day do not change it. Only the difference in use is applied to the stock now.
     */
    fun planConfirm(form: ReportForm, liveFeed: Double, liveTrays: Int): StockPlan {
        val feedBase = form.feedBase(liveFeed)
        val trayBase = form.trayBase(liveTrays)
        val problems = validate(form, feedBase, trayBase.toDouble()).toMutableList()
        val feedUsed = form.feedUsed
        val trayUsed = Math.round(form.trayUsed).toInt()
        val feedDelta = feedUsed - if (form.stockApplied) form.confirmedFeedUsed else 0.0
        val trayDelta = trayUsed - if (form.stockApplied) Math.round(form.confirmedTrayUsed).toInt() else 0
        if (problems.isEmpty()) {
            if (liveFeed - feedDelta < -1e-9) {
                problems += "Feed stock now is only ${fmt(liveFeed)} bags, so ${fmt(feedDelta)} more bags cannot be used. " +
                    "Please correct the bags used."
            }
            if (liveTrays - trayDelta < 0) {
                problems += "Tray stock now is only ${fmt(bundles(liveTrays.toDouble()))} bundles. " +
                    "Please correct the trays used or add tray stock."
            }
        }
        return StockPlan(problems, feedBase - feedUsed, trayBase - trayUsed, liveFeed - feedDelta, liveTrays - trayDelta)
    }

    /** Problems that block saving an Egg Sell entry (empty = OK). */
    fun validateSale(form: EggSaleForm): List<String> {
        val errors = mutableListOf<String>()
        if (form.hasInvalidNumbers()) errors += "Please enter a valid quantity (numbers only, not negative)."
        return errors
    }
}

data class FarmLineForm(
    val key: Long,
    val name: String = "",
    val feedBags: String = "",
    val feedRate: String = "",
    val trays: String = "",
    val mortality: String = "",
    /** Age of this farm's birds in days. */
    val dayNo: String = "",
    /** True when the age comes from Farm Records of the same date (shown as a value, not typed). */
    val ageFromRecord: Boolean = false
) {
    val feedAmount: Double get() = Calc.parse(feedBags) * Calc.parse(feedRate)
    /** Week of age (days 1-7 = week 1). 0 when no day is written. */
    val week: Int get() { val d = Calc.parse(dayNo).toInt(); return if (d <= 0) 0 else (d + 6) / 7 }
}

data class ExtraItemForm(
    val key: Long,
    val name: String = "",
    val amount: String = ""
)

const val MAX_EXTRA_ITEMS = 10

data class SaleLineForm(
    val key: Long,
    val name: String = "",
    val trays: String = "",
    /** Price of ONE egg. A tray has 30 eggs, so the amount is trays x 30 x price. */
    val rate: String = "",
    /** Optional new price of ONE egg. When filled it is used instead of [rate]. */
    val revisedRate: String = "",
    /** Optional subsidy per egg. It is taken off the price of one egg, the same way as the revise rate. */
    val subsidy: String = ""
) {
    val isRevised: Boolean get() = Calc.parse(revisedRate) > 0.0
    val isSubsidised: Boolean get() = Calc.parse(subsidy) > 0.0
    /** Price of one egg after the revise rate and the subsidy are taken off. */
    val effectiveRate: Double get() =
        Math.max(Calc.parse(rate) - (if (isRevised) Calc.parse(revisedRate) else 0.0) - (if (isSubsidised) Calc.parse(subsidy) else 0.0), 0.0)
    val pricePerTray: Double get() = effectiveRate * Calc.EGGS_PER_TRAY
    val amount: Double get() = Calc.parse(trays) * Calc.EGGS_PER_TRAY * effectiveRate
}

const val MAX_SALE_LINES = 10

/** Egg Sell screen: the sale of one day. Saved separately and shown inside that day's Daily Report. */
data class EggSaleForm(
    val date: LocalDate,
    val sales: List<SaleLineForm>,
    val cashReceived: String = "",
    val onlineReceived: String = "",
    val previousBalance: String = "",
    val advancePaid: String = "",
    val buyer: String = "",
    val dirty: Boolean = false
) {
    val totalIncome: Double get() = Math.floor(sales.sumOf { it.amount } + 1e-9)
    val totalTraysSold: Double get() = sales.sumOf { Calc.parse(it.trays) }
    val received: Double get() = Calc.parse(cashReceived) + Calc.parse(onlineReceived)
    val previous: Double get() = Calc.parse(previousBalance)
    val advance: Double get() = Calc.parse(advancePaid)

    /** previous + today's sale - advance - cash - online. Below zero means the buyer has paid in advance. */
    val balance: Double get() = previous + totalIncome - advance - received
    val isCredit: Boolean get() = balance < -1e-9
    val isNil: Boolean get() = totalIncome <= 0.0
    val hasMoney: Boolean get() = previous > 0.0 || advance > 0.0 || received > 0.0

    fun hasInvalidNumbers(): Boolean =
        listOf(cashReceived, onlineReceived, previousBalance, advancePaid).any { Calc.isInvalid(it) } ||
            sales.any { Calc.isInvalid(it.trays) || Calc.isInvalid(it.rate) || Calc.isInvalid(it.revisedRate) || Calc.isInvalid(it.subsidy) }

    /** Lines that really have a quantity or a price (blank rows are not saved). */
    fun realLines(): List<SaleLineForm> =
        sales.filter { Calc.parse(it.trays) > 0.0 || Calc.parse(it.rate) > 0.0 || Calc.parse(it.revisedRate) > 0.0 || Calc.parse(it.subsidy) > 0.0 }
}

data class ReportForm(
    val date: LocalDate,
    val lines: List<FarmLineForm>,
    val trayQty: String = "",
    val trayRate: String = "",
    val labour: String = "",
    val light: String = "",
    /** Egg rate of the day (price per egg), written at the top of the report. */
    val eggRate: String = "",
    val stoneQty: String = "",
    val stoneRate: String = "",
    val sales: List<SaleLineForm> = emptyList(),
    val cashReceived: String = "",
    val onlineReceived: String = "",
    val previousBalance: String = "",
    val advancePaid: String = "",
    val extras: List<ExtraItemForm> = emptyList(),
    /** Other income of the day (litter, empty feed bags...), apart from the egg sale. */
    val otherIncome: List<ExtraItemForm> = emptyList(),
    val confirmed: Boolean = false,
    val confirmedFeedUsed: Double = 0.0,
    val confirmedTrayUsed: Double = 0.0,
    val confirmedTrayOpening: Double = 0.0,
    val confirmedTrayClosing: Double = 0.0,
    val confirmedOpening: Double = 0.0,
    val confirmedClosing: Double = 0.0,
    /** Egg trays in stock when this report was confirmed; -1 if it was never recorded. */
    val confirmedEggTrays: Int = -1,
    /** Egg trays this report already added to / took from the egg stock when it was confirmed. */
    val confirmedEggNet: Double = 0.0,
    /** True when the stone quantity is the total of the stone bags written in Farm Records. */
    val stoneFromRecords: Boolean = false,
    val createdAt: Long = 0,
    val dirty: Boolean = false
) {
    val feedUsed: Double get() = lines.sumOf { Calc.parse(it.feedBags) }
    val feedExpense: Double get() = lines.sumOf { it.feedAmount }
    val trayUsed: Double get() = Calc.parse(trayQty)
    val totalMortality: Double get() = lines.sumOf { Calc.parse(it.mortality) }
    val trayAmount: Double get() = Calc.parse(trayQty) * Calc.parse(trayRate)
    val stoneAmount: Double get() = Calc.parse(stoneQty) * Calc.parse(stoneRate)
    val totalExpenditure: Double
        get() = feedExpense + trayAmount + Calc.parse(labour) + Calc.parse(light) + stoneAmount + extrasTotal
    val extrasTotal: Double get() = extras.sumOf { Calc.parse(it.amount) }
    val otherIncomeTotal: Double get() = otherIncome.sumOf { Calc.parse(it.amount) }
    /** Egg sale plus other income. */
    val allIncome: Double get() = totalIncome + otherIncomeTotal
    val totalTrays: Double get() = lines.sumOf { Calc.parse(it.trays) }
    val totalIncome: Double get() = Math.floor(sales.sumOf { it.amount } + 1e-9)
    val totalTraysSold: Double get() = sales.sumOf { Calc.parse(it.trays) }
    val received: Double get() = Calc.parse(cashReceived) + Calc.parse(onlineReceived)
    val previous: Double get() = Calc.parse(previousBalance)
    val advance: Double get() = Calc.parse(advancePaid)
    val balance: Double get() = previous + totalIncome - advance - received
    val hasSaleMoney: Boolean get() = previous > 0.0 || advance > 0.0 || received > 0.0

    /** True once this report's usage has been taken out of the stock (it was confirmed before). */
    val stockApplied: Boolean get() =
        confirmedOpening != 0.0 || confirmedClosing != 0.0 || confirmedFeedUsed != 0.0 ||
            confirmedTrayOpening != 0.0 || confirmedTrayClosing != 0.0 || confirmedTrayUsed != 0.0

    /** Feed in stock at the start of this report's day. A confirmed report keeps its own day's figure. */
    fun feedBase(liveFeed: Double): Double = if (stockApplied) confirmedOpening else liveFeed

    /** Blank trays in stock at the start of this report's day. */
    fun trayBase(liveTrays: Int): Int = if (stockApplied) Math.round(confirmedTrayOpening).toInt() else liveTrays

    /** Egg trays in stock for this report's day, or null if it is an old report that never recorded it. */
    fun eggStock(liveEggTrays: Int): Int? = when {
        !stockApplied -> liveEggTrays
        confirmedEggTrays >= 0 -> confirmedEggTrays
        else -> null
    }

    /** Egg trays added to the egg stock by this report: production minus the trays sold that day. */
    val netEggs: Int get() = Math.round(totalTrays - totalTraysSold).toInt()

    /**
     * Egg trays in stock after this report. Not confirmed yet: the stock now plus today's net. Confirmed: the stock it recorded
     * plus any change since. Null for an old report that never recorded it.
     */
    fun eggLeft(liveEggTrays: Int): Int? = when {
        !stockApplied -> liveEggTrays
        confirmedEggTrays >= 0 -> confirmedEggTrays
        else -> null
    }

    fun hasInvalidNumbers(): Boolean {
        val singles = listOf(eggRate, trayQty, trayRate, labour, light, stoneQty, stoneRate, cashReceived, onlineReceived, previousBalance, advancePaid)
        if (singles.any { Calc.isInvalid(it) }) return true
        if (extras.any { Calc.isInvalid(it.amount) } || otherIncome.any { Calc.isInvalid(it.amount) }) return true
        if (sales.any { Calc.isInvalid(it.trays) || Calc.isInvalid(it.rate) || Calc.isInvalid(it.revisedRate) || Calc.isInvalid(it.subsidy) }) return true
        return lines.any { Calc.isInvalid(it.feedBags) || Calc.isInvalid(it.feedRate) || Calc.isInvalid(it.trays) || Calc.isInvalid(it.mortality) || Calc.isInvalid(it.dayNo) }
    }
}
