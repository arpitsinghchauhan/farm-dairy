package com.farmdiary.app.domain

import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

object Calc {
    const val EGGS_PER_TRAY = 30
    const val TRAYS_PER_BUNDLE = 100
    const val LITERS_PER_TANK = 1000

    fun parse(s: String): Double = s.trim().toDoubleOrNull() ?: 0.0

    /** Non-empty text that is not a valid non-negative number. */
    fun isInvalid(s: String): Boolean {
        if (s.isBlank()) return false
        val v = s.trim().toDoubleOrNull() ?: return true
        return v < 0 || v.isNaN() || v.isInfinite()
    }

    fun fmt(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return String.format(Locale.ENGLISH, "%.2f", d).trimEnd('0').trimEnd('.')
    }

    fun money(d: Double): String {
        val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
        nf.maximumFractionDigits = 2
        nf.minimumFractionDigits = 0
        return "\u20B9" + nf.format(d)
    }

    fun eggsToTrays(eggs: Double): Double = eggs / EGGS_PER_TRAY

    fun bundles(trays: Double): Double = trays / TRAYS_PER_BUNDLE

    /** Returns user-facing problems that block confirming the report (empty = OK). */
    fun validate(
        form: ReportForm,
        availableFeed: Double,
        availableTrays: Double = Double.MAX_VALUE
    ): List<String> {
        val errors = mutableListOf<String>()
        if (form.hasInvalidNumbers()) errors += "Please enter a valid quantity (numbers only, not negative)."
        if (form.feedUsed > availableFeed + 1e-9) {
            errors += "You used ${fmt(form.feedUsed)} bags of feed, but only ${fmt(availableFeed)} bags " +
                "are in stock. Please correct the bags used."
        }
        if (form.trayUsed > availableTrays + 1e-9) {
            errors += "You used ${fmt(form.trayUsed)} trays (${fmt(bundles(form.trayUsed))} bundles), but only " +
                "${fmt(availableTrays)} trays (${fmt(bundles(availableTrays))} bundles) are in stock. " +
                "Please correct the trays used or add tray stock."
        }
        if (form.received > form.totalIncome + 1e-9) {
            errors += "Cash + online received (${money(form.received)}) is more than the total sale " +
                "(${money(form.totalIncome)}). Please correct it in Egg Sell."
        }
        return errors
    }

    /** Problems that block saving an Egg Sell entry (empty = OK). */
    fun validateSale(form: EggSaleForm): List<String> {
        val errors = mutableListOf<String>()
        if (form.hasInvalidNumbers()) errors += "Please enter a valid quantity (numbers only, not negative)."
        if (form.received > form.totalIncome + 1e-9) {
            errors += "Cash + online received (${money(form.received)}) is more than the total sale " +
                "(${money(form.totalIncome)}). Please correct the amounts."
        }
        return errors
    }
}

data class FarmLineForm(
    val key: Long,
    val name: String = "",
    val feedBags: String = "",
    val feedRate: String = "",
    val trays: String = "",
    val mortality: String = ""
) {
    val feedAmount: Double get() = Calc.parse(feedBags) * Calc.parse(feedRate)
}

data class ExtraItemForm(
    val key: Long,
    val name: String = "",
    val amount: String = ""
)

const val MAX_EXTRA_ITEMS = 10

data class SaleLineForm(
    val key: Long,
    val name: String = "",
    val trays: String = "",
    val rate: String = ""
) {
    val amount: Double get() = Calc.parse(trays) * Calc.parse(rate)
}

const val MAX_SALE_LINES = 10

/** Egg Sell screen: the sale of one day. Saved separately and shown inside that day's Daily Report. */
data class EggSaleForm(
    val date: LocalDate,
    val sales: List<SaleLineForm>,
    val cashReceived: String = "",
    val onlineReceived: String = "",
    val dirty: Boolean = false
) {
    val totalIncome: Double get() = sales.sumOf { it.amount }
    val totalTraysSold: Double get() = sales.sumOf { Calc.parse(it.trays) }
    val received: Double get() = Calc.parse(cashReceived) + Calc.parse(onlineReceived)
    val balance: Double get() = totalIncome - received
    val isNil: Boolean get() = totalIncome <= 0.0

    fun hasInvalidNumbers(): Boolean =
        Calc.isInvalid(cashReceived) || Calc.isInvalid(onlineReceived) ||
            sales.any { Calc.isInvalid(it.trays) || Calc.isInvalid(it.rate) }

    /** Lines that really have a quantity or a price (blank rows are not saved). */
    fun realLines(): List<SaleLineForm> =
        sales.filter { Calc.parse(it.trays) > 0.0 || Calc.parse(it.rate) > 0.0 }
}

data class ReportForm(
    val date: LocalDate,
    val lines: List<FarmLineForm>,
    val trayQty: String = "",
    val trayRate: String = "",
    val labour: String = "",
    val light: String = "",
    val stoneQty: String = "",
    val stoneRate: String = "",
    val sales: List<SaleLineForm> = emptyList(),
    val cashReceived: String = "",
    val onlineReceived: String = "",
    val extras: List<ExtraItemForm> = emptyList(),
    val waterTanks: String = "",
    val confirmed: Boolean = false,
    val confirmedFeedUsed: Double = 0.0,
    val confirmedTrayUsed: Double = 0.0,
    val confirmedTrayOpening: Double = 0.0,
    val confirmedTrayClosing: Double = 0.0,
    val confirmedOpening: Double = 0.0,
    val confirmedClosing: Double = 0.0,
    val createdAt: Long = 0,
    val dirty: Boolean = false
) {
    val feedUsed: Double get() = lines.sumOf { Calc.parse(it.feedBags) }
    val feedExpense: Double get() = lines.sumOf { it.feedAmount }
    val trayUsed: Double get() = Calc.parse(trayQty)
    val totalMortality: Double get() = lines.sumOf { Calc.parse(it.mortality) }
    val waterLiters: Double get() = Calc.parse(waterTanks) * Calc.LITERS_PER_TANK
    val trayAmount: Double get() = Calc.parse(trayQty) * Calc.parse(trayRate)
    val stoneAmount: Double get() = Calc.parse(stoneQty) * Calc.parse(stoneRate)
    val totalExpenditure: Double
        get() = feedExpense + trayAmount + Calc.parse(labour) + Calc.parse(light) + stoneAmount + extrasTotal
    val extrasTotal: Double get() = extras.sumOf { Calc.parse(it.amount) }
    val totalTrays: Double get() = lines.sumOf { Calc.parse(it.trays) }
    val totalEggs: Double get() = totalTrays * Calc.EGGS_PER_TRAY
    val totalIncome: Double get() = sales.sumOf { it.amount }
    val totalTraysSold: Double get() = sales.sumOf { Calc.parse(it.trays) }
    val received: Double get() = Calc.parse(cashReceived) + Calc.parse(onlineReceived)
    val balance: Double get() = totalIncome - received

    fun hasInvalidNumbers(): Boolean {
        val singles = listOf(trayQty, trayRate, labour, light, stoneQty, stoneRate, cashReceived, onlineReceived, waterTanks)
        if (singles.any { Calc.isInvalid(it) }) return true
        if (extras.any { Calc.isInvalid(it.amount) }) return true
        if (sales.any { Calc.isInvalid(it.trays) || Calc.isInvalid(it.rate) }) return true
        return lines.any { Calc.isInvalid(it.feedBags) || Calc.isInvalid(it.feedRate) || Calc.isInvalid(it.trays) || Calc.isInvalid(it.mortality) }
    }
}
