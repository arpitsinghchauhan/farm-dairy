package com.farmdiary.app.domain

import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

object Calc {
    const val EGGS_PER_TRAY = 30

    fun parse(s: String): Double = s.trim().toDoubleOrNull() ?: 0.0

    /** Non-empty text that is not a valid non-negative number. */
    fun isInvalid(s: String): Boolean {
        if (s.isBlank()) return false
        val v = s.trim().toDoubleOrNull() ?: return true
        return v < 0 || v.isNaN() || v.isInfinite()
    }

    fun fmt(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return String.format(Locale.ENGLISH, "%.2f", d).trimEnd('0').trimEnd('.')
    }

    fun money(d: Double): String {
        val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
        nf.maximumFractionDigits = 2
        nf.minimumFractionDigits = 0
        return "\u20B9" + nf.format(d)
    }

    fun eggsToTrays(eggs: Double): Double = eggs / EGGS_PER_TRAY

    /** Returns user-facing problems that block confirming the report (empty = OK). */
    fun validate(form: ReportForm, availableFeed: Double): List<String> {
        val errors = mutableListOf<String>()
        if (form.hasInvalidNumbers()) errors += "Please enter a valid quantity (numbers only, not negative)."
        if (form.feedUsed > availableFeed + 1e-9) {
            errors += "Feed used (${fmt(form.feedUsed)} bags) is more than available stock " +
                "(${fmt(availableFeed)} bags). Please correct the quantities."
        }
        return errors
    }
}

data class FarmLineForm(
    val key: Long,
    val name: String = "",
    val feedBags: String = "",
    val feedRate: String = "",
    val eggs: String = ""
) {
    val feedAmount: Double get() = Calc.parse(feedBags) * Calc.parse(feedRate)
}

data class ReportForm(
    val date: LocalDate,
    val lines: List<FarmLineForm>,
    val trayQty: String = "",
    val trayRate: String = "",
    val labour: String = "",
    val light: String = "",
    val stoneQty: String = "",
    val stoneRate: String = "",
    val eggSell: String = "",
    val confirmed: Boolean = false,
    val confirmedFeedUsed: Double = 0.0,
    val confirmedOpening: Double = 0.0,
    val confirmedClosing: Double = 0.0,
    val createdAt: Long = 0,
    val dirty: Boolean = false
) {
    val feedUsed: Double get() = lines.sumOf { Calc.parse(it.feedBags) }
    val feedExpense: Double get() = lines.sumOf { it.feedAmount }
    val trayAmount: Double get() = Calc.parse(trayQty) * Calc.parse(trayRate)
    val stoneAmount: Double get() = Calc.parse(stoneQty) * Calc.parse(stoneRate)
    val totalExpenditure: Double
        get() = feedExpense + trayAmount + Calc.parse(labour) + Calc.parse(light) + stoneAmount
    val totalEggs: Double get() = lines.sumOf { Calc.parse(it.eggs) }
    val totalIncome: Double get() = Calc.parse(eggSell)

    fun hasInvalidNumbers(): Boolean {
        val singles = listOf(trayQty, trayRate, labour, light, stoneQty, stoneRate, eggSell)
        if (singles.any { Calc.isInvalid(it) }) return true
        return lines.any { Calc.isInvalid(it.feedBags) || Calc.isInvalid(it.feedRate) || Calc.isInvalid(it.eggs) }
    }
}
