package com.farmdiary.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.IllnessViewModel
import com.farmdiary.app.data.IllnessEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.IllnessRules
import com.farmdiary.app.domain.MedicineDose
import java.time.LocalDate

@Composable
private fun TextBox(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 60) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
            focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
            focusedLabelColor = Primary, unfocusedLabelColor = TextLo
        ),
        modifier = modifier
    )
}

/** Illness (name, bird age, date, farm) and treatment (doctor, up to 10 medicines with dose per bird). */
@Composable
fun IllnessScreen(vm: IllnessViewModel, onBack: () -> Unit) {
    val records by vm.records.collectAsState()
    val farms by vm.farms.collectAsState()
    val errors by vm.errors.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.clearMessage() } }
    OpenPdfEffect(pdfUri) { vm.clearOpenPdf() }
    DisposableEffect(Unit) { onDispose { vm.clearErrors() } }

    var date by remember { mutableStateOf(LocalDate.now()) }
    var illness by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var farm by remember { mutableStateOf("") }
    var doctor by remember { mutableStateOf("") }
    var meds by remember { mutableStateOf(listOf(MedicineDose())) }
    var editing by remember { mutableStateOf<IllnessEntity?>(null) }
    val clearForm = {
        illness = ""; age = ""; farm = ""; doctor = ""; meds = listOf(MedicineDose()); editing = null
    }

    Scaffold(
        topBar = { FarmTopBar("Illness and Treatment", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DatePill(date) { date = it; vm.clearErrors() }

            SectionCard(if (editing != null) "Change illness" else "Illness", "🤒") {
                TextBox("Illness name", illness, { illness = it; vm.clearErrors() }, Modifier.fillMaxWidth())
                NumField("Bird age (days)", age, { age = it; vm.clearErrors() }, Modifier.fillMaxWidth(), integer = true)
                if (age.isNotBlank() && !Calc.isInvalid(age)) {
                    CalcRow("Week of age", "${com.farmdiary.app.domain.BirdRecords.weekOf(Calc.parse(age).toInt())}")
                }
                ChoiceDropdown(
                    label = "Farm",
                    selectedText = farm,
                    options = farms.map { it to it },
                    onSelect = { farm = it; vm.clearErrors() },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Treatment", "💊") {
                TextBox("Doctor name", doctor, { doctor = it }, Modifier.fillMaxWidth())
                meds.forEachIndexed { i, m ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextBox(
                            "Medicine ${i + 1}", m.name,
                            { v -> meds = meds.mapIndexed { j, x -> if (j == i) x.copy(name = v) else x } },
                            Modifier.weight(1f)
                        )
                        TextBox(
                            "Dose per bird", m.dose,
                            { v -> meds = meds.mapIndexed { j, x -> if (j == i) x.copy(dose = v) else x } },
                            Modifier.weight(0.8f)
                        )
                        IconButton(onClick = {
                            meds = meds.filterIndexed { j, _ -> j != i }.ifEmpty { listOf(MedicineDose()) }
                        }) { Icon(Icons.Default.Delete, contentDescription = "Remove medicine ${i + 1}") }
                    }
                }
                if (meds.size < IllnessRules.MAX_MEDICINES) {
                    OutlinedButton(onClick = { meds = meds + MedicineDose() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add medicine")
                    }
                } else {
                    Text("You can add up to ${IllnessRules.MAX_MEDICINES} medicines.", fontSize = 14.sp, color = TextLo)
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") { errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) } }
            }

            GradientButton(
                text = if (editing != null) "✅  Update" else "✅  Save",
                onClick = { vm.save(date, illness, age, farm, doctor, meds, editing) { clearForm() } },
                modifier = Modifier.fillMaxWidth()
            )
            if (editing != null) {
                TextButton(onClick = { clearForm(); vm.clearErrors() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel change", fontSize = 18.sp)
                }
            }

            AccentCard("Saved records", "📒", SunBrush, Sun) {
                if (records.isEmpty()) Text("Nothing saved yet.", fontSize = 16.sp, color = TextLo)
                records.forEach { r ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            LocalDate.parse(r.date).format(displayDateFormat) + "  •  " + r.farm,
                            fontSize = 17.sp, fontWeight = FontWeight.Bold
                        )
                        Text(r.illness + ", " + IllnessRules.ageText(r.birdAge), fontSize = 16.sp)
                        if (r.doctor.isNotBlank()) Text("Doctor: ${r.doctor}", fontSize = 15.sp, color = TextLo)
                        IllnessRules.medicinesOf(r).forEach {
                            Text("• ${it.name}" + if (it.dose.isNotBlank()) " - ${it.dose} per bird" else "", fontSize = 15.sp, color = TextLo)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = {
                                editing = r; date = LocalDate.parse(r.date); illness = r.illness; age = r.birdAge.toString()
                                farm = r.farm; doctor = r.doctor
                                meds = IllnessRules.medicinesOf(r).ifEmpty { listOf(MedicineDose()) }
                                vm.clearErrors()
                            }) { Text("Change", fontSize = 15.sp) }
                            TextButton(onClick = { vm.downloadPdf(r) }) { Text("PDF", fontSize = 15.sp) }
                            IconButton(onClick = { vm.delete(r.id); if (editing?.id == r.id) clearForm() }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete this record")
                            }
                        }
                    }
                }
            }

            GradientButton(
                text = "📄  Download PDF of all",
                onClick = { vm.downloadPdf() },
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
