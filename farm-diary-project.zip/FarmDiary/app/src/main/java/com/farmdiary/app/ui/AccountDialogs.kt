package com.farmdiary.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.AuthViewModel
import com.farmdiary.app.domain.Credentials

@Composable
private fun pinBox(value: String, label: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> if (v.length <= Credentials.PIN_MAX && v.all { it.isDigit() }) onChange(v) },
        label = { Text(label) },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Normal),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
            focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
            focusedLabelColor = Primary, unfocusedLabelColor = TextLo
        ),
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

/** Gear menu: change the PIN (asks for the current PIN first). */
@Composable
fun ChangePinDialog(auth: AuthViewModel, onClose: (changed: Boolean) -> Unit) {
    var current by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { onClose(false) },
        containerColor = Panel,
        shape = RoundedCornerShape(20.dp),
        title = { Text("Reset PIN", fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = TextHi) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                pinBox(current, "Current PIN") { current = it; error = null }
                pinBox(pin, "New PIN (4 to 6 digits)") { pin = it; error = null }
                pinBox(confirm, "Confirm new PIN") { confirm = it; error = null }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = { auth.changePin(current, pin, confirm) { err -> if (err == null) onClose(true) else error = err } }) {
                Text("Save", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Primary)
            }
        },
        dismissButton = { TextButton(onClick = { onClose(false) }) { Text("Cancel", fontSize = 15.sp, color = TextLo) } }
    )
}

/** Gear menu (and a one-time prompt): set the security question used by "Forgot PIN?". */
@Composable
fun SecurityQuestionDialog(auth: AuthViewModel, onClose: (saved: Boolean) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { onClose(false) },
        containerColor = Panel,
        shape = RoundedCornerShape(20.dp),
        title = { Text("Security question", fontFamily = TitleFont, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = TextHi) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceDropdown(
                    label = "Question",
                    selectedText = question,
                    options = Credentials.QUESTIONS.map { it to it },
                    onSelect = { question = it; error = null }
                )
                OutlinedTextField(
                    value = answer,
                    onValueChange = { if (it.length <= 40) { answer = it; error = null } },
                    label = { Text("Your answer") },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Normal),
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
                        focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
                        focusedLabelColor = Primary, unfocusedLabelColor = TextLo
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                pinBox(pin, "Your PIN") { pin = it; error = null }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = { auth.setQuestion(pin, question, answer) { err -> if (err == null) onClose(true) else error = err } }) {
                Text("Save", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Primary)
            }
        },
        dismissButton = { TextButton(onClick = { onClose(false) }) { Text("Later", fontSize = 15.sp, color = TextLo) } }
    )
}
