package com.farmdiary.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.EggSaleDayRow
import com.farmdiary.app.domain.StockHistory
import java.time.LocalDate

/** Earlier egg sales, newest first. Tap a day to open it in Egg Sell. */
@Composable
fun EggSaleHistoryScreen(vm: FarmViewModel, onOpen: (LocalDate) -> Unit, onBack: () -> Unit) {
    var rows by remember { mutableStateOf<List<EggSaleDayRow>?>(null) }
    LaunchedEffect(Unit) { rows = vm.loadEggSaleHistory() }

    Scaffold(topBar = { FarmTopBar("Selling History", onBack) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val list = rows
            if (list == null) {
                Text("Loading...", fontSize = 18.sp)
                return@Column
            }
            if (list.isEmpty()) {
                Text("No egg sales saved yet.", fontSize = 18.sp)
                return@Column
            }
            AccentCard("Total of all saved days", "📈", EggBrush, Sun) {
                CalcRow("Days saved", "${list.size}")
                CalcRow("Trays sold", "${Calc.fmt(list.sumOf { it.traysSold })} trays")
                CalcRow("Sale amount", Calc.money(list.sumOf { it.total }), bold = true)
                CalcRow("Cash and online received", Calc.money(list.sumOf { it.cash + it.online }))
            }
            list.forEach { r ->
                val date = LocalDate.parse(r.date)
                val accent = when {
                    r.isNil -> Color(0xFF9A93B5)
                    r.balance > 1e-9 -> Coral
                    else -> Mint
                }
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(date) },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.12f).compositeOverPanel())
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(date.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
                            Text(
                                if (r.isNil) "NIL" else Calc.money(r.total),
                                fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = accent
                            )
                        }
                        if (!r.isNil) CalcRow("Trays sold", "${Calc.fmt(r.traysSold)} trays")
                        if (r.previous > 0) CalcRow("Previous balance", Calc.money(r.previous))
                        if (r.advance > 0) CalcRow("Advance paid", Calc.money(r.advance))
                        if (r.cash + r.online > 0) CalcRow("Received (cash + online)", Calc.money(r.cash + r.online))
                        if (r.balance < -1e-9) {
                            CalcRow("Advance in hand (credit)", Calc.money(-r.balance), bold = true)
                        } else {
                            CalcRow("Balance to receive", Calc.money(r.balance), bold = true)
                        }
                    }
                }
            }
        }
    }
}

private fun Color.compositeOverPanel(): Color = this.compositeOver(Panel)

/** In-Stock: the confirmed stock record of the chosen date only. Dates that have a record are shown as chips. */
@Composable
fun StockReportSection(vm: FarmViewModel) {
    val reports by vm.reports.collectAsState()
    var date by remember { mutableStateOf(LocalDate.now()) }
    val rows = remember(reports) { StockHistory.rows(reports) }
    val onDate = remember(reports, date) { StockHistory.onExact(reports, date.toString()) }

    AccentCard("Stock record of a date", "📅", VioletBrush, Violet) {
        DatePill(date) { date = it }
        if (onDate == null) {
            Text("There is no confirmed stock record for this date.", fontSize = 17.sp)
        } else {
            Text(
                "After the Daily Report of ${LocalDate.parse(onDate.date).format(displayDateFormat)}",
                fontSize = 16.sp, color = TextLo
            )
            CalcRow("Feed", "${Calc.fmt(onDate.feedLeft)} bags", bold = true)
            CalcRow("Tray bundles", "${Calc.fmt(onDate.trayBundlesLeft)} bundles", bold = true)
            onDate.eggTrays?.let { CalcRow("Egg trays", "$it trays", bold = true) }
        }
        if (rows.isNotEmpty()) {
            Text("Dates with a stock record (tap one):", fontSize = 15.sp, color = TextLo)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rows.forEach { r ->
                    val d = LocalDate.parse(r.date)
                    val chosen = r.date == date.toString()
                    Text(
                        d.format(displayDateFormat),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (chosen) TextHi else Violet,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (chosen) Violet.copy(alpha = 0.55f) else Violet.copy(alpha = 0.15f))
                            .clickable { date = d }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}
