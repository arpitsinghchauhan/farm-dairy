package com.farmdiary.app.domain

/** One ingredient of the feed made on the farm (for example "Bajra", 45 %). */
data class MixItem(val name: String = "", val percent: String = "", /** Price of one 50 kg bag of this ingredient. */ val rate: String = "")

/** What one ingredient comes to for the bags used. */
data class MixRow(val name: String, val percent: Double, val kg: Double, /** Rupees per kg (the bag price divided by 50). */ val rate: Double = 0.0) {
    val bags: Double get() = kg / FeedMakerCalc.BAG_KG
    /** Cost of this ingredient: kg x rate per kg. */
    val cost: Double get() = kg * rate
}

data class MixResult(
    val rows: List<MixRow>,
    /** Bags of bought full feed (the part not made on the farm). */
    val fullFeedBags: Double,
    val totalBags: Double,
    /** Price of one bag of bought full feed (0 = not written). */
    val fullFeedBagPrice: Double = 0.0
) {
    val fullFeedKg: Double get() = fullFeedBags * FeedMakerCalc.BAG_KG
    val fullFeedCost: Double get() = fullFeedBags * fullFeedBagPrice
    val totalKg: Double get() = rows.sumOf { it.kg } + fullFeedKg
    val totalCost: Double get() = rows.sumOf { it.cost } + fullFeedCost
    /** True when at least one rate is written, so a cost can be shown. */
    val hasCost: Boolean get() = totalCost > 0.0
    /** Cost of 1 kg of the finished feed. */
    val costPerKg: Double get() = if (totalKg > 0.0) totalCost / totalKg else 0.0
}

/**
 * Feed Maker: the feed is made from up to 10 ingredients, each with a percent. The user says how many 50 kg bags of feed
 * are used and the app works out the kg and the bags of each ingredient.
 */
object FeedMakerCalc {
    const val MAX_ITEMS = 10
    const val BAG_KG = 50.0

    private fun real(items: List<MixItem>) = items.filter { it.name.isNotBlank() || it.percent.isNotBlank() }

    fun totalPercent(items: List<MixItem>): Double = real(items).sumOf { Calc.parse(it.percent) }

    fun validate(items: List<MixItem>): List<String> {
        val list = real(items)
        val out = mutableListOf<String>()
        if (list.isEmpty()) return listOf("Add the ingredients of your feed with their percent.")
        if (list.size > MAX_ITEMS) out += "You can add up to $MAX_ITEMS ingredients."
        if (list.any { it.name.isBlank() }) out += "Write the name of every ingredient."
        if (list.any { Calc.isInvalid(it.percent) }) out += "Write a valid percent (numbers only) for every ingredient."
        if (list.any { Calc.isInvalid(it.rate) }) out += "Write a valid rate (numbers only) for the ingredients."
        if (out.isEmpty() && Math.abs(totalPercent(items) - 100.0) > 0.005) {
            out += "The percents add up to ${Calc.fmt(Math.round(totalPercent(items) * 100) / 100.0)} %. They must add up to 100 %."
        }
        return out
    }

    /**
     * [bagsUsed] = all 50 kg bags of feed used. [ownShare] = percent of them made from the ingredients; the rest is bought
     * full feed. [roundTo5] rounds each ingredient to the nearest 5 kg, as is done when weighing.
     */
    fun split(items: List<MixItem>, bagsUsed: Double, ownShare: Double = 100.0, roundTo5: Boolean = false, fullFeedBagPrice: Double = 0.0): MixResult {
        val share = ownShare.coerceIn(0.0, 100.0)
        val ownKg = bagsUsed * BAG_KG * share / 100.0
        val rows = real(items).map {
            val pct = Calc.parse(it.percent)
            var kg = ownKg * pct / 100.0
            if (roundTo5) kg = Math.round(kg / 5.0) * 5.0
            MixRow(it.name.trim(), pct, kg, Calc.parse(it.rate) / BAG_KG) // the rate is written for one 50 kg bag
        }
        return MixResult(rows, bagsUsed * (100.0 - share) / 100.0, bagsUsed, fullFeedBagPrice)
    }

    fun encode(items: List<MixItem>): String =
        real(items).joinToString("\n") { it.name.replace('\n', ' ').replace('\t', ' ') + "\t" + it.percent + "\t" + it.rate }

    fun decode(text: String): List<MixItem> =
        text.split("\n").filter { it.isNotBlank() }.map {
            val p = it.split("\t")
            MixItem(p.getOrElse(0) { "" }, p.getOrElse(1) { "" }, p.getOrElse(2) { "" })
        }
}

/** A feed composition saved with a title (for example "Winter mix"), so it can be picked again later. */
data class MixTemplate(
    val title: String,
    val items: List<MixItem>,
    val share: String = "100",
    val round: Boolean = false,
    val fullPrice: String = ""
)

/** One feed made on a day: the composition used and the bags used on each farm. A day can have several. */
data class MixRecord(
    val id: String,
    /** ISO date, yyyy-MM-dd. */
    val date: String,
    val title: String,
    val items: List<MixItem>,
    val share: String = "100",
    val round: Boolean = false,
    val fullPrice: String = "",
    /** Bags used (50 kg), by farm name. */
    val bags: List<Pair<String, String>> = emptyList()
) {
    private val ownShare: Double get() = if (share.isBlank()) 100.0 else Calc.parse(share).coerceIn(0.0, 100.0)

    /** The result for each farm that has bags written. */
    fun results(): List<Pair<String, MixResult>> = bags.mapNotNull { (farm, b) ->
        val n = Calc.parse(b)
        if (n > 0.0 && !Calc.isInvalid(b)) farm to FeedMakerCalc.split(items, n, ownShare, round, Calc.parse(fullPrice)) else null
    }
}

/** Saving and reading templates and records as plain text (kept on the phone). */
object FeedMakerStore {
    const val MAX_TEMPLATES = 30
    const val MAX_RECORDS = 2000
    const val MAX_TITLE = 30

    private fun clean(s: String) = s.replace('\n', ' ').replace('\t', ' ').trim()

    fun validTitle(title: String): Boolean = clean(title).let { it.length in 1..MAX_TITLE }

    private fun itemLines(items: List<MixItem>) =
        items.filter { it.name.isNotBlank() || it.percent.isNotBlank() }.map { "I\t${clean(it.name)}\t${it.percent}\t${it.rate}" }

    fun encodeTemplates(list: List<MixTemplate>): String = list.joinToString("\n") { t ->
        (listOf("T\t${clean(t.title)}\t${t.share}\t${t.round}\t${t.fullPrice}") + itemLines(t.items)).joinToString("\n")
    }

    fun decodeTemplates(text: String): List<MixTemplate> {
        val out = ArrayList<MixTemplate>()
        var cur: MixTemplate? = null
        text.split("\n").forEach { line ->
            val p = line.split("\t")
            when (p.firstOrNull()) {
                "T" -> {
                    cur?.let { out += it }
                    cur = MixTemplate(p.getOrElse(1) { "" }, emptyList(), p.getOrElse(2) { "100" }, p.getOrElse(3) { "" } == "true", p.getOrElse(4) { "" })
                }
                "I" -> cur = cur?.let { it.copy(items = it.items + MixItem(p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" })) }
            }
        }
        cur?.let { out += it }
        return out
    }

    fun encodeRecords(list: List<MixRecord>): String = list.joinToString("\n") { r ->
        (listOf("R\t${clean(r.id)}\t${r.date}\t${clean(r.title)}\t${r.share}\t${r.round}\t${r.fullPrice}") +
            itemLines(r.items) + r.bags.map { "B\t${clean(it.first)}\t${it.second}" }).joinToString("\n")
    }

    fun decodeRecords(text: String): List<MixRecord> {
        val out = ArrayList<MixRecord>()
        var cur: MixRecord? = null
        text.split("\n").forEach { line ->
            val p = line.split("\t")
            when (p.firstOrNull()) {
                "R" -> {
                    cur?.let { out += it }
                    cur = MixRecord(
                        p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" }, emptyList(),
                        p.getOrElse(4) { "100" }, p.getOrElse(5) { "" } == "true", p.getOrElse(6) { "" }
                    )
                }
                "I" -> cur = cur?.let { it.copy(items = it.items + MixItem(p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" })) }
                "B" -> cur = cur?.let { it.copy(bags = it.bags + (p.getOrElse(1) { "" } to p.getOrElse(2) { "" })) }
            }
        }
        cur?.let { out += it }
        return out.filter { it.date.length == 10 }
    }

    /** The records day by day, oldest day first; the records of one day stay in the order they were saved. */
    fun byDate(list: List<MixRecord>): List<Pair<String, List<MixRecord>>> =
        list.groupBy { it.date }.toSortedMap().map { it.key to it.value }

    /** "Feed 1", "Feed 2"... the next free name for a day. */
    fun nextTitle(list: List<MixRecord>, date: String): String = "Feed ${list.count { it.date == date } + 1}"
}
