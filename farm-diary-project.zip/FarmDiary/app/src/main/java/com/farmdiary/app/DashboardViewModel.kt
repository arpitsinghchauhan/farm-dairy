package com.farmdiary.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.domain.Dashboard
import com.farmdiary.app.domain.MonthSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.YearMonth

class DashboardViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))

    private val _month = MutableStateFlow(YearMonth.now())
    val month: StateFlow<YearMonth> = _month.asStateFlow()

    private val _summary = MutableStateFlow<MonthSummary?>(null)
    val summary: StateFlow<MonthSummary?> = _summary.asStateFlow()

    fun previous() {
        _month.value = _month.value.minusMonths(1)
        refresh()
    }

    fun next() {
        if (_month.value.isBefore(YearMonth.now())) {
            _month.value = _month.value.plusMonths(1)
            refresh()
        }
    }

    val canGoNext: Boolean get() = _month.value.isBefore(YearMonth.now())

    /** Reads the month again from the database (also called each time the screen opens). */
    fun refresh() {
        val m = _month.value
        viewModelScope.launch {
            try {
                val d = repo.getMonth(m.atDay(1).toString(), m.atEndOfMonth().toString())
                val result = Dashboard.build(m, d.reports, d.lines, d.extras, d.sales, d.eggSales)
                if (m == _month.value) _summary.value = result
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "dashboard load failed", e)
            }
        }
    }
}
