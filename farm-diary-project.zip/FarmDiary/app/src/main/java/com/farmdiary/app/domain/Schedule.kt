package com.farmdiary.app.domain

import java.time.ZonedDateTime
import java.util.Locale

const val MAX_SCHEDULE_ITEMS = 20

/** 24 hour clock -> "7:05 AM". */
fun formatTime(hour: Int, minute: Int): String {
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    val ampm = if (hour < 12) "AM" else "PM"
    return String.format(Locale.ENGLISH, "%d:%02d %s", h12, minute, ampm)
}

/** The next moment (today, or tomorrow if it has passed) when the clock shows [hour]:[minute]. */
fun nextTriggerMillis(hour: Int, minute: Int, now: ZonedDateTime = ZonedDateTime.now()): Long {
    var t = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
    if (!t.isAfter(now)) t = t.plusDays(1)
    return t.toInstant().toEpochMilli()
}

data class ScheduleForm(
    val key: Long,
    val id: Long = 0,
    val title: String = "",
    val details: String = "",
    val hour: Int = 7,
    val minute: Int = 0,
    val reminderOn: Boolean = false
) {
    val timeText: String get() = formatTime(hour, minute)
}
