package com.farmdiary.app.domain

import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.Locale

const val MAX_SCHEDULE_ITEMS = 20

/** 24 hour clock -> "7:05 AM". */
fun formatTime(hour: Int, minute: Int): String {
    val h12 = if (hour % 12 == 0) 12 else hour % 12
    val ampm = if (hour < 12) "AM" else "PM"
    return String.format(Locale.ENGLISH, "%d:%02d %s", h12, minute, ampm)
}

/** The next moment (today, or tomorrow if it has passed) when the clock shows [hour]:[minute]. */
fun nextTriggerMillis(hour: Int, minute: Int, now: ZonedDateTime = ZonedDateTime.now()): Long {
    var t = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
    if (!t.isAfter(now)) t = t.plusDays(1)
    return t.toInstant().toEpochMilli()
}

object ScheduleKind {
    const val DAILY = "DAILY"
    const val WEEKLY = "WEEKLY"
    const val MONTHLY = "MONTHLY"
    val all = listOf(DAILY, WEEKLY, MONTHLY)

    fun label(kind: String) = when (kind) {
        WEEKLY -> "Weekly"
        MONTHLY -> "Monthly"
        else -> "Daily"
    }

    /** How long before the task the reminder rings: daily 5 minutes, weekly 1 day, monthly 5 days. */
    fun leadMinutes(kind: String): Long = when (kind) {
        WEEKLY -> 24L * 60
        MONTHLY -> 5L * 24 * 60
        else -> 5L
    }

    fun leadText(kind: String) = when (kind) {
        WEEKLY -> "Tomorrow"
        MONTHLY -> "In 5 days"
        else -> "In 5 minutes"
    }

    fun reminderLabel(kind: String) = when (kind) {
        WEEKLY -> "Remind me 1 day before"
        MONTHLY -> "Remind me 5 days before"
        else -> "Remind me 5 minutes before"
    }
}

val WEEK_DAY_LETTERS = listOf("M", "T", "W", "T", "F", "S", "S")
val WEEK_DAY_NAMES = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

/** Does the task fall on [date]? Day of week is 1 = Monday ... 7 = Sunday. A monthly day after the month's end (31 in June) falls on the last day. */
fun occursOn(kind: String, dayOfWeek: Int, dayOfMonth: Int, date: LocalDate): Boolean = when (kind) {
    ScheduleKind.WEEKLY -> date.dayOfWeek.value == dayOfWeek
    ScheduleKind.MONTHLY -> date.dayOfMonth == Math.min(dayOfMonth, date.lengthOfMonth())
    else -> true
}

/** The first time the task happens strictly after [after]. */
fun nextOccurrence(kind: String, hour: Int, minute: Int, dayOfWeek: Int, dayOfMonth: Int, after: ZonedDateTime): ZonedDateTime {
    var date = after.toLocalDate()
    repeat(400) {
        if (occursOn(kind, dayOfWeek, dayOfMonth, date)) {
            val at = date.atTime(hour, minute).atZone(after.zone)
            if (at.isAfter(after)) return at
        }
        date = date.plusDays(1)
    }
    return after.plusDays(1)
}

/** When the next reminder should ring: the task time minus the lead time (5 minutes, 1 day or 5 days). */
fun nextReminderMillis(
    kind: String, hour: Int, minute: Int, dayOfWeek: Int, dayOfMonth: Int,
    now: ZonedDateTime = ZonedDateTime.now()
): Long {
    val lead = ScheduleKind.leadMinutes(kind)
    val occurrence = nextOccurrence(kind, hour, minute, dayOfWeek, dayOfMonth, now.plusMinutes(lead))
    return occurrence.minusMinutes(lead).toInstant().toEpochMilli()
}

data class ScheduleForm(
    val key: Long,
    val id: Long = 0,
    val title: String = "",
    val details: String = "",
    val hour: Int = 7,
    val minute: Int = 0,
    val reminderOn: Boolean = false,
    val kind: String = ScheduleKind.DAILY,
    val dayOfWeek: Int = 1,
    val dayOfMonth: Int = 1
) {
    val timeText: String get() = formatTime(hour, minute)
}
