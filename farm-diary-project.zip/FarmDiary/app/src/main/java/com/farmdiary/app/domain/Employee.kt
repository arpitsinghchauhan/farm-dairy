package com.farmdiary.app.domain

import com.farmdiary.app.data.EmployeePaymentEntity
import java.time.YearMonth

object PayMode {
    const val CASH = "CASH"
    const val ONLINE = "ONLINE"
}

object EmployeeRules {
    const val MAX_EMPLOYEES = 10

    /** [others] are the names of the other active employees (to stop two with the same name). */
    fun validateName(name: String, others: List<String>): List<String> {
        val n = name.trim()
        if (n.isEmpty()) return listOf("Please enter the employee name.")
        if (n.length > 40) return listOf("The name is too long (40 letters at most).")
        if (others.any { it.trim().equals(n, ignoreCase = true) }) return listOf("An employee with this name already exists.")
        return emptyList()
    }

    fun validateSalary(salary: String): List<String> {
        if (Calc.isInvalid(salary)) return listOf("Please enter a valid salary (numbers only, not negative).")
        return emptyList()
    }

    fun validateAmount(amount: String): List<String> {
        if (Calc.isInvalid(amount)) return listOf("Please enter a valid amount (numbers only, not negative).")
        if (Calc.parse(amount) <= 0.0) return listOf("Please enter the amount given.")
        return emptyList()
    }
}

data class EmployeeTotals(val cash: Double, val online: Double) {
    val total: Double get() = cash + online
}

/** All the payments of one date, newest entry first. */
data class PaymentDay(val date: String, val entries: List<EmployeePaymentEntity>) {
    val total: Double get() = entries.sumOf { it.amount }
}

object EmployeeCalc {
    fun totals(payments: List<EmployeePaymentEntity>): EmployeeTotals {
        val live = payments.filter { !it.deleted }
        return EmployeeTotals(
            cash = live.filter { it.mode == PayMode.CASH }.sumOf { it.amount },
            online = live.filter { it.mode == PayMode.ONLINE }.sumOf { it.amount }
        )
    }

    /** Payments of one employee grouped by date, latest date first; within a date the newest entry is first. */
    fun byDate(payments: List<EmployeePaymentEntity>, employeeId: String): List<PaymentDay> =
        payments.filter { !it.deleted && it.employeeId == employeeId }
            .groupBy { it.date }
            .toSortedMap(compareByDescending { it })
            .map { (d, list) -> PaymentDay(d, list.sortedByDescending { it.createdAt }) }

    /** One month of one employee: salary, what was paid (cash / online) and what is left to pay. */
    fun statement(payments: List<EmployeePaymentEntity>, employeeId: String, salary: Double, month: YearMonth): MonthStatement {
        val prefix = month.toString() // yyyy-MM
        val entries = payments
            .filter { !it.deleted && it.employeeId == employeeId && it.date.startsWith(prefix) }
            .sortedWith(compareBy({ it.date }, { it.createdAt }))
        val t = totals(entries)
        return MonthStatement(month, salary, t.cash, t.online, entries)
    }
}

/** Left to pay = salary - paid. A negative value means more was paid than the salary (an advance). */
data class MonthStatement(
    val month: YearMonth,
    val salary: Double,
    val cash: Double,
    val online: Double,
    val entries: List<EmployeePaymentEntity>
) {
    val paid: Double get() = cash + online
    val leftToPay: Double get() = salary - paid
}
