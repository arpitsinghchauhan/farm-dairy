package com.farmdiary.app.domain

import com.farmdiary.app.data.EmployeeAttendanceEntity
import com.farmdiary.app.data.EmployeePaymentEntity
import java.time.YearMonth

object PayMode {
    const val CASH = "CASH"
    const val ONLINE = "ONLINE"
}

object Attendance {
    const val ABSENT = "ABSENT"
    const val HALF = "HALF"

    fun id(employeeId: String, date: String) = "$employeeId|$date"

    /** One tap on a day: present -> absent -> half day -> present. */
    fun next(current: String?): String? = when (current) {
        null -> ABSENT
        ABSENT -> HALF
        else -> null
    }
}

object EmployeeRules {
    const val MAX_EMPLOYEES = 10

    /** [others] are the names of the other active employees (to stop two with the same name). */
    fun validateName(name: String, others: List<String>): List<String> {
        val n = name.trim()
        if (n.isEmpty()) return listOf("Please enter the employee name.")
        if (n.length > 40) return listOf("The name is too long (40 letters at most).")
        if (others.any { it.trim().equals(n, ignoreCase = true) }) return listOf("An employee with this name already exists.")
        return emptyList()
    }

    /** Mobile and Aadhaar are optional. When written: mobile is 10 digits, Aadhaar is 12 digits. */
    fun validateContact(mobile: String, aadhaar: String): List<String> {
        val out = mutableListOf<String>()
        if (mobile.isNotEmpty() && !(mobile.length == 10 && mobile.all { it.isDigit() })) out += "Mobile number must be 10 digits."
        if (aadhaar.isNotEmpty() && !(aadhaar.length == 12 && aadhaar.all { it.isDigit() })) out += "Aadhaar number must be 12 digits."
        return out
    }

    fun validateSalary(salary: String): List<String> {
        if (Calc.isInvalid(salary)) return listOf("Please enter a valid salary (numbers only, not negative).")
        return emptyList()
    }

    fun validateAmount(amount: String): List<String> {
        if (Calc.isInvalid(amount)) return listOf("Please enter a valid amount (numbers only, not negative).")
        if (Calc.parse(amount) <= 0.0) return listOf("Please enter the amount given.")
        return emptyList()
    }
}

data class EmployeeTotals(val cash: Double, val online: Double) {
    val total: Double get() = cash + online
}

/** All the payments of one date, newest entry first. */
data class PaymentDay(val date: String, val entries: List<EmployeePaymentEntity>) {
    val total: Double get() = entries.sumOf { it.amount }
}

object EmployeeCalc {
    fun totals(payments: List<EmployeePaymentEntity>): EmployeeTotals {
        val live = payments.filter { !it.deleted }
        return EmployeeTotals(
            cash = live.filter { it.mode == PayMode.CASH }.sumOf { it.amount },
            online = live.filter { it.mode == PayMode.ONLINE }.sumOf { it.amount }
        )
    }

    /** Payments of one employee grouped by date, latest date first; within a date the newest entry is first. */
    fun byDate(payments: List<EmployeePaymentEntity>, employeeId: String): List<PaymentDay> =
        payments.filter { !it.deleted && it.employeeId == employeeId }
            .groupBy { it.date }
            .toSortedMap(compareByDescending { it })
            .map { (d, list) -> PaymentDay(d, list.sortedByDescending { it.createdAt }) }

    /** One month of one employee: salary, what was paid (cash / online) and what is left to pay. */
    fun statement(
        payments: List<EmployeePaymentEntity>, employeeId: String, salary: Double, month: YearMonth,
        attendance: List<EmployeeAttendanceEntity> = emptyList()
    ): MonthStatement {
        val prefix = month.toString() // yyyy-MM
        val entries = payments
            .filter { !it.deleted && it.employeeId == employeeId && it.date.startsWith(prefix) }
            .sortedWith(compareBy({ it.date }, { it.createdAt }))
        val t = totals(entries)
        val days = attendance
            .filter { !it.deleted && it.employeeId == employeeId && it.date.startsWith(prefix) }
            .sortedBy { it.date }
        return MonthStatement(month, salary, t.cash, t.online, entries, days)
    }
}

/** Left to pay = salary - paid. A negative value means more was paid than the salary (an advance). */
data class MonthStatement(
    val month: YearMonth,
    val salary: Double,
    val cash: Double,
    val online: Double,
    val entries: List<EmployeePaymentEntity>,
    /** Absent and half days of this month. */
    val attendance: List<EmployeeAttendanceEntity> = emptyList()
) {
    val paid: Double get() = cash + online
    val absentDays: Int get() = attendance.count { it.status == Attendance.ABSENT }
    val halfDays: Int get() = attendance.count { it.status == Attendance.HALF }
    /** Salary of one day: the monthly salary divided by the days of that month. */
    val perDay: Double get() = if (salary > 0.0) salary / month.lengthOfMonth() else 0.0
    /** Salary cut for the absent days (a half day cuts half). */
    val deduction: Double get() = Math.round(perDay * (absentDays + 0.5 * halfDays) * 100.0) / 100.0
    /** Salary to give after the cut. */
    val payable: Double get() = Math.max(salary - deduction, 0.0)
    val leftToPay: Double get() = payable - paid
}
