package com.farmdiary.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.Reminders
import com.farmdiary.app.SchedulerViewModel
import com.farmdiary.app.domain.MAX_SCHEDULE_ITEMS
import com.farmdiary.app.domain.ScheduleKind
import com.farmdiary.app.domain.WEEK_DAY_LETTERS
import com.farmdiary.app.domain.WEEK_DAY_NAMES
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign

@Composable
fun SchedulerScreen(vm: SchedulerViewModel, onBack: () -> Unit) {
    val items by vm.items.collectAsState()
    val dirty by vm.dirty.collectAsState()
    val message by vm.message.collectAsState()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var askDiscard by remember { mutableStateOf(false) }
    var pendingKey by remember { mutableStateOf<Long?>(null) }
    var tab by remember { mutableStateOf(ScheduleKind.DAILY) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            pendingKey?.let { k -> vm.edit(k) { it.copy(reminderOn = false) } }
            vm.say("Notifications are blocked. Allow notifications for Layer Diary in your phone Settings to get reminders.")
        }
        pendingKey = null
    }

    val leave: () -> Unit = {
        if (dirty) {
            askDiscard = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = leave)

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved changes in the schedule.") },
            confirmButton = {
                TextButton(onClick = {
                    askDiscard = false
                    vm.reload()
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = { TextButton(onClick = { askDiscard = false }) { Text("Keep editing") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Scheduler", leave) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Daily / Weekly / Monthly tabs
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScheduleKind.all.forEach { k ->
                    val chosen = k == tab
                    val count = items.count { it.kind == k }
                    Text(
                        "${ScheduleKind.label(k)} ($count)",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (chosen) OnPrimary else TextHi,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (chosen) Brush.linearGradient(listOf(Primary, Primary)) else Brush.linearGradient(listOf(PanelHi, PanelHi)))
                            .clickable { tab = k }
                            .padding(vertical = 14.dp)
                    )
                }
            }
            Text(
                when (tab) {
                    ScheduleKind.WEEKLY -> "Tasks for one day of the week. You get a reminder 1 day before."
                    ScheduleKind.MONTHLY -> "Tasks for one date of the month. You get a reminder 5 days before."
                    else -> "Tasks for every day. You get a reminder 5 minutes before."
                },
                fontSize = 17.sp,
                color = TextLo
            )

            val shown = items.filter { it.kind == tab }
            if (shown.isEmpty()) {
                Text("No ${ScheduleKind.label(tab).lowercase()} tasks yet. Add your first task.", fontSize = 18.sp)
            }

            shown.forEach { item ->
                SectionCard(item.title.ifBlank { "New task" }, "⏰") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            item.timeText,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Sun,
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(PanelHi)
                                .clickable {
                                    TimePickerDialog(
                                        context,
                                        { _, h, m -> vm.edit(item.key) { it.copy(hour = h, minute = m) } },
                                        item.hour,
                                        item.minute,
                                        false
                                    ).show()
                                }
                                .padding(horizontal = 18.dp, vertical = 10.dp)
                        )
                        IconButton(onClick = { vm.remove(item.key) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove ${item.title}")
                        }
                    }
                    if (item.kind == ScheduleKind.WEEKLY) {
                        Text("Day of the week: ${WEEK_DAY_NAMES[(item.dayOfWeek - 1).coerceIn(0, 6)]}", fontSize = 17.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            WEEK_DAY_LETTERS.forEachIndexed { i, letter ->
                                val chosen = item.dayOfWeek == i + 1
                                Text(
                                    letter,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (chosen) OnPrimary else TextHi,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (chosen) Brush.linearGradient(listOf(Primary, Primary)) else Brush.linearGradient(listOf(PanelHi, PanelHi)))
                                        .clickable { vm.edit(item.key) { it.copy(dayOfWeek = i + 1) } }
                                        .padding(vertical = 12.dp)
                                )
                            }
                        }
                    }
                    if (item.kind == ScheduleKind.MONTHLY) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(onClick = { vm.edit(item.key) { it.copy(dayOfMonth = if (it.dayOfMonth <= 1) 31 else it.dayOfMonth - 1) } }) {
                                Text("−", fontSize = 24.sp)
                            }
                            Text("Date of the month: ${item.dayOfMonth}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            OutlinedButton(onClick = { vm.edit(item.key) { it.copy(dayOfMonth = if (it.dayOfMonth >= 31) 1 else it.dayOfMonth + 1) } }) {
                                Text("+", fontSize = 24.sp)
                            }
                        }
                        if (item.dayOfMonth > 28) {
                            Text("In months with fewer days, this task falls on the last day of the month.", fontSize = 15.sp, color = TextLo)
                        }
                    }
                    OutlinedTextField(
                        value = item.title,
                        onValueChange = { v -> vm.edit(item.key) { it.copy(title = v) } },
                        label = { Text("Task (e.g. Feed time)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = item.details,
                        onValueChange = { v -> vm.edit(item.key) { it.copy(details = v) } },
                        label = { Text("Note (e.g. 2 tanks of water)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔔 ${ScheduleKind.reminderLabel(item.kind)}", fontSize = 18.sp, modifier = Modifier.weight(1f))
                        Switch(
                            checked = item.reminderOn,
                            onCheckedChange = { on ->
                                vm.edit(item.key) { it.copy(reminderOn = on) }
                                if (on && Build.VERSION.SDK_INT >= 33 && !Reminders.canNotify(context)) {
                                    pendingKey = item.key
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                        )
                    }
                }
            }

            if (items.size < MAX_SCHEDULE_ITEMS) {
                OutlinedButton(onClick = { vm.add(tab) }, modifier = Modifier.fillMaxWidth().height(60.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text("  Add ${ScheduleKind.label(tab).lowercase()} task (${items.size}/$MAX_SCHEDULE_ITEMS)", fontSize = 18.sp)
                }
            }

            OutlinedButton(
                onClick = {
                    if (Build.VERSION.SDK_INT >= 33 && !Reminders.canNotify(context)) {
                        pendingKey = null
                        vm.say("Allow notifications first, then press the test button again.")
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        Reminders.ensureChannel(context)
                        Reminders.showTest(context)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(60.dp)
            ) { Text("🔊  Test reminder sound", fontSize = 18.sp) }
            TextButton(onClick = { Reminders.openChannelSettings(context) }) {
                Text("No sound? Open phone sound settings", fontSize = 16.sp)
            }

            GradientButton(
                text = "💾  Save Schedule",
                onClick = { vm.save() },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Reminders are set when you press Save Schedule. Daily tasks ring 5 minutes before, weekly 1 day before, monthly 5 days before.",
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}
