package com.farmdiary.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.Reminders
import com.farmdiary.app.SchedulerViewModel
import com.farmdiary.app.domain.MAX_SCHEDULE_ITEMS

@Composable
fun SchedulerScreen(vm: SchedulerViewModel, onBack: () -> Unit) {
    val items by vm.items.collectAsState()
    val dirty by vm.dirty.collectAsState()
    val message by vm.message.collectAsState()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var askDiscard by remember { mutableStateOf(false) }
    var pendingKey by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            pendingKey?.let { k -> vm.edit(k) { it.copy(reminderOn = false) } }
            vm.say("Notifications are blocked. Allow notifications for Farm Diary in your phone Settings to get reminders.")
        }
        pendingKey = null
    }

    val leave: () -> Unit = {
        if (dirty) {
            askDiscard = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = leave)

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved changes in the schedule.") },
            confirmButton = {
                TextButton(onClick = {
                    askDiscard = false
                    vm.reload()
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = { TextButton(onClick = { askDiscard = false }) { Text("Keep editing") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Scheduler", leave) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Your daily farm tasks. Tap a time to change it. Turn on the bell to get a reminder every day.",
                fontSize = 18.sp,
                color = TextLo
            )

            if (items.isEmpty()) {
                Text("No tasks yet. Add your first task.", fontSize = 18.sp)
            }

            items.forEach { item ->
                SectionCard(item.title.ifBlank { "New task" }, "⏰") {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            item.timeText,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Sun,
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(PanelHi)
                                .clickable {
                                    TimePickerDialog(
                                        context,
                                        { _, h, m -> vm.edit(item.key) { it.copy(hour = h, minute = m) } },
                                        item.hour,
                                        item.minute,
                                        false
                                    ).show()
                                }
                                .padding(horizontal = 18.dp, vertical = 10.dp)
                        )
                        IconButton(onClick = { vm.remove(item.key) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove ${item.title}")
                        }
                    }
                    OutlinedTextField(
                        value = item.title,
                        onValueChange = { v -> vm.edit(item.key) { it.copy(title = v) } },
                        label = { Text("Task (e.g. Feed time)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = item.details,
                        onValueChange = { v -> vm.edit(item.key) { it.copy(details = v) } },
                        label = { Text("Note (e.g. 2 tanks of water)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔔 Remind me every day", fontSize = 18.sp)
                        Switch(
                            checked = item.reminderOn,
                            onCheckedChange = { on ->
                                vm.edit(item.key) { it.copy(reminderOn = on) }
                                if (on && Build.VERSION.SDK_INT >= 33 && !Reminders.canNotify(context)) {
                                    pendingKey = item.key
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                        )
                    }
                }
            }

            if (items.size < MAX_SCHEDULE_ITEMS) {
                OutlinedButton(onClick = { vm.add() }, modifier = Modifier.fillMaxWidth().height(60.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text("  Add task (${items.size}/$MAX_SCHEDULE_ITEMS)", fontSize = 18.sp)
                }
            }

            GradientButton(
                text = "💾  Save Schedule",
                onClick = { vm.save() },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Reminders are set when you press Save Schedule.",
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}
