package com.farmdiary.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.domain.LowStock
import com.farmdiary.app.domain.ScheduleKind
import com.farmdiary.app.domain.nextReminderMillis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Low stock notifications: when the stock falls low, and again every morning at 8:00 while it stays low. */
object StockAlerts {
    private const val FEED_ID = 2_000_000_101L
    private const val TRAY_ID = 2_000_000_102L
    private const val ALARM_CODE = 101_101
    private const val HOUR = 8

    /** Posts a notification for each low item. With [oncePerDay] an item that was already notified today is skipped. */
    fun check(context: Context, stock: FarmStockEntity, oncePerDay: Boolean) {
        if (stock.updatedAt <= 0L) return
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        fun notifyOnce(key: String, id: Long, low: Boolean, title: String, text: String) {
            if (!low) { prefs.edit().remove(key).apply(); return }
            if (oncePerDay && prefs.getString(key, "") == today) return
            Reminders.show(context, id, title, text)
            prefs.edit().putString(key, today).apply()
        }
        notifyOnce(
            "low_feed_day", FEED_ID, LowStock.feedLow(stock.feedBags), "Feed stock is low",
            "Only ${com.farmdiary.app.domain.Calc.fmt(stock.feedBags)} bags left (below ${com.farmdiary.app.domain.Calc.fmt(LowStock.FEED_MIN_BAGS)}). Time to buy feed."
        )
        notifyOnce(
            "low_tray_day", TRAY_ID, LowStock.traysLow(stock.blankTrays), "Tray stock is low",
            "Only ${com.farmdiary.app.domain.Calc.fmt(com.farmdiary.app.domain.Calc.bundles(stock.blankTrays.toDouble()))} tray bundles left (below ${com.farmdiary.app.domain.Calc.fmt(LowStock.TRAY_MIN_BUNDLES)}). Time to buy trays."
        )
    }

    /** Arms the 8:00 AM check for the next morning. Called at app start, after boot, and after each check. */
    fun scheduleDaily(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            context, ALARM_CODE, Intent(context, LowStockReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = nextReminderMillis(ScheduleKind.DAILY, HOUR, 0, 1, 1)
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) {
            AppLog.e("low stock alarm failed", e)
        }
    }
}

class LowStockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(app).dao().getStock()?.let { StockAlerts.check(app, it, oncePerDay = false) }
            } catch (e: Exception) {
                AppLog.e("low stock check failed", e)
            } finally {
                StockAlerts.scheduleDaily(app)
                pending.finish()
            }
        }
    }
}
