package com.farmdiary.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.live.LiveSync
import kotlinx.coroutines.launch

/** The Firestore security rules for the service: a farm's data can be read and written only by the members of that farm. */
private const val RULES_TEXT = "rules_version = '2';\n" +
    "service cloud.firestore {\n" +
    "  match /databases/{database}/documents {\n" +
    "    function signedIn() { return request.auth != null; }\n" +
    "    function isMember(farmId) {\n" +
    "      return signedIn() && exists(/databases/\$(database)/documents/farms/\$(farmId)/members/\$(request.auth.uid));\n" +
    "    }\n" +
    "    function isOwner(farmId) {\n" +
    "      return signedIn() && get(/databases/\$(database)/documents/farms/\$(farmId)).data.ownerUid == request.auth.uid;\n" +
    "    }\n" +
    "    match /userFarms/{uid} {\n" +
    "      allow read, write: if signedIn() && request.auth.uid == uid;\n" +
    "    }\n" +
    "    match /farms/{farmId} {\n" +
    "      allow create: if signedIn() && request.resource.data.ownerUid == request.auth.uid;\n" +
    "      allow read: if isMember(farmId);\n" +
    "      allow update: if isOwner(farmId);\n" +
    "      match /members/{uid} {\n" +
    "        allow read: if isMember(farmId) || (signedIn() && request.auth.uid == uid);\n" +
    "        allow create: if signedIn() && request.auth.uid == uid && (\n" +
    "          get(/databases/\$(database)/documents/farms/\$(farmId)).data.ownerUid == request.auth.uid ||\n" +
    "          exists(/databases/\$(database)/documents/farms/\$(farmId)/invites/\$(request.resource.data.code)));\n" +
    "        allow delete: if isOwner(farmId);\n" +
    "      }\n" +
    "      match /invites/{code} {\n" +
    "        allow read, create, delete: if isOwner(farmId);\n" +
    "      }\n" +
    "      match /changes/{doc} {\n" +
    "        allow read, create: if isMember(farmId);\n" +
    "      }\n" +
    "    }\n" +
    "  }\n" +
    "}\n"

@Composable
private fun LiveText(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 200) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else KeyboardType.Text),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
            focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
            focusedLabelColor = Primary, unfocusedLabelColor = TextLo
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

/** Live sync between the phones of a farm: set-up, sign in, create or join a farm, and the connected view. */
@Composable
fun LiveSyncCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val st by LiveSync.status.collectAsState()
    var projectId by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var farmName by remember { mutableStateOf("") }
    var invite by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var members by remember { mutableStateOf(listOf<Triple<String, String, String>>()) }

    LaunchedEffect(st.farmId, st.signedIn) {
        if (st.connected) members = LiveSync.members(context)
    }

    fun copyRules() {
        (context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
            ?.setPrimaryClip(ClipData.newPlainText("Firestore rules", RULES_TEXT))
        note = "The Firebase security rules are copied. Paste them in Firestore > Rules and press Publish."
    }

    AccentCard("Live sync between phones", "🔄", SkyBrush, Sky) {
        when {
            !st.projectSet -> {
                Text("Set-up (once, by the person who runs the service): type the Firebase project details.", fontSize = 15.sp, color = TextLo)
                LiveText("Project ID", projectId) { projectId = it; note = "" }
                LiveText("Web API key", apiKey) { apiKey = it; note = "" }
                GradientButton(
                    "Save",
                    onClick = {
                        val problems = LiveSync.saveProject(context, projectId, apiKey)
                        note = problems.joinToString(" ")
                    },
                    modifier = Modifier.fillMaxWidth(), brush = SkyBrush
                )
                OutlinedButton(onClick = { copyRules() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("Copy Firebase rules", fontSize = 18.sp)
                }
            }

            !st.signedIn -> {
                Text(
                    "Sign in with your own email and password. Every person has their own account; the data of each farm is private to its members.",
                    fontSize = 15.sp, color = TextLo
                )
                LiveText("Email", email) { email = it; note = "" }
                LiveText("Password (6 or more)", password, secret = true) { password = it; note = "" }
                GradientButton(
                    if (st.busy) "Please wait..." else "Sign in",
                    onClick = { scope.launch { note = LiveSync.signIn(context, email, password, create = false) ?: ""; if (note.isEmpty()) password = "" } },
                    modifier = Modifier.fillMaxWidth(), enabled = !st.busy, brush = SkyBrush
                )
                OutlinedButton(
                    onClick = { scope.launch { note = LiveSync.signIn(context, email, password, create = true) ?: ""; if (note.isEmpty()) password = "" } },
                    modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !st.busy
                ) { Text("Create a new account", fontSize = 18.sp) }
                TextButton(
                    onClick = {
                        scope.launch {
                            val e = LiveSync.resetPassword(context, email)
                            note = e ?: "An email to set a new password was sent to ${email.trim()}."
                        }
                    }
                ) { Text("Forgot password?", fontSize = 16.sp) }
            }

            st.farmId.isEmpty() -> {
                Text("Signed in as ${st.email}", fontSize = 15.sp, color = TextLo)
                Text("Start a new farm:", fontSize = 17.sp)
                LiveText("Farm name", farmName) { farmName = it; note = "" }
                GradientButton(
                    if (st.busy) "Please wait..." else "Create my farm",
                    onClick = { scope.launch { note = LiveSync.createFarm(context, farmName) ?: "" } },
                    modifier = Modifier.fillMaxWidth(), enabled = !st.busy, brush = SkyBrush
                )
                Text("Or join a farm with the invite code the owner gave you:", fontSize = 17.sp)
                LiveText("Invite code", invite) { invite = it; note = "" }
                OutlinedButton(
                    onClick = { scope.launch { note = LiveSync.joinFarm(context, invite) ?: "" } },
                    modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !st.busy
                ) { Text("Join this farm", fontSize = 18.sp) }
                TextButton(onClick = { LiveSync.signOut(context); note = "" }) { Text("Sign out", fontSize = 16.sp) }
            }

            else -> {
                Text("Connected: ${st.farmName}", fontSize = 18.sp, color = Mint)
                Text("${st.email}  •  " + if (st.isOwner) "owner" else "member", fontSize = 15.sp, color = TextLo)
                Text(
                    if (st.lastSync.isEmpty()) "Last sync: not yet" else "Last sync: ${st.lastSync}",
                    fontSize = 15.sp, color = TextLo
                )
                Text("Data is sent and received by itself.", fontSize = 15.sp, color = TextLo)
                if (st.error.isNotEmpty()) Text(st.error, color = MaterialTheme.colorScheme.error, fontSize = 15.sp)
                GradientButton(
                    if (st.busy) "Syncing..." else "Sync now",
                    onClick = { scope.launch { LiveSync.sync(context, notify = false) } },
                    modifier = Modifier.fillMaxWidth(), enabled = !st.busy, brush = SkyBrush
                )
                if (st.isOwner) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                val (code, err) = LiveSync.createInvite(context)
                                if (code == null) {
                                    note = err ?: "Could not make the invite."
                                } else {
                                    val send = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "Join my farm in Layer Diary. Sign in, then use this invite code: $code")
                                    }
                                    try {
                                        context.startActivity(Intent.createChooser(send, "Invite a staff member").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                        note = "Invite code: $code"
                                    } catch (e: Exception) {
                                        note = "Invite code: $code"
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !st.busy
                    ) { Text("Invite a staff member", fontSize = 18.sp) }
                    if (members.isNotEmpty()) {
                        Text("Members", fontSize = 17.sp)
                        members.forEach { (uid, mail, role) ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${mail.ifBlank { "member" }}  ($role)", fontSize = 15.sp, color = TextHi, modifier = Modifier.weight(1f))
                                if (role != "owner") {
                                    TextButton(onClick = {
                                        scope.launch {
                                            note = LiveSync.removeMember(context, uid) ?: "Removed."
                                            members = LiveSync.members(context)
                                        }
                                    }) { Text("Remove", fontSize = 15.sp) }
                                }
                            }
                        }
                    }
                }
                OutlinedButton(
                    onClick = { LiveSync.signOut(context); note = "Signed out. The data on this phone stays." },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("Sign out", fontSize = 18.sp) }
            }
        }
        if (note.isNotEmpty()) Text(note, fontSize = 15.sp, color = Sun)
        if (st.error.isNotEmpty() && !st.connected) Text(st.error, fontSize = 15.sp, color = MaterialTheme.colorScheme.error)
    }
}
