package com.farmdiary.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.AuthState
import com.farmdiary.app.AuthViewModel
import java.time.LocalDate

@Composable
fun AuthScreen(vm: AuthViewModel) {
    val state by vm.state.collectAsState()
    val error by vm.error.collectAsState()
    val context = LocalContext.current
    val isSetup = state == AuthState.NeedSetup

    var phone by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf<LocalDate?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FarmLogo(height = 200.dp)
        Text(
            if (isSetup) "Create Your Login" else "Login",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = FarmRed
        )
        Text(
            if (isSetup) {
                "Enter your mobile number and date of birth. " +
                    "Use the same two things every time you log in."
            } else {
                "Enter your mobile number and date of birth."
            },
            fontSize = 18.sp
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { v -> if (v.length <= 10 && v.all { it.isDigit() }) { phone = v; vm.clearError() } },
            label = { Text("Mobile number (10 digits)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    showDatePicker(context, dob ?: LocalDate.of(1990, 1, 1)) {
                        dob = it
                        vm.clearError()
                    }
                },
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Date of birth (tap to choose)", fontSize = 16.sp)
                Text(
                    dob?.format(displayDateFormat) ?: "Not chosen",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (dob == null) Color.Gray else FarmRed
                )
            }
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(4.dp))
        Button(
            onClick = { vm.submit(phone, dob) },
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text(if (isSetup) "Create Login" else "Login", fontSize = 22.sp) }
    }
}
