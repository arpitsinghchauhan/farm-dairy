package com.farmdiary.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.farmdiary.app.domain.Credentials
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.AuthState
import com.farmdiary.app.AuthViewModel
import java.time.LocalDate

@Composable
fun AuthScreen(vm: AuthViewModel) {
    val state by vm.state.collectAsState()
    val error by vm.error.collectAsState()
    val notice by vm.notice.collectAsState()
    val savedQuestion by vm.question.collectAsState()
    val setting = state == AuthState.NeedSetup || state == AuthState.NeedPin
    val forgot = state == AuthState.Forgot

    var phone by remember { mutableStateOf(vm.savedPhone()) }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    val fieldStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Normal)

    @Composable
    fun pinField(value: String, label: String, onChange: (String) -> Unit) = OutlinedTextField(
        value = value,
        onValueChange = { v -> if (v.length <= Credentials.PIN_MAX && v.all { it.isDigit() }) { onChange(v); vm.clearError() } },
        label = { Text(label) },
        colors = loginFieldColors(),
        textStyle = fieldStyle,
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FarmLogoFull(height = 190.dp)
        OutlinedTextField(
            value = phone,
            onValueChange = { v -> if (v.length <= 10 && v.all { it.isDigit() }) { phone = v; vm.clearError() } },
            label = { Text("Mobile number (10 digits)") },
            colors = loginFieldColors(),
            textStyle = fieldStyle,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        if (forgot) {
            if (savedQuestion.isBlank()) {
                Text(
                    "No security question was set on this login, so the PIN cannot be reset here.",
                    fontSize = 16.sp, color = MaterialTheme.colorScheme.error
                )
            } else {
                Text(savedQuestion, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextHi)
                OutlinedTextField(
                    value = answer,
                    onValueChange = { if (it.length <= 40) { answer = it; vm.clearError() } },
                    label = { Text("Your answer") },
                    colors = loginFieldColors(),
                    textStyle = fieldStyle,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                pinField(pin, "New PIN (4 to 6 digits)") { pin = it }
                pinField(confirm, "Confirm new PIN") { confirm = it }
            }
        } else {
            pinField(pin, if (setting) "Set PIN (4 to 6 digits)" else "PIN") { pin = it }
            if (setting) pinField(confirm, "Confirm PIN") { confirm = it }
            if (state == AuthState.NeedSetup) {
                ChoiceDropdown(
                    label = "Security question (for forgot PIN)",
                    selectedText = question,
                    options = Credentials.QUESTIONS.map { it to it },
                    onSelect = { question = it; vm.clearError() }
                )
                OutlinedTextField(
                    value = answer,
                    onValueChange = { if (it.length <= 40) { answer = it; vm.clearError() } },
                    label = { Text("Your answer") },
                    colors = loginFieldColors(),
                    textStyle = fieldStyle,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        notice?.let { Text(it, color = Primary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(4.dp))
        if (forgot) {
            if (savedQuestion.isNotBlank()) {
                GradientButton(
                    text = "Reset PIN",
                    onClick = { vm.resetPin(phone, answer, pin, confirm) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            TextButton(onClick = { pin = ""; confirm = ""; answer = ""; vm.cancelForgot() }) {
                Text("Back to login", fontSize = 17.sp, color = Primary)
            }
        } else {
            GradientButton(
                text = when (state) {
                    AuthState.NeedSetup -> "Create Login"
                    AuthState.NeedPin -> "Save PIN"
                    else -> "Login"
                },
                onClick = { vm.clearNotice(); vm.submit(phone, pin, confirm, question, answer) },
                modifier = Modifier.fillMaxWidth()
            )
            if (state == AuthState.LoggedOut) {
                TextButton(onClick = { pin = ""; vm.startForgot() }) {
                    Text("Forgot PIN?", fontSize = 17.sp, color = Primary)
                }
            }
        }
    }
}

/** Clear, coloured text for the login field so what is typed is always easy to see. */
@Composable
private fun loginFieldColors() = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
    focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
    focusedLabelColor = Primary, unfocusedLabelColor = TextLo,
    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent
)
