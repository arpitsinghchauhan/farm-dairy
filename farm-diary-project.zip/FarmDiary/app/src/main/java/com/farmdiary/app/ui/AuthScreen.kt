package com.farmdiary.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.farmdiary.app.domain.Credentials
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.AuthState
import com.farmdiary.app.AuthViewModel
import java.time.LocalDate

@Composable
fun AuthScreen(vm: AuthViewModel) {
    val state by vm.state.collectAsState()
    val error by vm.error.collectAsState()
    val setting = state == AuthState.NeedSetup || state == AuthState.NeedPin

    var phone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FarmLogoFull(height = 190.dp)
        if (state == AuthState.NeedPin) {
            Text("Set a PIN for your login. You will use your mobile number and this PIN from now on.", fontSize = 16.sp, color = TextLo)
        }
        OutlinedTextField(
            value = phone,
            onValueChange = { v -> if (v.length <= 10 && v.all { it.isDigit() }) { phone = v; vm.clearError() } },
            label = { Text("Mobile number (10 digits)") },
            colors = loginFieldColors(),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = pin,
            onValueChange = { v -> if (v.length <= Credentials.PIN_MAX && v.all { it.isDigit() }) { pin = v; vm.clearError() } },
            label = { Text(if (setting) "Set PIN (4 to 6 digits)" else "PIN") },
            colors = loginFieldColors(),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        if (setting) {
            OutlinedTextField(
                value = confirm,
                onValueChange = { v -> if (v.length <= Credentials.PIN_MAX && v.all { it.isDigit() }) { confirm = v; vm.clearError() } },
                label = { Text("Confirm PIN") },
                colors = loginFieldColors(),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(4.dp))
        GradientButton(
            text = when (state) {
                AuthState.NeedSetup -> "Create Login"
                AuthState.NeedPin -> "Save PIN"
                else -> "Login"
            },
            onClick = { vm.submit(phone, pin, confirm) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Clear, coloured text for the login field so what is typed is always easy to see. */
@Composable
private fun loginFieldColors() = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
    focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
    focusedLabelColor = Primary, unfocusedLabelColor = TextLo,
    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent
)
