package com.farmdiary.app.domain

import com.farmdiary.app.data.FeedTxnEntity

object PurchaseCategory {
    const val FEED = "FEED"
    const val MEDICINE = "MEDICINE"
}

object FeedType {
    const val BUY = "BUY"
    const val ONLINE = "ONLINE"
    const val CASH = "CASH"
    /** Old balance already owed to the supplier before the user started using the app. */
    const val OPENING = "OPENING"
}

/** Everything that happened on one date, and the balance owed to the supplier at the end of that date. */
data class FeedDayRow(
    val date: String,
    val bags: Double,
    val opening: Double,
    val bought: Double,
    val online: Double,
    val cash: Double,
    val balance: Double,
    val entries: List<FeedTxnEntity>
)

data class FeedLedger(
    /** Oldest date first. */
    val rows: List<FeedDayRow>,
    val totalBags: Double,
    val totalOpening: Double,
    val totalBought: Double,
    val totalOnline: Double,
    val totalCash: Double
) {
    val totalPaid: Double get() = totalOnline + totalCash

    /** Money still to be paid to the supplier. Below zero means advance was paid. */
    val outstanding: Double get() = totalOpening + totalBought - totalPaid
}

object VendorRules {
    const val MAX_VENDORS = 5

    fun validateName(name: String, others: List<String>): List<String> {
        val n = name.trim()
        if (n.isEmpty()) return listOf("Please enter the vendor name.")
        if (n.length > 40) return listOf("The name is too long (40 letters at most).")
        if (others.any { it.trim().equals(n, ignoreCase = true) }) return listOf("This vendor is already added.")
        return emptyList()
    }

    /** Vendors are required once at least one is added. */
    fun validateChoice(vendor: String, vendorsAdded: Int): List<String> =
        if (vendorsAdded > 0 && vendor.isBlank()) listOf("Please select the vendor.") else emptyList()
}

object FeedCalc {
    /** Amount of a purchase: bags x (rate - discount per bag). */
    fun buyAmount(bags: Double, rate: Double, discountPerBag: Double): Double =
        bags * (rate - discountPerBag)

    fun validateBuy(bags: String, rate: String, discount: String, itemName: String? = null): List<String> {
        val errors = mutableListOf<String>()
        if (itemName != null && itemName.isBlank()) errors += "Please enter the medicine name."
        if (Calc.isInvalid(bags) || Calc.isInvalid(rate) || Calc.isInvalid(discount)) {
            errors += "Please enter a valid quantity (numbers only, not negative)."
            return errors
        }
        if (Calc.parse(bags) <= 0.0) errors += "Please enter the number of bags."
        if (Calc.parse(rate) <= 0.0) errors += "Please enter the feed rate per bag."
        if (Calc.parse(discount) > Calc.parse(rate)) errors += "Discount per bag cannot be more than the rate."
        return errors
    }

    fun validateOpening(amount: String): List<String> {
        if (Calc.isInvalid(amount)) return listOf("Please enter a valid amount (numbers only, not negative).")
        if (Calc.parse(amount) <= 0.0) return listOf("Please enter the old balance you still have to pay.")
        return emptyList()
    }

    fun validatePayment(amount: String): List<String> {
        if (Calc.isInvalid(amount)) return listOf("Please enter a valid amount (numbers only, not negative).")
        if (Calc.parse(amount) <= 0.0) return listOf("Please enter the amount paid.")
        return emptyList()
    }

    /** Builds the date-wise ledger. Deleted entries are ignored. */
    fun build(all: List<FeedTxnEntity>, category: String = PurchaseCategory.FEED, vendor: String? = null): FeedLedger {
        val live = all.filter { !it.deleted && it.category == category && (vendor == null || it.vendor == vendor) }
        var running = 0.0
        val rows = live
            .groupBy { it.date }
            .toSortedMap()
            .map { (date, list) ->
                val entries = list.sortedBy { it.createdAt }
                val opening = entries.filter { it.type == FeedType.OPENING }.sumOf { it.amount }
                val bought = entries.filter { it.type == FeedType.BUY }.sumOf { it.amount }
                val online = entries.filter { it.type == FeedType.ONLINE }.sumOf { it.amount }
                val cash = entries.filter { it.type == FeedType.CASH }.sumOf { it.amount }
                running += opening + bought - online - cash
                FeedDayRow(
                    date = date,
                    bags = entries.filter { it.type == FeedType.BUY }.sumOf { it.bags },
                    opening = opening,
                    bought = bought,
                    online = online,
                    cash = cash,
                    balance = running,
                    entries = entries
                )
            }
        return FeedLedger(
            rows = rows,
            totalBags = rows.sumOf { it.bags },
            totalOpening = rows.sumOf { it.opening },
            totalBought = rows.sumOf { it.bought },
            totalOnline = rows.sumOf { it.online },
            totalCash = rows.sumOf { it.cash }
        )
    }
}
