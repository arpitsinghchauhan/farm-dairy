package com.farmdiary.app.domain

/** When the stock is low enough to warn: feed below 130 bags, blank trays below 40 bundles. */
object LowStock {
    const val FEED_MIN_BAGS = 130.0
    const val TRAY_MIN_BUNDLES = 40.0

    fun feedLow(bags: Double): Boolean = bags < FEED_MIN_BAGS
    fun traysLow(trays: Int): Boolean = Calc.bundles(trays.toDouble()) < TRAY_MIN_BUNDLES

    /** Lines to show, e.g. "Feed: 120 bags left (below 130)". Empty when nothing is low. */
    fun messages(bags: Double, trays: Int): List<String> = buildList {
        if (feedLow(bags)) add("Feed: ${Calc.fmt(bags)} bags left (below ${Calc.fmt(FEED_MIN_BAGS)})")
        if (traysLow(trays)) add("Tray bundles: ${Calc.fmt(Calc.bundles(trays.toDouble()))} left (below ${Calc.fmt(TRAY_MIN_BUNDLES)})")
    }
}
