package com.farmdiary.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * A small log file kept on the phone: app start, saves that failed, data shared or added. It holds no PIN and no farm figures.
 * The newest part is kept (about 200 KB). The user can download it from Share Data.
 */
object AppLog {
    private const val FILE = "farmdiary-log.txt"
    private const val MAX_BYTES = 200 * 1024
    private val stamp = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss", Locale.ENGLISH)
    private var dir: File? = null

    fun init(context: Context) {
        dir = context.applicationContext.filesDir
    }

    private fun file(): File? = dir?.let { File(it, FILE) }

    @Synchronized
    private fun write(level: String, text: String) {
        try {
            val f = file() ?: return
            if (f.length() > MAX_BYTES) {
                val keep = f.readText().takeLast(MAX_BYTES / 2)
                f.writeText(keep.substringAfter('\n', keep))
            }
            f.appendText("${LocalDateTime.now().format(stamp)}  $level  $text\n")
        } catch (e: Exception) {
            AppLog.e("log write failed", e)
        }
    }

    fun i(text: String) {
        android.util.Log.i("FarmDiary", text)
        write("INFO ", text)
    }

    fun e(text: String, error: Throwable? = null) {
        android.util.Log.e("FarmDiary", text, error)
        write("ERROR", if (error == null) text else "$text: ${error.javaClass.simpleName}: ${error.message}")
    }

    /** The log text, or a short note if nothing was logged yet. */
    fun text(): String = try {
        file()?.takeIf { it.exists() }?.readText()?.ifBlank { null } ?: "No log entries yet."
    } catch (e: Exception) {
        "The log could not be read."
    }

    /** Saves the log in the Downloads folder. Returns the file name, or null if the phone refused. */
    fun saveToDownloads(context: Context, appVersion: String): String? {
        return try {
            val name = "LayerDiary_Log_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy_HHmm", Locale.ENGLISH)) + ".txt"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri: Uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            val header = "Layer Diary log  (app $appVersion, Android ${android.os.Build.VERSION.RELEASE}, ${android.os.Build.MODEL})\n\n"
            context.contentResolver.openOutputStream(uri)?.use { it.write((header + text()).toByteArray(Charsets.UTF_8)) } ?: return null
            name
        } catch (e: Exception) {
            AppLog.e("saving the log failed", e)
            null
        }
    }
}
