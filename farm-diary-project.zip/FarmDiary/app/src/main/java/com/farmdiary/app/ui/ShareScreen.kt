package com.farmdiary.app.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.ShareViewModel

@Composable
fun ShareScreen(share: ShareViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val busy by share.busy.collectAsState()
    val message by share.message.collectAsState()
    val shareUri by share.shareUri.collectAsState()
    val pending by share.pending.collectAsState()
    val pendingText by share.pendingText.collectAsState()
    val result by share.result.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            share.clearMessage()
        }
    }

    LaunchedEffect(shareUri) {
        val uri = shareUri ?: return@LaunchedEffect
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Share farm data").apply {
            clipData = android.content.ClipData.newRawUri("Farm data", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(chooser)
        } catch (e: Exception) {
            snackbar.showSnackbar("No app found to share the file.")
        }
        share.shareHandled()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) share.readFile(uri)
    }

    if (pending != null) {
        AlertDialog(
            onDismissRequest = { share.cancelImport() },
            title = { Text("Add this data?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(pendingText, fontSize = 17.sp)
                    Text(
                        "Entries are added or updated only when the file has the newer version. Nothing on this phone is removed.",
                        fontSize = 15.sp, color = TextLo
                    )
                }
            },
            confirmButton = { TextButton(onClick = { share.confirmImport() }) { Text("Add data", fontSize = 18.sp) } },
            dismissButton = { TextButton(onClick = { share.cancelImport() }) { Text("Cancel", fontSize = 18.sp) } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Share Data", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Where is my data?", "🔒") {
                Text(
                    "All your reports, stock and feed entries are saved inside this app on this phone. " +
                        "No other app can open them, and nothing goes to the internet.",
                    fontSize = 17.sp
                )
            }
            SectionCard("Send my data", "📤") {
                Text(
                    "Make a data file and send it by WhatsApp, Bluetooth or any app. " +
                        "The other phone opens it from Add data below.",
                    fontSize = 17.sp
                )
                GradientButton(
                    if (busy) "Please wait..." else "Share data file",
                    onClick = { share.prepareShare() },
                    modifier = Modifier,
                    enabled = !busy
                )
                GradientButton(
                    "Save a copy in Downloads",
                    onClick = { share.saveCopy() },
                    enabled = !busy,
                    brush = VioletBrush
                )
            }
            SectionCard("Add data from another phone", "📥") {
                Text(
                    "Choose the data file you received. You will see what it contains before anything is added.",
                    fontSize = 17.sp
                )
                GradientButton(
                    if (busy) "Please wait..." else "Choose data file",
                    onClick = { picker.launch(arrayOf("*/*")) },
                    enabled = !busy,
                    brush = MintBrush
                )
            }
            result?.let { lines ->
                SectionCard("Done", "✅") {
                    lines.forEach { Text(it, fontSize = 17.sp) }
                    TextButton(onClick = { share.clearResult() }) { Text("OK", fontSize = 18.sp) }
                }
            }
            SectionCard("Good to know", "💡") {
                Text("• This is not live sync. Share the file again whenever you want the other phone to catch up.", fontSize = 16.sp)
                Text("• If the same day is changed on both phones, the newer change is kept.", fontSize = 16.sp)
                Text("• The stock numbers from the newer file replace this phone's stock. Check In-Stock after adding.", fontSize = 16.sp)
                Text("• Login and reminders are not shared.", fontSize = 16.sp)
                Text("• The file has your farm money details. Send it only to people you trust.", fontSize = 16.sp)
            }
        }
    }
}
