package com.farmdiary.app.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.ImportStatus
import com.farmdiary.app.ShareViewModel

@Composable
fun ShareScreen(share: ShareViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val busy by share.busy.collectAsState()
    val message by share.message.collectAsState()
    val shareUri by share.shareUri.collectAsState()
    val status by share.status.collectAsState()
    val lastImport by share.lastImport.collectAsState()
    val lastExport by share.lastExport.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            share.clearMessage()
        }
    }

    LaunchedEffect(shareUri) {
        val uri = shareUri ?: return@LaunchedEffect
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Share farm data").apply {
            clipData = android.content.ClipData.newRawUri("Farm data", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(chooser)
        } catch (e: Exception) {
            snackbar.showSnackbar("No app found to share the file.")
        }
        share.shareHandled()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        share.readFile(uri)
    }

    Scaffold(
        topBar = { FarmTopBar("Share Data", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // The result of choosing a file is always shown here, with the reason if it did not work.
            when (val s = status) {
                ImportStatus.Idle -> {}
                is ImportStatus.Reading -> AccentCard("Reading the file...", "⏳", SunBrush, Sun) {
                    Text(s.name, fontSize = 17.sp)
                    Text("Please wait.", fontSize = 16.sp, color = TextLo)
                }
                is ImportStatus.Ready -> AccentCard("File is ready to add", "📄", MintBrush, Mint) {
                    Text(s.name + if (s.sizeText.isNotEmpty()) "  (${s.sizeText})" else "", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(s.summary, fontSize = 17.sp)
                    Text(
                        "Nothing is added until you press Add data. Nothing on this phone is removed.",
                        fontSize = 15.sp, color = TextLo
                    )
                    GradientButton("Add data now", onClick = { share.confirmImport() }, enabled = !busy, brush = MintBrush)
                    TextButton(onClick = { share.closeStatus() }) { Text("Cancel", fontSize = 18.sp) }
                }
                is ImportStatus.Failed -> AccentCard("This file could not be added", "⚠️", CoralBrush, Coral) {
                    if (s.name.isNotEmpty()) Text(s.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(s.reason, fontSize = 17.sp)
                    TextButton(onClick = { share.closeStatus() }) { Text("OK", fontSize = 18.sp) }
                }
                is ImportStatus.Done -> AccentCard("Data added", "✅", MintBrush, Mint) {
                    Text(s.name, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    s.lines.forEach { Text(it, fontSize = 17.sp) }
                    TextButton(onClick = { share.closeStatus() }) { Text("OK", fontSize = 18.sp) }
                }
            }

            AccentCard("Add data from another phone", "📥", MintBrush, Mint) {
                Text(
                    "Choose the data file you received (a .json file). You will see what it contains before anything is added.",
                    fontSize = 17.sp
                )
                GradientButton(
                    if (busy) "Please wait..." else "Choose data file",
                    onClick = { picker.launch(arrayOf("*/*")) },
                    enabled = !busy,
                    brush = MintBrush
                )
                Text(
                    if (lastImport.isEmpty()) "Last data added: nothing added yet" else "Last data added: $lastImport",
                    fontSize = 15.sp, color = TextLo
                )
            }

            AccentCard("Send my data", "📤", SunBrush, Sun) {
                Text(
                    "Make a data file and send it by WhatsApp, Bluetooth or any app. " +
                        "The other phone opens it from Add data above.",
                    fontSize = 17.sp
                )
                GradientButton(
                    if (busy) "Please wait..." else "Share data file",
                    onClick = { share.prepareShare() },
                    enabled = !busy
                )
                GradientButton(
                    "Save a copy in Downloads",
                    onClick = { share.saveCopy() },
                    enabled = !busy,
                    brush = VioletBrush
                )
                Text(
                    if (lastExport.isEmpty()) "Last data sent or saved: not yet" else "Last data sent or saved: $lastExport",
                    fontSize = 15.sp, color = TextLo
                )
            }

            AccentCard("Where is my data?", "🔒", VioletBrush, Violet) {
                Text(
                    "All your reports, stock and feed entries are saved inside this app on this phone. " +
                        "No other app can open them, and nothing goes to the internet.",
                    fontSize = 17.sp
                )
            }

            AccentCard("Good to know", "💡", CoralBrush, Coral) {
                Text("• This is not live sync. Share the file again whenever you want the other phone to catch up.", fontSize = 16.sp)
                Text("• If the same day is changed on both phones, the newer change is kept.", fontSize = 16.sp)
                Text("• The stock numbers from the newer file replace this phone's stock. Check In-Stock after adding.", fontSize = 16.sp)
                Text("• Login and reminders are not shared.", fontSize = 16.sp)
                Text("• The file has your farm money details. Send it only to people you trust.", fontSize = 16.sp)
            }
        }
    }
}
