package com.farmdiary.app.ui

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.R
import com.farmdiary.app.domain.Calc
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

val FarmRed = Color(0xFFC40000)
val FarmOrange = Color(0xFFF9B260)
val FarmText = Color(0xFF212121)

private val scheme = lightColorScheme(
    primary = FarmRed,
    onPrimary = Color.White,
    secondary = FarmOrange,
    onSecondary = FarmText,
    background = Color(0xFFF5F5F5),
    onBackground = FarmText,
    surface = Color.White,
    onSurface = FarmText,
    error = Color(0xFFB00020)
)

// Big, plain text so it is easy to read outdoors.
private val farmTypography = Typography(
    bodyLarge = TextStyle(fontSize = 20.sp),
    bodyMedium = TextStyle(fontSize = 20.sp),
    bodySmall = TextStyle(fontSize = 18.sp),
    labelLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold)
)

@Composable
fun FarmDiaryTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = farmTypography, content = content)
}

val displayDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

fun showDatePicker(context: Context, current: LocalDate, onPicked: (LocalDate) -> Unit) {
    DatePickerDialog(
        context,
        { _, y, m, d -> onPicked(LocalDate.of(y, m + 1, d)) },
        current.year,
        current.monthValue - 1,
        current.dayOfMonth
    ).show()
}

/** Farm logo picture (hen with eggs). */
@Composable
fun FarmLogo(height: Dp = 240.dp) {
    Image(
        painter = painterResource(R.drawable.farm_logo),
        contentDescription = "Poultry Farm logo: hen with eggs",
        contentScale = ContentScale.Fit,
        modifier = Modifier.height(height)
    )
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FarmRed)
            content()
        }
    }
}

/** Numeric input. Only digits (and one decimal point if allowed) can be typed. */
@Composable
fun NumField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    integer: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = { v ->
            val ok = if (integer) v.all { it.isDigit() } else v.all { it.isDigit() || it == '.' }
            if (ok) onChange(v)
        },
        label = { Text(label) },
        singleLine = true,
        isError = Calc.isInvalid(value),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (integer) KeyboardType.Number else KeyboardType.Decimal
        ),
        modifier = modifier
    )
}

/** Read-only calculated value, visually distinct from entry fields. */
@Composable
fun CalcRow(label: String, value: String, bold: Boolean = false, error: Boolean = false) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            fontSize = 18.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            value,
            fontSize = 18.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
        )
    }
}
