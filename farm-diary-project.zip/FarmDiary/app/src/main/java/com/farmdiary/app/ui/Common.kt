package com.farmdiary.app.ui

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.domain.Calc
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

val FarmGreen = Color(0xFF2E7D32)

private val scheme = lightColorScheme(
    primary = FarmGreen,
    onPrimary = Color.White,
    secondary = Color(0xFF8D6E63),
    background = Color(0xFFFAFAF5),
    surface = Color.White
)

@Composable
fun FarmDiaryTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

val displayDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

fun showDatePicker(context: Context, current: LocalDate, onPicked: (LocalDate) -> Unit) {
    DatePickerDialog(
        context,
        { _, y, m, d -> onPicked(LocalDate.of(y, m + 1, d)) },
        current.year,
        current.monthValue - 1,
        current.dayOfMonth
    ).show()
}

/** Simple circular logo: white hen + white egg on green. */
@Composable
fun FarmLogo(size: Dp = 180.dp) {
    Canvas(
        Modifier
            .size(size)
            .semantics { contentDescription = "Farm Diary logo: white hen and egg" }
    ) {
        val s = this.size.minDimension
        val white = Color.White
        drawCircle(FarmGreen, radius = s / 2)
        drawCircle(white, radius = s / 2 - s * 0.04f, style = Stroke(width = s * 0.015f))

        // tail
        val tail = Path().apply {
            moveTo(s * 0.26f, s * 0.50f)
            lineTo(s * 0.14f, s * 0.30f)
            lineTo(s * 0.36f, s * 0.44f)
            close()
        }
        drawPath(tail, white)
        // body
        drawOval(white, Offset(s * 0.22f, s * 0.40f), Size(s * 0.42f, s * 0.32f))
        // head
        drawCircle(white, s * 0.085f, Offset(s * 0.60f, s * 0.34f))
        // comb
        drawCircle(Color(0xFFD32F2F), s * 0.03f, Offset(s * 0.58f, s * 0.245f))
        drawCircle(Color(0xFFD32F2F), s * 0.03f, Offset(s * 0.635f, s * 0.255f))
        // beak
        val beak = Path().apply {
            moveTo(s * 0.67f, s * 0.32f)
            lineTo(s * 0.76f, s * 0.35f)
            lineTo(s * 0.67f, s * 0.38f)
            close()
        }
        drawPath(beak, Color(0xFFF9A825))
        // eye
        drawCircle(FarmGreen, s * 0.012f, Offset(s * 0.625f, s * 0.325f))
        // legs
        drawLine(Color(0xFFF9A825), Offset(s * 0.38f, s * 0.72f), Offset(s * 0.38f, s * 0.80f), strokeWidth = s * 0.015f)
        drawLine(Color(0xFFF9A825), Offset(s * 0.50f, s * 0.72f), Offset(s * 0.50f, s * 0.80f), strokeWidth = s * 0.015f)
        // egg
        drawOval(white, Offset(s * 0.68f, s * 0.58f), Size(s * 0.15f, s * 0.20f))
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = FarmGreen)
            content()
        }
    }
}

/** Numeric input. Only digits (and one decimal point if allowed) can be typed. */
@Composable
fun NumField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    integer: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = { v ->
            val ok = if (integer) v.all { it.isDigit() } else v.all { it.isDigit() || it == '.' }
            if (ok) onChange(v)
        },
        label = { Text(label) },
        singleLine = true,
        isError = Calc.isInvalid(value),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (integer) KeyboardType.Number else KeyboardType.Decimal
        ),
        modifier = modifier
    )
}

/** Read-only calculated value, visually distinct from entry fields. */
@Composable
fun CalcRow(label: String, value: String, bold: Boolean = false, error: Boolean = false) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            fontSize = 16.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            value,
            fontSize = 16.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
        )
    }
}
