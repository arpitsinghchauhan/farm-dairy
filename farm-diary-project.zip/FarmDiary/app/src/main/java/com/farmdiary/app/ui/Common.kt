package com.farmdiary.app.ui

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.R
import com.farmdiary.app.domain.Calc
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

// Midnight theme with warm, loud accents (taken from the hen logo).
val Ink = Color(0xFF15111F)
val Panel = Color(0xFF211B31)
val PanelHi = Color(0xFF2D2542)
val Sun = Color(0xFFFFB547)
val Coral = Color(0xFFFF5C8A)
val Mint = Color(0xFF3DDC97)
val Sky = Color(0xFF4DA3FF)
val Violet = Color(0xFF8B7BFF)
val TextHi = Color(0xFFF7F4FF)
val TextLo = Color(0xFFB9B0D0)
val LineSoft = Color(0xFF3A3254)

val SunBrush = Brush.linearGradient(listOf(Sun, Coral))
val MintBrush = Brush.linearGradient(listOf(Mint, Sky))
val VioletBrush = Brush.linearGradient(listOf(Violet, Sky))
val CoralBrush = Brush.linearGradient(listOf(Coral, Sun))
val EggBrush = Brush.linearGradient(listOf(Color(0xFFFFE08A), Sun))
val PinkBrush = Brush.linearGradient(listOf(Coral, Violet))

private val scheme = darkColorScheme(
    primary = Sun,
    onPrimary = Color(0xFF2A1700),
    secondary = Violet,
    onSecondary = Color.White,
    background = Ink,
    onBackground = TextHi,
    surface = Panel,
    onSurface = TextHi,
    surfaceVariant = PanelHi,
    onSurfaceVariant = TextLo,
    outline = Color(0xFF6B5F8C),
    error = Color(0xFFFF7A90),
    onError = Color(0xFF30000B)
)

private val farmShapes = Shapes(
    extraSmall = RoundedCornerShape(14.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

// Big, plain text so it is easy to read outdoors.
private val farmTypography = Typography(
    bodyLarge = TextStyle(fontSize = 20.sp),
    bodyMedium = TextStyle(fontSize = 20.sp),
    bodySmall = TextStyle(fontSize = 18.sp),
    labelLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
)

@Composable
fun FarmDiaryTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = farmTypography, shapes = farmShapes, content = content)
}

val displayDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

fun showDatePicker(context: Context, current: LocalDate, onPicked: (LocalDate) -> Unit) {
    DatePickerDialog(
        context,
        { _, y, m, d -> onPicked(LocalDate.of(y, m + 1, d)) },
        current.year,
        current.monthValue - 1,
        current.dayOfMonth
    ).show()
}

/** Farm logo picture (hen with eggs) on a light "sticker" so the logo colours stay true. */
@Composable
fun FarmLogo(height: Dp = 240.dp) {
    Box(
        Modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xFFF5F5F5))
            .padding(14.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.farm_logo),
            contentDescription = "Poultry Farm logo: hen with eggs",
            contentScale = ContentScale.Fit,
            modifier = Modifier.height(height)
        )
    }
}

@Composable
fun SectionCard(title: String, icon: String = "", content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (icon.isNotEmpty()) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(SunBrush),
                        contentAlignment = Alignment.Center
                    ) { Text(icon, fontSize = 22.sp) }
                }
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = TextHi)
            }
            content()
        }
    }
}

/** Big gradient call-to-action button. */
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    brush: Brush = SunBrush
) {
    Box(
        modifier
            .height(64.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (enabled) brush else Brush.linearGradient(listOf(PanelHi, PanelHi)))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (enabled) Color(0xFF2A1700) else TextLo
        )
    }
}

/** Colourful tile used on the Home screen. */
@Composable
fun BigTile(
    icon: String,
    title: String,
    subtitle: String,
    brush: Brush,
    dark: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fg = if (dark) Color(0xFF1B1030) else Color.White
    Column(
        modifier
            .clip(RoundedCornerShape(28.dp))
            .background(brush)
            .clickable(onClick = onClick)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(icon, fontSize = 38.sp)
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = fg)
        Text(subtitle, fontSize = 15.sp, color = fg.copy(alpha = 0.8f))
    }
}

/** Small stat chip (emoji + number + label). */
@Composable
fun StatChip(icon: String, value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Panel)
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(22.dp))
            .padding(horizontal = 12.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 26.sp)
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = TextHi)
        Text(label, fontSize = 14.sp, color = TextLo)
    }
}

/** Numeric input. Only digits (and one decimal point if allowed) can be typed. */
@Composable
fun NumField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    integer: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = { v ->
            val ok = if (integer) v.all { it.isDigit() } else v.all { it.isDigit() || it == '.' }
            if (ok) onChange(v)
        },
        label = { Text(label) },
        singleLine = true,
        isError = Calc.isInvalid(value),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (integer) KeyboardType.Number else KeyboardType.Decimal
        ),
        modifier = modifier
    )
}

/** Read-only calculated value, visually distinct from entry fields. */
@Composable
fun CalcRow(label: String, value: String, bold: Boolean = false, error: Boolean = false) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            fontSize = 18.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            value,
            fontSize = 18.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (error) MaterialTheme.colorScheme.error else if (bold) Sun else MaterialTheme.colorScheme.onSurface
        )
    }
}

/** Opens a freshly created PDF in the phone's PDF viewer (it is also in Downloads). */
@Composable
fun OpenPdfEffect(uri: android.net.Uri?, onDone: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.LaunchedEffect(uri) {
        uri?.let {
            try {
                context.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(it, "application/pdf")
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            } catch (e: android.content.ActivityNotFoundException) {
                // No PDF viewer installed; the file is still in Downloads.
            }
            onDone()
        }
    }
}
