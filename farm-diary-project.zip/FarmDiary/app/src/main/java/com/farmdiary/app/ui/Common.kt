package com.farmdiary.app.ui

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.R
import com.farmdiary.app.domain.Calc
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Dark (deep green) or light (white) look. The choice is kept on the phone and applies to every page. */
object Palette {
    var light by androidx.compose.runtime.mutableStateOf(true)

    fun load(context: Context) {
        light = try {
            context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("theme_light", true)
        } catch (e: Exception) {
            true
        }
    }

    fun setLight(context: Context, value: Boolean) {
        light = value
        try {
            context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("theme_light", value).apply()
        } catch (e: Exception) {
            // The look still changes for this session.
        }
    }
}

// Palette from the Layer Diary design: warm paper + deep forest green (light), midnight forest + mint (dark).
val Ink: Color get() = if (Palette.light) Color(0xFFF9F8F3) else Color(0xFF0C1E15)         // screen background
val Panel: Color get() = if (Palette.light) Color(0xFFFFFFFF) else Color(0xFF14291E)       // cards
val PanelHi: Color get() = if (Palette.light) Color(0xFFF0EFE9) else Color(0xFF1C3528)     // inputs, pills, containers
val Primary: Color get() = if (Palette.light) Color(0xFF1E4D38) else Color(0xFF4ADE80)     // deep forest / mint
val OnPrimary: Color get() = if (Palette.light) Color(0xFFFFFFFF) else Color(0xFF0C1E15)
val PrimaryTonal: Color get() = if (Palette.light) Color(0xFFE2ECE6) else Color(0xFF1D4431)
val Sun: Color get() = if (Palette.light) Color(0xFFA9700F) else Color(0xFFF5B041)         // egg amber (text-safe)
val Coral: Color get() = if (Palette.light) Color(0xFFC85A32) else Color(0xFFE07A5F)       // terracotta
val Mint: Color get() = if (Palette.light) Color(0xFF1E4D38) else Color(0xFF4ADE80)        // green accent
val Sky: Color get() = if (Palette.light) Color(0xFF2F7F78) else Color(0xFF5CC7BB)         // teal
val Violet: Color get() = if (Palette.light) Color(0xFFB9672F) else Color(0xFFE8955A)      // warm orange
val TextHi: Color get() = if (Palette.light) Color(0xFF191C1A) else Color(0xFFE2ECE6)
val TextLo: Color get() = if (Palette.light) Color(0xFF58625B) else Color(0xFF9CA8A0)
val LineSoft: Color get() = if (Palette.light) Color(0xFFE3E1D6) else Color(0xFF24402F)
/** Text on the soft tinted tiles, card headers and buttons. */
val OnBrush: Color get() = TextHi

private fun soft(light1: Long, light2: Long, dark1: Long, dark2: Long) =
    if (Palette.light) Brush.linearGradient(listOf(Color(light1), Color(light2)))
    else Brush.linearGradient(listOf(Color(dark1), Color(dark2)))

val SunBrush: Brush get() = soft(0xFFF8E6BF, 0xFFF2D49B, 0xFF3A3015, 0xFF4A3A18)
val MintBrush: Brush get() = soft(0xFFE2ECE6, 0xFFCFE0D6, 0xFF1D4431, 0xFF24543D)
val VioletBrush: Brush get() = soft(0xFFD9ECE9, 0xFFC5E0DC, 0xFF1B4540, 0xFF225650)
val CoralBrush: Brush get() = soft(0xFFF5D9CE, 0xFFEFC4B4, 0xFF4A2A22, 0xFF5A332A)
val EggBrush: Brush get() = soft(0xFFFAEBC4, 0xFFF4DB9E, 0xFF3F3516, 0xFF4F4219)
val LimeBrush: Brush get() = soft(0xFFE4EDCB, 0xFFD3E2AD, 0xFF2F4220, 0xFF3A5128)
val PinkBrush: Brush get() = soft(0xFFF3D9DC, 0xFFEBC6CB, 0xFF4A2A33, 0xFF5A3440)
val SkyBrush: Brush get() = soft(0xFFD6E9F0, 0xFFC0DDE8, 0xFF1B3A45, 0xFF22495A)

/** Headings: Outfit. Body, labels and numbers: Plus Jakarta Sans. */
val TitleFont = FontFamily(
    Font(R.font.outfit_medium, FontWeight.Medium),
    Font(R.font.outfit_semibold, FontWeight.SemiBold),
    Font(R.font.outfit_bold, FontWeight.Bold),
    Font(R.font.outfit_extrabold, FontWeight.ExtraBold)
)
val BodyFont = FontFamily(
    Font(R.font.jakarta_regular, FontWeight.Normal),
    Font(R.font.jakarta_medium, FontWeight.Medium),
    Font(R.font.jakarta_semibold, FontWeight.SemiBold),
    Font(R.font.jakarta_bold, FontWeight.Bold),
    Font(R.font.jakarta_extrabold, FontWeight.ExtraBold)
)

private fun colorScheme() = if (Palette.light) {
    androidx.compose.material3.lightColorScheme(
        primary = Primary,
        onPrimary = OnPrimary,
        primaryContainer = PrimaryTonal,
        onPrimaryContainer = Primary,
        secondary = Sun,
        onSecondary = Color.White,
        background = Ink,
        onBackground = TextHi,
        surface = Panel,
        onSurface = TextHi,
        surfaceVariant = PanelHi,
        onSurfaceVariant = TextLo,
        outline = Color(0xFF9AA39C),
        error = Color(0xFFB3261E),
        onError = Color.White
    )
} else {
    darkColorScheme(
        primary = Primary,
        onPrimary = OnPrimary,
        primaryContainer = PrimaryTonal,
        onPrimaryContainer = Primary,
        secondary = Sun,
        onSecondary = Color(0xFF0C1E15),
        background = Ink,
        onBackground = TextHi,
        surface = Panel,
        onSurface = TextHi,
        surfaceVariant = PanelHi,
        onSurfaceVariant = TextLo,
        outline = Color(0xFF3E5A49),
        error = Color(0xFFFF8A80),
        onError = Color(0xFF30000B)
    )
}

private val farmShapes = Shapes(
    extraSmall = RoundedCornerShape(14.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

// Big, plain text so it is easy to read outdoors.
private val farmTypography = Typography(
    bodyLarge = TextStyle(fontSize = 20.sp, fontFamily = BodyFont),
    bodyMedium = TextStyle(fontSize = 20.sp, fontFamily = BodyFont),
    bodySmall = TextStyle(fontSize = 18.sp, fontFamily = BodyFont),
    labelLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = BodyFont),
    labelMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium, fontFamily = BodyFont),
    labelSmall = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium, fontFamily = BodyFont),
    titleLarge = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont),
    titleMedium = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont),
    titleSmall = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont)
)

@Composable
fun FarmDiaryTheme(content: @Composable () -> Unit) {
    val light = Palette.light
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.SideEffect {
        // Status bar and navigation bar follow the chosen look.
        val window = (view.context as? android.app.Activity)?.window
        if (window != null) {
            window.statusBarColor = (if (light) Color(0xFFF9F8F3) else Color(0xFF0C1E15)).toArgb()
            window.navigationBarColor = (if (light) Color(0xFFF9F8F3) else Color(0xFF0C1E15)).toArgb()
            androidx.core.view.WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = light
                isAppearanceLightNavigationBars = light
            }
        }
    }
    MaterialTheme(colorScheme = colorScheme(), typography = farmTypography, shapes = farmShapes) {
        // One solid screen background for every page (login and home included), so text is never drawn on the window colour.
        androidx.compose.material3.Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
            content = content
        )
    }
}

val displayDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

fun showDatePicker(context: Context, current: LocalDate, onPicked: (LocalDate) -> Unit) {
    DatePickerDialog(
        context,
        { _, y, m, d -> onPicked(LocalDate.of(y, m + 1, d)) },
        current.year,
        current.monthValue - 1,
        current.dayOfMonth
    ).show()
}

/** The round Layer Diary logo (hen on a green field with an egg). */
@Composable
fun FarmLogo(height: Dp = 240.dp) {
    // A clean white ring around the round logo, so its edge is sharp on any background.
    Box(
        Modifier
            .size(height)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Color.White)
            .padding(5.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.logo_mark),
            contentDescription = "Layer Diary logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().clip(androidx.compose.foundation.shape.CircleShape)
        )
    }
}

/** The full logo with the name and tagline, on a white card so the logo colours stay true. */
@Composable
fun FarmLogoFull(height: Dp = 200.dp) {
    Box(
        Modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White)
            .padding(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.logo_full),
            contentDescription = "Layer Diary. Every Day. Every Egg. Every Record.",
            contentScale = ContentScale.Fit,
            modifier = Modifier.height(height)
        )
    }
}

@Composable
fun SectionCard(
    title: String,
    icon: String = "",
    accent: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = if (accent != null) accent.copy(alpha = 0.10f).compositeOver(Panel) else Panel),
        border = if (accent != null) BorderStroke(1.5.dp, accent.copy(alpha = 0.7f)) else BorderStroke(1.dp, LineSoft)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (icon.isNotEmpty()) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(SunBrush),
                        contentAlignment = Alignment.Center
                    ) { Text(icon, fontSize = 22.sp) }
                }
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont, color = accent ?: TextHi)
            }
            content()
        }
    }
}

/** Big gradient call-to-action button. */
/** A section card with a colored header strip, for screens that should look more colorful. */
@Composable
fun AccentCard(
    title: String,
    icon: String,
    brush: Brush,
    accent: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f).compositeOver(Panel)),
        border = BorderStroke(1.5.dp, accent.copy(alpha = 0.7f))
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(brush).padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(icon, fontSize = 24.sp)
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont, color = OnBrush)
            }
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                content()
            }
        }
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    /** null = the main solid green button; a brush = a softer tinted button for secondary actions. */
    brush: Brush? = null
) {
    val fill: Brush = when {
        !enabled -> Brush.linearGradient(listOf(PanelHi, PanelHi))
        brush == null -> Brush.linearGradient(listOf(Primary, Primary))
        else -> brush
    }
    val fg = when {
        !enabled -> TextLo
        brush == null -> OnPrimary
        else -> OnBrush
    }
    Box(
        modifier
            .height(60.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(fill)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = TitleFont,
            color = fg
        )
    }
}

/** Colourful tile used on the Home screen. */
@Composable
fun BigTile(
    icon: String,
    title: String,
    subtitle: String,
    brush: Brush,
    dark: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .clip(RoundedCornerShape(26.dp))
            .background(Panel)
            .border(1.dp, LineSoft, RoundedCornerShape(26.dp))
            .clickable(onClick = onClick)
            .height(200.dp)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.size(64.dp).clip(RoundedCornerShape(20.dp)).background(brush),
            contentAlignment = Alignment.Center
        ) { Text(icon, fontSize = 34.sp) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont, color = TextHi, maxLines = 2, lineHeight = 24.sp)
        Text(subtitle, fontSize = 15.sp, color = TextLo, maxLines = 1)
    }
}

/** Small stat chip (emoji + number + label). */
@Composable
fun StatChip(icon: String, value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(26.dp))
            .background(PanelHi)
            .padding(horizontal = 8.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(icon, fontSize = 30.sp)
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, fontFamily = TitleFont, color = Primary, maxLines = 1)
        Text(label, fontSize = 15.sp, color = TextLo, maxLines = 1)
    }
}

/** Numeric input. Only digits (and one decimal point if allowed) can be typed. */
@Composable
fun NumField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    integer: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = { v ->
            val ok = if (integer) v.all { it.isDigit() } else v.all { it.isDigit() || it == '.' }
            if (ok) onChange(v)
        },
        label = { Text(label) },
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextHi,
            unfocusedTextColor = TextHi,
            cursorColor = Primary,
            focusedBorderColor = Primary,
            unfocusedBorderColor = TextLo,
            focusedLabelColor = Primary,
            unfocusedLabelColor = TextLo
        ),
        singleLine = true,
        isError = Calc.isInvalid(value),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (integer) KeyboardType.Number else KeyboardType.Decimal
        ),
        modifier = modifier
    )
}

/** Read-only calculated value, visually distinct from entry fields. */
@Composable
fun CalcRow(label: String, value: String, bold: Boolean = false, error: Boolean = false) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            fontSize = 18.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            value,
            fontSize = 18.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (error) MaterialTheme.colorScheme.error else if (bold) Sun else MaterialTheme.colorScheme.onSurface
        )
    }
}

/** Opens a freshly created PDF in the phone's PDF viewer (it is also in Downloads). */
@Composable
fun OpenPdfEffect(uri: android.net.Uri?, onDone: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.LaunchedEffect(uri) {
        uri?.let {
            try {
                context.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(it, "application/pdf")
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            } catch (e: android.content.ActivityNotFoundException) {
                // No PDF viewer installed; the file is still in Downloads.
            }
            onDone()
        }
    }
}

/** Tap to change the date. Used on the Daily Report, Egg Sell, Feed Purchase and In-Stock screens. */
@Composable
fun DatePill(date: LocalDate, onPicked: (LocalDate) -> Unit) {
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Panel)
            .border(1.dp, Sun, RoundedCornerShape(20.dp))
            .clickable { showDatePicker(context, date, onPicked) }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("📅 Date (tap to change)", fontSize = 16.sp, color = TextLo)
        Text(date.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
    }
}

