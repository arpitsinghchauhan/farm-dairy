package com.farmdiary.app.domain

import com.farmdiary.app.data.BirdRecordEntity
import java.time.LocalDate
import java.time.temporal.ChronoUnit

const val MAX_BIRD_FARMS = 5
const val MAX_MEDICINES = 5

/** One farm's record for one date (the Farm Records screen). */
data class BirdFarmForm(
    val key: Long,
    val name: String = "",
    /** Age of the flock in days, e.g. 245. */
    val day: String = "",
    /** Feed given per bird, in grams. */
    val feedPerBird: String = "",
    val feedBags: String = "",
    val stoneBags: String = "",
    /** Production of this farm in trays. */
    val production: String = "",
    val mortality: String = "",
    /** Broken eggs (pieces). */
    val breakage: String = "",
    val waterTanks: String = "",
    val medicines: List<String> = emptyList(),
    val notes: String = ""
) {
    private val numbers get() = listOf(day, feedPerBird, feedBags, stoneBags, production, mortality, breakage, waterTanks)

    /** True when the user wrote something other than the farm name. */
    val hasData: Boolean
        get() = numbers.any { it.isNotBlank() } || medicines.any { it.isNotBlank() } || notes.isNotBlank()

    fun hasInvalidNumbers(): Boolean = numbers.any { Calc.isInvalid(it) }
}

object BirdRecords {
    const val MEDICINE_SEPARATOR = "\n"

    fun validate(farms: List<BirdFarmForm>): List<String> {
        val errors = mutableListOf<String>()
        if (farms.any { it.hasInvalidNumbers() }) {
            errors += "Please enter valid numbers only (not negative)."
        }
        return errors
    }

    /** Only farms where something was written are saved. Farms get a default name if it was left empty. */
    fun toEntities(date: LocalDate, farms: List<BirdFarmForm>, now: Long): List<BirdRecordEntity> =
        farms.filter { it.hasData }.take(MAX_BIRD_FARMS).mapIndexed { i, f ->
            BirdRecordEntity(
                date = date.toString(),
                position = i,
                name = f.name.trim().ifEmpty { "Farm ${i + 1}" },
                dayNo = Calc.parse(f.day).toInt(),
                feedPerBirdGrams = Calc.parse(f.feedPerBird),
                feedBags = Calc.parse(f.feedBags),
                stoneBags = Calc.parse(f.stoneBags),
                production = Calc.parse(f.production),
                mortality = Calc.parse(f.mortality).toInt(),
                breakage = Calc.parse(f.breakage).toInt(),
                waterTanks = Calc.parse(f.waterTanks),
                medicines = f.medicines.map { it.trim() }.filter { it.isNotEmpty() }.take(MAX_MEDICINES)
                    .joinToString(MEDICINE_SEPARATOR),
                notes = f.notes.trim(),
                updatedAt = now
            )
        }

    private fun text(d: Double): String = if (d == 0.0) "" else Calc.fmt(d)
    private fun text(i: Int): String = if (i == 0) "" else i.toString()

    /** Saved records back into the form. */
    fun toForms(rows: List<BirdRecordEntity>, nextKey: () -> Long): List<BirdFarmForm> =
        rows.sortedBy { it.position }.map {
            BirdFarmForm(
                key = nextKey(),
                name = it.name,
                day = text(it.dayNo),
                feedPerBird = text(it.feedPerBirdGrams),
                feedBags = text(it.feedBags),
                stoneBags = text(it.stoneBags),
                production = text(it.production),
                mortality = text(it.mortality),
                breakage = text(it.breakage),
                waterTanks = text(it.waterTanks),
                medicines = if (it.medicines.isEmpty()) emptyList() else it.medicines.split(MEDICINE_SEPARATOR),
                notes = it.notes
            )
        }

    /**
     * A new date starts with the farm names of the last saved day and the day number counted forward,
     * so the user does not have to type them again. Everything else starts empty.
     */
    fun prefill(previous: List<BirdRecordEntity>, previousDate: LocalDate, date: LocalDate, nextKey: () -> Long): List<BirdFarmForm> {
        if (previous.isEmpty()) return emptyList()
        val gap = ChronoUnit.DAYS.between(previousDate, date).coerceAtLeast(0)
        return previous.sortedBy { it.position }.map {
            BirdFarmForm(
                key = nextKey(),
                name = it.name,
                day = if (it.dayNo > 0) (it.dayNo + gap).toString() else ""
            )
        }
    }

    /** One line per saved date for the history list, newest date first. */
    fun summarize(all: List<BirdRecordEntity>): List<BirdDaySummary> =
        all.groupBy { it.date }
            .map { (date, rows) -> summarizeDay(date, rows) }
            .sortedByDescending { it.date }

    fun summarizeDay(date: String, rows: List<BirdRecordEntity>) = BirdDaySummary(
        date = date,
        farmNames = rows.sortedBy { it.position }.map { it.name },
        feedBags = rows.sumOf { it.feedBags },
        stoneBags = rows.sumOf { it.stoneBags },
        production = rows.sumOf { it.production },
        mortality = rows.sumOf { it.mortality },
        breakage = rows.sumOf { it.breakage },
        waterTanks = rows.sumOf { it.waterTanks }
    )

    /** Splits long text into lines of at most [width] characters (for the PDF). Words are not cut unless very long. */
    fun wrap(text: String, width: Int): List<String> {
        val out = mutableListOf<String>()
        text.split("\n").forEach { para ->
            var line = ""
            para.trim().split(" ").filter { it.isNotEmpty() }.forEach { word0 ->
                var word = word0
                while (word.length > width) {
                    if (line.isNotEmpty()) { out += line; line = "" }
                    out += word.take(width)
                    word = word.drop(width)
                }
                line = when {
                    line.isEmpty() -> word
                    line.length + 1 + word.length <= width -> "$line $word"
                    else -> { out += line; word }
                }
            }
            out += line
        }
        return out.ifEmpty { listOf("") }
    }
}

/** Totals of one saved date, for the history list and the PDF. */
data class BirdDaySummary(
    val date: String,
    val farmNames: List<String>,
    val feedBags: Double,
    val stoneBags: Double,
    val production: Double,
    val mortality: Int,
    val breakage: Int,
    val waterTanks: Double
)
