package com.farmdiary.app.domain

import com.farmdiary.app.data.BirdRecordEntity
import java.time.LocalDate
import java.time.temporal.ChronoUnit

const val MAX_BIRD_FARMS = 5
const val MAX_MEDICINES = 5

/** One farm's record for one date (the Farm Records screen). */
data class BirdFarmForm(
    val key: Long,
    val name: String = "",
    /** Age of the flock in days, e.g. 245. */
    val day: String = "",
    /** Live birds in this farm at the start of the day. */
    val birds: String = "",
    /** Feed given per bird, in grams. */
    val feedPerBird: String = "",
    val feedBags: String = "",
    val stoneBags: String = "",
    /** Production of this farm in trays. */
    val production: String = "",
    val mortality: String = "",
    /** Broken eggs (pieces). */
    val breakage: String = "",
    val waterTanks: String = "",
    val medicines: List<String> = emptyList(),
    val notes: String = ""
) {
    private val numbers get() = listOf(day, birds, feedPerBird, feedBags, stoneBags, production, mortality, breakage, waterTanks)

    /** True when the user wrote something other than the farm name. */
    val hasData: Boolean
        get() = numbers.any { it.isNotBlank() } || medicines.any { it.isNotBlank() } || notes.isNotBlank()

    fun hasInvalidNumbers(): Boolean = numbers.any { Calc.isInvalid(it) }

    /** Week of the birds' age (days 1-7 = week 1). 0 when no day is written. */
    val week: Int get() = BirdRecords.weekOf(Calc.parse(day).toInt())

    /** Birds left at the end of the day: birds at start minus the mortality. */
    val birdsLeft: Int get() = Calc.parse(birds).toInt() - Calc.parse(mortality).toInt()

    /** Production percentage of the day (eggs laid / birds x 100). 0 when the bird count is not written. */
    val productionPercent: Double get() = BirdRecords.productionPercent(Calc.parse(production), Calc.parse(birds).toInt())
}

object BirdRecords {
    const val MEDICINE_SEPARATOR = "\n"

    /** Production percentage: eggs laid (trays x 30) as a percentage of the birds. 0 when there are no birds written. */
    fun productionPercent(trays: Double, birds: Int): Double =
        if (birds > 0) trays * Calc.EGGS_PER_TRAY * 100.0 / birds else 0.0

    /** Week of age for a day number: days 1-7 are week 1, days 8-14 are week 2, and so on. */
    fun weekOf(day: Int): Int = if (day <= 0) 0 else (day + 6) / 7

    fun validate(farms: List<BirdFarmForm>): List<String> {
        val errors = mutableListOf<String>()
        if (farms.any { it.hasInvalidNumbers() }) {
            errors += "Please enter valid numbers only (not negative)."
        } else {
            farms.forEachIndexed { i, f ->
                if (f.birds.isNotBlank() && f.birdsLeft < 0) {
                    errors += "${f.name.ifBlank { "Farm ${i + 1}" }}: mortality (${f.mortality}) is more than the birds in the farm (${f.birds})."
                }
            }
        }
        return errors
    }

    /** Only farms where something was written are saved. Farms get a default name if it was left empty. */
    fun toEntities(date: LocalDate, farms: List<BirdFarmForm>, now: Long): List<BirdRecordEntity> =
        farms.filter { it.hasData }.take(MAX_BIRD_FARMS).mapIndexed { i, f ->
            BirdRecordEntity(
                date = date.toString(),
                position = i,
                name = f.name.trim().ifEmpty { "Farm ${i + 1}" },
                dayNo = Calc.parse(f.day).toInt(),
                birdsStart = Calc.parse(f.birds).toInt(),
                feedPerBirdGrams = Calc.parse(f.feedPerBird),
                feedBags = Calc.parse(f.feedBags),
                stoneBags = Calc.parse(f.stoneBags),
                production = Calc.parse(f.production),
                mortality = Calc.parse(f.mortality).toInt(),
                breakage = Calc.parse(f.breakage).toInt(),
                waterTanks = Calc.parse(f.waterTanks),
                medicines = f.medicines.map { it.trim() }.filter { it.isNotEmpty() }.take(MAX_MEDICINES)
                    .joinToString(MEDICINE_SEPARATOR),
                notes = f.notes.trim(),
                updatedAt = now
            )
        }

    private fun text(d: Double): String = if (d == 0.0) "" else Calc.fmt(d)
    private fun text(i: Int): String = if (i == 0) "" else i.toString()

    /** Saved records back into the form. */
    fun toForms(rows: List<BirdRecordEntity>, nextKey: () -> Long): List<BirdFarmForm> =
        rows.sortedBy { it.position }.map {
            BirdFarmForm(
                key = nextKey(),
                name = it.name,
                day = text(it.dayNo),
                birds = text(it.birdsStart),
                feedPerBird = text(it.feedPerBirdGrams),
                feedBags = text(it.feedBags),
                stoneBags = text(it.stoneBags),
                production = text(it.production),
                mortality = text(it.mortality),
                breakage = text(it.breakage),
                waterTanks = text(it.waterTanks),
                medicines = if (it.medicines.isEmpty()) emptyList() else it.medicines.split(MEDICINE_SEPARATOR),
                notes = it.notes
            )
        }

    /**
     * A new date starts with the farm names of the last saved day and the day number counted forward,
     * so the user does not have to type them again. Everything else starts empty.
     */
    fun prefill(previous: List<BirdRecordEntity>, previousDate: LocalDate, date: LocalDate, nextKey: () -> Long): List<BirdFarmForm> {
        if (previous.isEmpty()) return emptyList()
        val gap = ChronoUnit.DAYS.between(previousDate, date).coerceAtLeast(0)
        return previous.sortedBy { it.position }.map {
            BirdFarmForm(
                key = nextKey(),
                name = it.name,
                day = if (it.dayNo > 0) (it.dayNo + gap).toString() else "",
                // Yesterday's birds minus yesterday's mortality are today's birds.
                birds = if (it.birdsStart > 0) (it.birdsStart - it.mortality).coerceAtLeast(0).toString() else ""
            )
        }
    }

    /** One line per saved date for the history list, newest date first. */
    fun summarize(all: List<BirdRecordEntity>): List<BirdDaySummary> =
        all.groupBy { it.date }
            .map { (date, rows) -> summarizeDay(date, rows) }
            .sortedByDescending { it.date }

    fun summarizeDay(date: String, rows: List<BirdRecordEntity>) = BirdDaySummary(
        date = date,
        farmNames = rows.sortedBy { it.position }.map { it.name },
        feedBags = rows.sumOf { it.feedBags },
        stoneBags = rows.sumOf { it.stoneBags },
        production = rows.sumOf { it.production },
        mortality = rows.sumOf { it.mortality },
        breakage = rows.sumOf { it.breakage },
        waterTanks = rows.sumOf { it.waterTanks },
        birdsLeft = rows.sumOf { if (it.birdsStart > 0) it.birdsStart - it.mortality else 0 },
        productionPercent = productionPercent(
            rows.filter { it.birdsStart > 0 }.sumOf { it.production },
            rows.sumOf { it.birdsStart }
        )
    )

    /** Splits long text into lines of at most [width] characters (for the PDF). Words are not cut unless very long. */
    fun wrap(text: String, width: Int): List<String> {
        val out = mutableListOf<String>()
        text.split("\n").forEach { para ->
            var line = ""
            para.trim().split(" ").filter { it.isNotEmpty() }.forEach { word0 ->
                var word = word0
                while (word.length > width) {
                    if (line.isNotEmpty()) { out += line; line = "" }
                    out += word.take(width)
                    word = word.drop(width)
                }
                line = when {
                    line.isEmpty() -> word
                    line.length + 1 + word.length <= width -> "$line $word"
                    else -> { out += line; word }
                }
            }
            out += line
        }
        return out.ifEmpty { listOf("") }
    }
}

/** Totals of one saved date, for the history list and the PDF. */
data class BirdDaySummary(
    val date: String,
    val farmNames: List<String>,
    val feedBags: Double,
    val stoneBags: Double,
    val production: Double,
    val mortality: Int,
    val breakage: Int,
    val waterTanks: Double,
    /** Birds left at the end of that day, added up over the farms that have a bird count. */
    val birdsLeft: Int = 0,
    /** Production percentage over the farms that have a bird count (0 if none). */
    val productionPercent: Double = 0.0
)

/** One farm's month: birds at the start, mortality day by day, birds at the end. */
data class BirdMonthFarm(
    val name: String,
    val birdsAtStart: Int,
    val birdsAtEnd: Int,
    val mortality: Int,
    val production: Double,
    val breakage: Int,
    val feedBags: Double,
    val stoneBags: Double,
    val waterTanks: Double,
    val days: Int,
    /** Eggs laid on the days that have a bird count (trays x 30) and the birds of those days added up. */
    val countedTrays: Double = 0.0,
    val birdDays: Long = 0L
) {
    /** Production percentage of the month: all eggs laid / all bird-days x 100. 0 if no bird count was written. */
    val productionPercent: Double get() =
        if (birdDays > 0) countedTrays * Calc.EGGS_PER_TRAY * 100.0 / birdDays else 0.0

    /** Mortality as a percentage of the birds at the start; 0 if the bird count was not written. */
    val mortalityPercent: Double get() = if (birdsAtStart > 0) mortality * 100.0 / birdsAtStart else 0.0
}

object BirdMonthly {
    /** One entry per farm name that has records in [month], plus nothing for empty months. */
    fun build(all: List<BirdRecordEntity>, month: java.time.YearMonth): List<BirdMonthFarm> {
        val prefix = month.toString() // 2026-10
        return all.filter { it.date.startsWith(prefix) }
            .groupBy { it.name.trim().lowercase() }
            .map { (_, rows) ->
                val ordered = rows.sortedWith(compareBy({ it.date }, { it.position }))
                val first = ordered.first()
                val last = ordered.last()
                BirdMonthFarm(
                    name = last.name,
                    birdsAtStart = first.birdsStart,
                    birdsAtEnd = if (last.birdsStart > 0) (last.birdsStart - last.mortality).coerceAtLeast(0) else 0,
                    mortality = ordered.sumOf { it.mortality },
                    production = ordered.sumOf { it.production },
                    breakage = ordered.sumOf { it.breakage },
                    feedBags = ordered.sumOf { it.feedBags },
                    stoneBags = ordered.sumOf { it.stoneBags },
                    waterTanks = ordered.sumOf { it.waterTanks },
                    days = ordered.map { it.date }.distinct().size,
                    countedTrays = ordered.filter { it.birdsStart > 0 }.sumOf { it.production },
                    birdDays = ordered.sumOf { it.birdsStart.toLong() }
                )
            }
            .sortedBy { it.name.lowercase() }
    }
}
