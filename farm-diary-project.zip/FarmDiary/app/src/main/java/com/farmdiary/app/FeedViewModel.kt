package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FeedCalc
import com.farmdiary.app.domain.FeedLedger
import com.farmdiary.app.domain.FeedType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.UUID

class FeedViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val ledger: StateFlow<FeedLedger> = repo.observeFeedTxns()
        .map { FeedCalc.build(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FeedCalc.build(emptyList()))

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()

    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()

    private var saving = false

    fun clearMessage() { _message.value = null }
    fun clearErrors() { _errors.value = emptyList() }
    fun clearOpenPdf() { _openPdf.value = null }

    /** Confirm Transaction on the Buy page: saves the purchase. Feed stock is managed separately in In-Stock. */
    fun confirmBuy(date: LocalDate, bags: String, rate: String, discount: String, note: String, onSaved: () -> Unit) {
        val problems = FeedCalc.validateBuy(bags, rate, discount)
        if (problems.isNotEmpty()) {
            _errors.value = problems
            return
        }
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val b = Calc.parse(bags)
                val r = Calc.parse(rate)
                val d = Calc.parse(discount)
                val txn = FeedTxnEntity(
                    id = UUID.randomUUID().toString(),
                    date = date.toString(),
                    type = FeedType.BUY,
                    bags = b, rate = r, discount = d,
                    amount = FeedCalc.buyAmount(b, r, d),
                    note = note.trim(),
                    deleted = false,
                    createdAt = now, updatedAt = now
                )
                repo.addFeedEntry(txn)
                _errors.value = emptyList()
                _message.value = "Purchase saved: ${Calc.fmt(b)} bags, ${Calc.money(txn.amount)}."
                onSaved()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "confirmBuy failed", e)
                _message.value = "Unable to save the purchase. Please try again."
            } finally {
                saving = false
            }
        }
    }

    /** Confirm on the Paid Online / Paid Cash / Old Balance pages. */
    fun confirmPayment(type: String, date: LocalDate, amount: String, note: String, onSaved: () -> Unit) {
        val problems = if (type == FeedType.OPENING) FeedCalc.validateOpening(amount) else FeedCalc.validatePayment(amount)
        if (problems.isNotEmpty()) {
            _errors.value = problems
            return
        }
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val txn = FeedTxnEntity(
                    id = UUID.randomUUID().toString(),
                    date = date.toString(),
                    type = type,
                    bags = 0.0, rate = 0.0, discount = 0.0,
                    amount = Calc.parse(amount),
                    note = note.trim(),
                    deleted = false,
                    createdAt = now, updatedAt = now
                )
                repo.addFeedEntry(txn)
                _errors.value = emptyList()
                _message.value = when (type) {
                    FeedType.OPENING -> "Old balance saved: ${Calc.money(txn.amount)}."
                    FeedType.ONLINE -> "Payment saved: ${Calc.money(txn.amount)} paid online."
                    else -> "Payment saved: ${Calc.money(txn.amount)} paid cash."
                }
                onSaved()
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "confirmPayment failed", e)
                _message.value = "Unable to save the payment. Please try again."
            } finally {
                saving = false
            }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            try {
                when (repo.deleteFeedTxn(id, System.currentTimeMillis())) {
                    FarmRepository.DeleteResult.DELETED -> _message.value = "Entry deleted."
                    FarmRepository.DeleteResult.NOT_FOUND -> _message.value = "This entry was already deleted."
                }
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "delete failed", e)
                _message.value = "Unable to delete. Please try again."
            }
        }
    }

    fun downloadPdf() {
        val farmName = prefs.getString("farm_name", "") ?: ""
        val l = ledger.value
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.createFeedReport(getApplication(), l, farmName, LocalDate.now())
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}
