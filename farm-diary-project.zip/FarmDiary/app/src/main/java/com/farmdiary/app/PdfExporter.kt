package com.farmdiary.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.EggSaleForm
import com.farmdiary.app.domain.ReportForm
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Builds the Daily Report PDF on the device. No network or cloud involved. */
object PdfExporter {
    private val dateFmt = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

    private fun rs(d: Double) = "Rs. " + Calc.fmt(d)

    fun create(context: Context, f: ReportForm, stock: FarmStockEntity, farmName: String): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            if (farmName.isBlank()) {
                w.text("FARM DIARY - Daily Report", style = Style.TITLE)
            } else {
                w.text(farmName, style = Style.TITLE)
                w.text("Daily Report", style = Style.BOLD)
            }
            w.text("Date: ${f.date.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            w.text("EXPENDITURE", "Amount", Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(
                    "$name: ${l.feedBags.ifBlank { "0" }} bags x ${l.feedRate.ifBlank { "0" }}",
                    rs(l.feedAmount)
                )
            }
            w.text("Tray: ${f.trayQty.ifBlank { "0" }} x ${f.trayRate.ifBlank { "0" }}  (${Calc.fmt(Calc.bundles(f.trayUsed))} bundles)", rs(f.trayAmount))
            w.text("Labour", rs(Calc.parse(f.labour)))
            w.text("Light", rs(Calc.parse(f.light)))
            f.extras.forEachIndexed { i, e ->
                w.text(e.name.ifBlank { "Item ${i + 1}" }, rs(Calc.parse(e.amount)))
            }
            w.text("Stone: ${f.stoneQty.ifBlank { "0" }} x ${f.stoneRate.ifBlank { "0" }}", rs(f.stoneAmount))
            w.rule()
            w.text("Total Expenditure", rs(f.totalExpenditure), Style.BOLD)
            w.gap()

            w.text("INCOME (Egg Sale)", "Amount", Style.BOLD)
            w.rule()
            if (f.totalIncome <= 0.0) {
                w.text("NIL - no egg sold on this day", "Rs. 0", Style.BOLD)
            } else {
                f.sales.forEachIndexed { i, s ->
                    val name = s.name.ifBlank { "Sale ${i + 1}" }
                    w.text("$name: ${s.trays.ifBlank { "0" }} trays x ${s.rate.ifBlank { "0" }}", rs(s.amount))
                }
                w.rule()
                w.text("Total Sale (${Calc.fmt(f.totalTraysSold)} trays)", rs(f.totalIncome), Style.BOLD)
                w.text("Cash received", rs(Calc.parse(f.cashReceived)))
                w.text("Online received", rs(Calc.parse(f.onlineReceived)))
                w.text("Balance to receive", rs(f.balance), Style.BOLD)
            }
            w.gap()

            w.text("PRODUCTION (trays)", style = Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(name, "${Calc.fmt(Calc.parse(l.trays))} trays")
            }
            w.rule()
            w.text(
                "Total Production",
                "${Calc.fmt(f.totalTrays)} trays = ${Calc.fmt(f.totalEggs)} eggs",
                Style.BOLD
            )
            w.gap()

            w.text("MORTALITY (birds died)", style = Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(name, "${Calc.fmt(Calc.parse(l.mortality))} birds")
            }
            w.rule()
            w.text("Total Mortality", "${Calc.fmt(f.totalMortality)} birds", Style.BOLD)
            w.gap()

            w.text("WATER USED", style = Style.BOLD)
            w.rule()
            w.text(
                "Tanks of ${Calc.LITERS_PER_TANK} litres",
                "${Calc.fmt(Calc.parse(f.waterTanks))} tanks = ${Calc.fmt(f.waterLiters)} L"
            )
            w.gap()

            w.text("STOCK", style = Style.BOLD)
            w.rule()
            w.text("Feed - Opening Stock", "${Calc.fmt(f.confirmedOpening)} bags")
            w.text("Feed - Total Used", "${Calc.fmt(f.confirmedFeedUsed)} bags")
            w.text("Feed - Closing Stock", "${Calc.fmt(f.confirmedClosing)} bags", Style.BOLD)
            w.text(
                "Trays - Opening Stock",
                "${Calc.fmt(Calc.bundles(f.confirmedTrayOpening))} bundles (${Calc.fmt(f.confirmedTrayOpening)} trays)"
            )
            w.text(
                "Trays - Used",
                "${Calc.fmt(Calc.bundles(f.confirmedTrayUsed))} bundles (${Calc.fmt(f.confirmedTrayUsed)} trays)"
            )
            w.text(
                "Trays - Closing Stock",
                "${Calc.fmt(Calc.bundles(f.confirmedTrayClosing))} bundles (${Calc.fmt(f.confirmedTrayClosing)} trays)",
                Style.BOLD
            )
            w.text("Blank Trays (current stock)", "${Calc.fmt(Calc.bundles(stock.blankTrays.toDouble()))} bundles")
            w.text(
                "Egg Stock (current)",
                "${stock.eggTrays} trays = ${stock.eggTrays * Calc.EGGS_PER_TRAY} eggs"
            )
            w.finish()

            saveToDownloads(context, doc, "Farm_Diary_${f.date}.pdf")
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    /** PDF of the Egg Sell screen for one day. */
    fun createEggSale(context: Context, f: EggSaleForm, farmName: String): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            w.text(farmName.ifBlank { "FARM DIARY" }, style = Style.TITLE)
            w.text("Egg Sale Report", style = Style.BOLD)
            w.text("Date: ${f.date.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            w.text("EGG SALE", "Amount", Style.BOLD)
            w.rule()
            if (f.totalIncome <= 0.0) {
                w.text("NIL - no egg sold on this day", "Rs. 0", Style.BOLD)
            } else {
                f.sales.forEachIndexed { i, s ->
                    val name = s.name.ifBlank { "Sale ${i + 1}" }
                    w.text("$name: ${s.trays.ifBlank { "0" }} trays x ${s.rate.ifBlank { "0" }}", rs(s.amount))
                }
                w.rule()
                w.text("Total Sale (${Calc.fmt(f.totalTraysSold)} trays)", rs(f.totalIncome), Style.BOLD)
                w.gap()
                w.text("MONEY RECEIVED", style = Style.BOLD)
                w.rule()
                w.text("Cash received", rs(Calc.parse(f.cashReceived)))
                w.text("Online received", rs(Calc.parse(f.onlineReceived)))
                w.rule()
                w.text("Balance to receive", rs(f.balance), Style.BOLD)
            }
            w.finish()
            saveToDownloads(context, doc, "Farm_Diary_EggSale_${f.date}.pdf")
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "Egg sale PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    private fun saveToDownloads(context: Context, doc: PdfDocument, fileName: String): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: return null
        return uri
    }

    private enum class Style { NORMAL, BOLD, TITLE }

    private class PageWriter(private val doc: PdfDocument) {
        private var pageNo = 0
        private lateinit var page: PdfDocument.Page
        private var y = 0f
        private val left = 40f
        private val right = 555f

        private val normal = Paint().apply {
            textSize = 12f
            color = Color.BLACK
            isAntiAlias = true
        }
        private val bold = Paint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
        private val title = Paint(bold).apply { textSize = 20f }
        private val rightNormal = Paint(normal).apply { textAlign = Paint.Align.RIGHT }
        private val rightBold = Paint(bold).apply { textAlign = Paint.Align.RIGHT }

        init { newPage() }

        private fun newPage() {
            if (pageNo > 0) doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            y = 50f
        }

        fun text(leftText: String, rightText: String? = null, style: Style = Style.NORMAL) {
            if (y > 790f) newPage()
            val lp = when (style) {
                Style.NORMAL -> normal
                Style.BOLD -> bold
                Style.TITLE -> title
            }
            page.canvas.drawText(leftText, left, y, lp)
            if (rightText != null) {
                val rp = if (style == Style.NORMAL) rightNormal else rightBold
                page.canvas.drawText(rightText, right, y, rp)
            }
            y += if (style == Style.TITLE) 30f else 20f
        }

        fun rule() {
            if (y > 790f) newPage()
            page.canvas.drawLine(left, y - 12f, right, y - 12f, normal)
            y += 4f
        }

        fun gap() { y += 12f }

        fun finish() { doc.finishPage(page) }
    }
}
