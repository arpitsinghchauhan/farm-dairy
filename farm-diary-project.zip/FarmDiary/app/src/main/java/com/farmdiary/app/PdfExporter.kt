package com.farmdiary.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.ReportForm
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Builds the Daily Report PDF on the device. No network or cloud involved. */
object PdfExporter {
    private val dateFmt = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

    private fun rs(d: Double) = "Rs. " + Calc.fmt(d)

    fun create(context: Context, f: ReportForm, stock: FarmStockEntity): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            w.text("FARM DIARY - Daily Report", style = Style.TITLE)
            w.text("Date: ${f.date.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            w.text("EXPENDITURE", "Amount", Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(
                    "$name: ${l.feedBags.ifBlank { "0" }} bags x ${l.feedRate.ifBlank { "0" }}",
                    rs(l.feedAmount)
                )
            }
            w.text("Tray: ${f.trayQty.ifBlank { "0" }} x ${f.trayRate.ifBlank { "0" }}", rs(f.trayAmount))
            w.text("Labour", rs(Calc.parse(f.labour)))
            w.text("Light", rs(Calc.parse(f.light)))
            w.text("Stone: ${f.stoneQty.ifBlank { "0" }} x ${f.stoneRate.ifBlank { "0" }}", rs(f.stoneAmount))
            w.rule()
            w.text("Total Expenditure", rs(f.totalExpenditure), Style.BOLD)
            w.gap()

            w.text("INCOME", "Amount", Style.BOLD)
            w.rule()
            w.text("Egg Sell", rs(f.totalIncome))
            w.rule()
            w.text("Total Income", rs(f.totalIncome), Style.BOLD)
            w.gap()

            w.text("PRODUCTION (eggs)", style = Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(name, Calc.fmt(Calc.parse(l.eggs)))
            }
            w.rule()
            w.text(
                "Total Eggs",
                "${Calc.fmt(f.totalEggs)} (${Calc.fmt(Calc.eggsToTrays(f.totalEggs))} trays)",
                Style.BOLD
            )
            w.gap()

            w.text("STOCK", style = Style.BOLD)
            w.rule()
            w.text("Feed - Opening Stock", "${Calc.fmt(f.confirmedOpening)} bags")
            w.text("Feed - Total Used", "${Calc.fmt(f.confirmedFeedUsed)} bags")
            w.text("Feed - Closing Stock", "${Calc.fmt(f.confirmedClosing)} bags", Style.BOLD)
            w.text("Blank / New Trays (current)", "${stock.blankTrays} trays")
            w.text(
                "Egg Stock (current)",
                "${stock.eggTrays} trays = ${stock.eggTrays * Calc.EGGS_PER_TRAY} eggs"
            )
            w.finish()

            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "Farm_Diary_${f.date}.pdf")
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            resolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: return null
            uri
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    private enum class Style { NORMAL, BOLD, TITLE }

    private class PageWriter(private val doc: PdfDocument) {
        private var pageNo = 0
        private lateinit var page: PdfDocument.Page
        private var y = 0f
        private val left = 40f
        private val right = 555f

        private val normal = Paint().apply {
            textSize = 12f
            color = Color.BLACK
            isAntiAlias = true
        }
        private val bold = Paint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
        private val title = Paint(bold).apply { textSize = 20f }
        private val rightNormal = Paint(normal).apply { textAlign = Paint.Align.RIGHT }
        private val rightBold = Paint(bold).apply { textAlign = Paint.Align.RIGHT }

        init { newPage() }

        private fun newPage() {
            if (pageNo > 0) doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            y = 50f
        }

        fun text(leftText: String, rightText: String? = null, style: Style = Style.NORMAL) {
            if (y > 790f) newPage()
            val lp = when (style) {
                Style.NORMAL -> normal
                Style.BOLD -> bold
                Style.TITLE -> title
            }
            page.canvas.drawText(leftText, left, y, lp)
            if (rightText != null) {
                val rp = if (style == Style.NORMAL) rightNormal else rightBold
                page.canvas.drawText(rightText, right, y, rp)
            }
            y += if (style == Style.TITLE) 30f else 20f
        }

        fun rule() {
            if (y > 790f) newPage()
            page.canvas.drawLine(left, y - 12f, right, y - 12f, normal)
            y += 4f
        }

        fun gap() { y += 12f }

        fun finish() { doc.finishPage(page) }
    }
}
