package com.farmdiary.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.domain.BirdRecords
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.EggSaleForm
import com.farmdiary.app.domain.FeedLedger
import com.farmdiary.app.domain.FeedType
import com.farmdiary.app.domain.FileNames
import com.farmdiary.app.domain.ReportForm
import com.farmdiary.app.domain.SaleLineForm
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Builds the PDFs on the device. No network or cloud involved.
 * File names are the farm name the user set + the date, e.g. Green_Valley_Farm_17-Oct-2026.pdf
 */
object PdfExporter {
    private val dateFmt = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

    private fun rs(d: Double) = "Rs. " + Calc.fmt(d)

    private fun saleLineText(s: SaleLineForm, index: Int): String {
        val name = s.name.ifBlank { "Sale ${index + 1}" }
        return if (s.isRevised) {
            "$name: ${s.trays.ifBlank { "0" }} trays x ${Calc.EGGS_PER_TRAY} eggs x ${s.revisedRate} (revised, was ${s.rate.ifBlank { "0" }})"
        } else {
            "$name: ${s.trays.ifBlank { "0" }} trays x ${Calc.EGGS_PER_TRAY} eggs x ${s.rate.ifBlank { "0" }}"
        }
    }

    /** Sale lines and the money summary, shared by the Daily Report PDF and the Egg Sale PDF. */
    private fun writeSale(
        w: PageWriter,
        sales: List<SaleLineForm>,
        totalSale: Double,
        totalTrays: Double,
        previous: Double,
        advance: Double,
        cash: Double,
        online: Double,
        balance: Double
    ) {
        if (totalSale <= 0.0) {
            w.text("NIL - no egg sold on this day", "Rs. 0", Style.BOLD)
        } else {
            sales.forEachIndexed { i, s -> w.text(saleLineText(s, i), rs(s.amount)) }
            w.rule()
            w.text("Total Sale (${Calc.fmt(totalTrays)} trays)", rs(totalSale), Style.BOLD)
        }
        if (totalSale > 0.0 || previous > 0.0 || advance > 0.0 || cash > 0.0 || online > 0.0) {
            w.gap()
            w.text("ACCOUNT", style = Style.BOLD)
            w.rule()
            if (previous > 0.0) w.text("Previous balance", rs(previous))
            w.text("Today's sale", rs(totalSale))
            if (advance > 0.0) w.text("Advance paid", "- " + rs(advance))
            w.text("Cash received", "- " + rs(cash))
            w.text("Online received", "- " + rs(online))
            w.rule()
            if (balance < -1e-9) {
                w.text("Advance in hand (credit)", rs(-balance), Style.BOLD)
            } else {
                w.text("Balance to receive", rs(balance), Style.BOLD)
            }
        }
    }

    fun create(context: Context, f: ReportForm, stock: FarmStockEntity, farmName: String): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            if (farmName.isBlank()) {
                w.text("FARM DIARY - Daily Report", style = Style.TITLE)
            } else {
                w.text(farmName, style = Style.TITLE)
                w.text("Daily Report", style = Style.BOLD)
            }
            w.text("Date: ${f.date.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            w.text("EXPENDITURE", "Amount", Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(
                    "$name: ${l.feedBags.ifBlank { "0" }} bags x ${l.feedRate.ifBlank { "0" }}",
                    rs(l.feedAmount)
                )
            }
            w.text(
                "Tray: ${f.trayQty.ifBlank { "0" }} x ${f.trayRate.ifBlank { "0" }}  " +
                    "(${Calc.fmt(Calc.bundles(f.trayUsed))} bundles)",
                rs(f.trayAmount)
            )
            w.text("Labour", rs(Calc.parse(f.labour)))
            w.text("Light", rs(Calc.parse(f.light)))
            f.extras.forEachIndexed { i, e ->
                w.text(e.name.ifBlank { "Item ${i + 1}" }, rs(Calc.parse(e.amount)))
            }
            w.text("Stone: ${f.stoneQty.ifBlank { "0" }} x ${f.stoneRate.ifBlank { "0" }}", rs(f.stoneAmount))
            w.rule()
            w.text("Total Expenditure", rs(f.totalExpenditure), Style.BOLD)
            w.gap()

            w.text("INCOME (Egg Sale)", "Amount", Style.BOLD)
            w.rule()
            writeSale(
                w, f.sales, f.totalIncome, f.totalTraysSold,
                f.previous, f.advance, Calc.parse(f.cashReceived), Calc.parse(f.onlineReceived), f.balance
            )
            w.gap()

            w.text("PRODUCTION (trays)", style = Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(name, "${Calc.fmt(Calc.parse(l.trays))} trays")
            }
            w.rule()
            w.text("Total Production", "${Calc.fmt(f.totalTrays)} trays", Style.BOLD)
            w.gap()

            w.text("MORTALITY (birds died)", style = Style.BOLD)
            w.rule()
            f.lines.forEachIndexed { i, l ->
                val name = l.name.ifBlank { "S.No. ${i + 1}" }
                w.text(name, "${Calc.fmt(Calc.parse(l.mortality))} birds")
            }
            w.rule()
            w.text("Total Mortality", "${Calc.fmt(f.totalMortality)} birds", Style.BOLD)
            w.gap()

            w.text("STOCK LEFT", style = Style.BOLD)
            w.rule()
            w.text("Feed", "${Calc.fmt(f.confirmedClosing)} bags")
            w.text("Tray bundles", "${Calc.fmt(Calc.bundles(f.confirmedTrayClosing))} bundles")
            if (f.confirmedEggTrays >= 0) w.text("Egg trays", "${f.confirmedEggTrays} trays")
            w.finish()

            saveToDownloads(context, doc, FileNames.pdf(farmName, f.date))
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    /** PDF of the Egg Sell screen for one day. */
    fun createEggSale(context: Context, f: EggSaleForm, farmName: String): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            w.text(farmName.ifBlank { "FARM DIARY" }, style = Style.TITLE)
            w.text("Egg Sale Report", style = Style.BOLD)
            w.text("Date: ${f.date.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            w.text("EGG SALE", "Amount", Style.BOLD)
            w.rule()
            writeSale(
                w, f.sales, f.totalIncome, f.totalTraysSold,
                f.previous, f.advance, Calc.parse(f.cashReceived), Calc.parse(f.onlineReceived), f.balance
            )
            w.finish()
            saveToDownloads(context, doc, FileNames.pdf(farmName, f.date, "EggSale"))
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "Egg sale PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    /** Date-wise feed purchase report: purchase, online paid, cash paid and the balance owed. */
    fun createFeedReport(context: Context, ledger: FeedLedger, farmName: String, asOf: LocalDate): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            w.text(farmName.ifBlank { "FARM DIARY" }, style = Style.TITLE)
            w.text("Feed Purchase Report", style = Style.BOLD)
            w.text("Till: ${asOf.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            w.text("SUMMARY", style = Style.BOLD)
            w.rule()
            if (ledger.totalOpening > 0) w.text("Old balance (before using the app)", rs(ledger.totalOpening))
            w.text("Total feed bought", "${Calc.fmt(ledger.totalBags)} bags")
            w.text("Total purchase amount", rs(ledger.totalBought))
            w.text("Paid online", rs(ledger.totalOnline))
            w.text("Paid cash", rs(ledger.totalCash))
            w.rule()
            if (ledger.outstanding < -1e-9) {
                w.text("Advance paid to supplier", rs(-ledger.outstanding), Style.BOLD)
            } else {
                w.text("Outstanding balance", rs(ledger.outstanding), Style.BOLD)
            }
            w.gap()

            w.text("DATE-WISE (amounts in Rs.)", style = Style.BOLD)
            w.startTable(listOf("Date", "Old bal.", "Purchase", "Online", "Cash", "Balance"))
            if (ledger.rows.isEmpty()) {
                w.text("No feed purchase entries yet.")
            }
            ledger.rows.forEach { r ->
                val d = LocalDate.parse(r.date).format(DateTimeFormatter.ofPattern("dd-MMM-yy", Locale.ENGLISH))
                w.row(
                    listOf(
                        d,
                        if (r.opening > 0) Calc.group(r.opening) else "-",
                        if (r.bought > 0) Calc.group(r.bought) else "-",
                        if (r.online > 0) Calc.group(r.online) else "-",
                        if (r.cash > 0) Calc.group(r.cash) else "-",
                        Calc.group(r.balance)
                    )
                )
            }
            w.row(
                listOf(
                    "Total",
                    Calc.group(ledger.totalOpening),
                    Calc.group(ledger.totalBought),
                    Calc.group(ledger.totalOnline),
                    Calc.group(ledger.totalCash),
                    Calc.group(ledger.outstanding)
                ),
                bold = true
            )
            w.endTable()

            // Bills: one line per purchase so the rate and discount can be checked later.
            val buys = ledger.rows.flatMap { it.entries }.filter { it.type == FeedType.BUY }
            if (buys.isNotEmpty()) {
                w.gap()
                w.text("PURCHASE DETAILS", style = Style.BOLD)
                w.rule()
                buys.forEach { b ->
                    val d = LocalDate.parse(b.date).format(DateTimeFormatter.ofPattern("dd-MMM-yy", Locale.ENGLISH))
                    val discount = if (b.discount > 0) " - ${Calc.fmt(b.discount)} discount" else ""
                    w.text(
                        "$d: ${Calc.fmt(b.bags)} bags x ${Calc.fmt(b.rate)}$discount",
                        rs(b.amount)
                    )
                }
            }
            w.finish()
            saveToDownloads(context, doc, FileNames.pdf(farmName, asOf, "FeedReport"))
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "Feed report PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    /** Farm Records of one date: every farm with all its fields, then the totals. */
    fun createBirdDay(context: Context, date: LocalDate, rows: List<BirdRecordEntity>, farmName: String): Uri? {
        val doc = PdfDocument()
        return try {
            val w = PageWriter(doc)
            w.text(farmName.ifBlank { "FARM DIARY" }, style = Style.TITLE)
            w.text("Farm Records", style = Style.BOLD)
            w.text("Date: ${date.format(dateFmt)}", style = Style.BOLD)
            w.gap()

            if (rows.isEmpty()) {
                w.text("No farm records for this date.")
            }
            rows.sortedBy { it.position }.forEach { r ->
                w.text(r.name.uppercase(Locale.ENGLISH), style = Style.BOLD)
                w.rule()
                w.text("Day (age of birds)", "${r.dayNo}")
                if (r.dayNo > 0) w.text("Week of age", "Week ${BirdRecords.weekOf(r.dayNo)}")
                if (r.birdsStart > 0) w.text("Birds in farm (start of day)", "${r.birdsStart}")
                w.text("Feed per bird", "${Calc.fmt(r.feedPerBirdGrams)} g")
                w.text("Feed bags used", "${Calc.fmt(r.feedBags)} bags")
                w.text("Stone bags used", "${Calc.fmt(r.stoneBags)} bags")
                w.text("Production", "${Calc.fmt(r.production)} trays")
                w.text("Mortality", "${r.mortality} birds")
                if (r.birdsStart > 0) w.text("Birds left", "${(r.birdsStart - r.mortality).coerceAtLeast(0)}", Style.BOLD)
                w.text("Breakage", "${r.breakage} eggs")
                w.text("Water tanks used", "${Calc.fmt(r.waterTanks)} tanks")
                val meds = if (r.medicines.isEmpty()) emptyList() else r.medicines.split(BirdRecords.MEDICINE_SEPARATOR)
                if (meds.isEmpty()) {
                    w.text("Medicines", "None")
                } else {
                    w.text("Medicines", style = Style.BOLD)
                    meds.forEachIndexed { i, m -> BirdRecords.wrap("${i + 1}. $m", 80).forEach { line -> w.text("   $line") } }
                }
                if (r.notes.isNotBlank()) {
                    w.text("Notes", style = Style.BOLD)
                    BirdRecords.wrap(r.notes, 80).forEach { line -> w.text("   $line") }
                }
                w.gap()
            }

            if (rows.size > 1) {
                val t = BirdRecords.summarizeDay(date.toString(), rows)
                w.text("TOTAL OF ALL FARMS", style = Style.BOLD)
                w.rule()
                w.text("Feed bags used", "${Calc.fmt(t.feedBags)} bags")
                w.text("Stone bags used", "${Calc.fmt(t.stoneBags)} bags")
                w.text("Production", "${Calc.fmt(t.production)} trays")
                w.text("Mortality", "${t.mortality} birds")
                w.text("Breakage", "${t.breakage} eggs")
                w.text("Water tanks used", "${Calc.fmt(t.waterTanks)} tanks")
            }
            w.finish()
            saveToDownloads(context, doc, FileNames.pdf(farmName, date, "FarmRecords"))
        } catch (e: Exception) {
            android.util.Log.e("FarmDiary", "Farm records PDF export failed", e)
            null
        } finally {
            doc.close()
        }
    }

    private fun saveToDownloads(context: Context, doc: PdfDocument, fileName: String): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: return null
        return uri
    }

    private enum class Style { NORMAL, BOLD, TITLE }

    private class PageWriter(private val doc: PdfDocument) {
        private var pageNo = 0
        private lateinit var page: PdfDocument.Page
        private var y = 0f
        private val left = 40f
        private val right = 555f

        // Table columns: first column is left aligned at [left], the others are right aligned at these x positions.
        private val columnRight = floatArrayOf(0f, 190f, 285f, 375f, 465f, 555f)
        private var tableHeader: List<String>? = null

        private val normal = Paint().apply {
            textSize = 12f
            color = Color.BLACK
            isAntiAlias = true
        }
        private val bold = Paint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
        private val title = Paint(bold).apply { textSize = 20f }
        private val rightNormal = Paint(normal).apply { textAlign = Paint.Align.RIGHT }
        private val rightBold = Paint(bold).apply { textAlign = Paint.Align.RIGHT }

        init { newPage() }

        private fun newPage() {
            if (pageNo > 0) doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            y = 50f
            // Long tables repeat their header on every page.
            tableHeader?.let { drawRow(it, true); y += 4f; drawLine() }
        }

        private fun drawLine() {
            page.canvas.drawLine(left, y - 12f, right, y - 12f, normal)
        }

        fun text(leftText: String, rightText: String? = null, style: Style = Style.NORMAL) {
            if (y > 790f) newPage()
            val lp = when (style) {
                Style.NORMAL -> normal
                Style.BOLD -> bold
                Style.TITLE -> title
            }
            page.canvas.drawText(leftText, left, y, lp)
            if (rightText != null) {
                val rp = if (style == Style.NORMAL) rightNormal else rightBold
                page.canvas.drawText(rightText, right, y, rp)
            }
            y += if (style == Style.TITLE) 30f else 20f
        }

        fun rule() {
            if (y > 790f) newPage()
            drawLine()
            y += 4f
        }

        fun gap() { y += 12f }

        private fun drawRow(cells: List<String>, isBold: Boolean) {
            cells.forEachIndexed { i, c ->
                if (i == 0) {
                    page.canvas.drawText(c, left, y, if (isBold) bold else normal)
                } else {
                    page.canvas.drawText(c, columnRight[i.coerceAtMost(columnRight.lastIndex)], y, if (isBold) rightBold else rightNormal)
                }
            }
            y += 20f
        }

        fun startTable(header: List<String>) {
            if (y > 770f) newPage()
            tableHeader = header
            drawRow(header, true)
            y += 4f
            drawLine()
        }

        fun row(cells: List<String>, bold: Boolean = false) {
            if (y > 790f) newPage()
            if (bold) {
                drawLine()
                y += 4f
            }
            drawRow(cells, bold)
        }

        fun endTable() { tableHeader = null }

        fun finish() { doc.finishPage(page) }
    }
}
