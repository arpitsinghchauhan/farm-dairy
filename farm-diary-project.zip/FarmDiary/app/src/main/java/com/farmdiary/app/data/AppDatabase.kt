package com.farmdiary.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Database(
    entities = [DailyReportEntity::class, FarmLineEntity::class, FarmStockEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): FarmDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "farm_diary.db"
            ).build().also { instance = it }
        }
    }
}

class FarmRepository(private val db: AppDatabase) {
    private val dao = db.dao()

    fun observeReports(): Flow<List<DailyReportEntity>> = dao.observeReports()

    fun observeStock(): Flow<FarmStockEntity> = dao.observeStock().map { it ?: FarmStockEntity() }

    suspend fun getStock(): FarmStockEntity = dao.getStock() ?: FarmStockEntity()

    suspend fun getReport(date: String): DailyReportEntity? = dao.getReport(date)

    suspend fun getLines(date: String): List<FarmLineEntity> = dao.getLines(date)

    suspend fun saveStock(stock: FarmStockEntity) = dao.upsertStock(stock)

    /** Saves report + lines (and optionally the updated stock) atomically. */
    suspend fun saveReport(
        report: DailyReportEntity,
        lines: List<FarmLineEntity>,
        newStock: FarmStockEntity?
    ) {
        db.withTransaction {
            dao.upsertReport(report)
            dao.deleteLines(report.date)
            dao.insertLines(lines)
            if (newStock != null) dao.upsertStock(newStock)
        }
    }
}
