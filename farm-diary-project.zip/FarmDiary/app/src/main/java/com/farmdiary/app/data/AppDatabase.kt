package com.farmdiary.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.room.withTransaction
import androidx.sqlite.db.SupportSQLiteDatabase
import com.farmdiary.app.sync.Counts
import com.farmdiary.app.sync.MergeAction
import com.farmdiary.app.sync.MergeResult
import com.farmdiary.app.sync.SyncData
import com.farmdiary.app.sync.SyncMerge
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** v1 -> v2: adds user-defined extra expenditure items. Existing data is kept. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `extra_item` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`reportDate` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`amount` REAL NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_extra_item_reportDate` ON `extra_item` (`reportDate`)")
    }
}

/** v2 -> v3: adds the farm login (account) table. Existing data is kept. */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `account` (" +
                "`id` INTEGER PRIMARY KEY NOT NULL, " +
                "`phone` TEXT NOT NULL, " +
                "`credentialHash` TEXT NOT NULL, " +
                "`createdAt` INTEGER NOT NULL)"
        )
    }
}

/** v3 -> v4: production is now entered in trays, so old egg counts are converted (30 eggs = 1 tray). */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("UPDATE farm_line SET eggs = eggs / 30.0")
    }
}

/** v4 -> v5: egg sale lines + cash/online received. Old "Egg Sell" amounts become one sale line, marked as received in cash. */
val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN cashReceived REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN onlineReceived REAL NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `sale_line` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`reportDate` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`trays` REAL NOT NULL, " +
                "`rate` REAL NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sale_line_reportDate` ON `sale_line` (`reportDate`)")
        db.execSQL(
            "INSERT INTO sale_line (reportDate, position, name, trays, rate) " +
                "SELECT date, 0, 'Egg Sell', 1, eggSell FROM daily_report WHERE eggSell > 0"
        )
        db.execSQL("UPDATE daily_report SET cashReceived = eggSell WHERE eggSell > 0")
    }
}

/**
 * v5 -> v6: water tanks, tray stock used, mortality per farm, a separate egg-sale header table
 * (cash / online per day) and the scheduler. Existing data is kept; old cash / online amounts are copied.
 */
val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN waterTanks REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN confirmedTrayUsed REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN openingTrays REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN closingTrays REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE farm_line ADD COLUMN mortality INTEGER NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `egg_sale` (" +
                "`date` TEXT NOT NULL, " +
                "`cashReceived` REAL NOT NULL, " +
                "`onlineReceived` REAL NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`date`))"
        )
        db.execSQL(
            "INSERT INTO egg_sale (date, cashReceived, onlineReceived, updatedAt) " +
                "SELECT date, cashReceived, onlineReceived, updatedAt FROM daily_report " +
                "WHERE cashReceived > 0 OR onlineReceived > 0 OR date IN (SELECT reportDate FROM sale_line)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `schedule_item` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`title` TEXT NOT NULL, " +
                "`details` TEXT NOT NULL, " +
                "`hour` INTEGER NOT NULL, " +
                "`minute` INTEGER NOT NULL, " +
                "`reminderOn` INTEGER NOT NULL)"
        )
    }
}

/** v6 -> v7: egg sale gets previous balance, advance paid and revised rate. Existing sales are kept. */
val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE egg_sale ADD COLUMN previousBalance REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE egg_sale ADD COLUMN advancePaid REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE egg_sale ADD COLUMN closingBalance REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sale_line ADD COLUMN revisedRate REAL NOT NULL DEFAULT 0")
        // Old sales had no previous balance or advance, so their closing balance is what was left to receive.
        db.execSQL(
            "UPDATE egg_sale SET closingBalance = " +
                "(SELECT COALESCE(SUM(trays * rate), 0) FROM sale_line WHERE sale_line.reportDate = egg_sale.date) " +
                "- cashReceived - onlineReceived"
        )
    }
}

/** v7 -> v8: feed purchase ledger (purchases and payments to the supplier). */
/**
 * v8 -> v9: egg price is now entered per EGG (a tray = 30 eggs), and a confirmed report remembers the egg stock of its day.
 * Old prices were per tray, so they are divided by 30 and every old sale keeps exactly the same amount.
 */
val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("UPDATE sale_line SET rate = rate / 30.0, revisedRate = revisedRate / 30.0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN closingEggTrays INTEGER NOT NULL DEFAULT -1")
    }
}

/** v9 -> v10: Farm Records (per farm, per date). */
val MIGRATION_9_10 = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `bird_record` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`date` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`dayNo` INTEGER NOT NULL, " +
                "`feedPerBirdGrams` REAL NOT NULL, " +
                "`feedBags` REAL NOT NULL, " +
                "`stoneBags` REAL NOT NULL, " +
                "`production` REAL NOT NULL, " +
                "`mortality` INTEGER NOT NULL, " +
                "`breakage` INTEGER NOT NULL, " +
                "`waterTanks` REAL NOT NULL, " +
                "`medicines` TEXT NOT NULL, " +
                "`notes` TEXT NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_bird_record_date` ON `bird_record` (`date`)")
    }
}

val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `feed_txn` (" +
                "`id` TEXT NOT NULL, " +
                "`date` TEXT NOT NULL, " +
                "`type` TEXT NOT NULL, " +
                "`bags` REAL NOT NULL, " +
                "`rate` REAL NOT NULL, " +
                "`discount` REAL NOT NULL, " +
                "`amount` REAL NOT NULL, " +
                "`note` TEXT NOT NULL, " +
                "`deleted` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`id`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_feed_txn_date` ON `feed_txn` (`date`)")
    }
}

@Database(
    entities = [
        DailyReportEntity::class,
        FarmLineEntity::class,
        FarmStockEntity::class,
        ExtraItemEntity::class,
        AccountEntity::class,
        SaleLineEntity::class,
        EggSaleEntity::class,
        ScheduleItemEntity::class,
        FeedTxnEntity::class,
        BirdRecordEntity::class
    ],
    version = 10,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): FarmDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "farm_diary.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10).build().also { instance = it }
        }
    }
}

data class MonthData(
    val reports: List<DailyReportEntity>,
    val lines: List<FarmLineEntity>,
    val extras: List<ExtraItemEntity>,
    val sales: List<SaleLineEntity>,
    val eggSales: List<EggSaleEntity>
)

class FarmRepository(private val db: AppDatabase) {
    private val dao = db.dao()

    fun observeReports(): Flow<List<DailyReportEntity>> = dao.observeReports()

    fun observeStock(): Flow<FarmStockEntity> = dao.observeStock().map { it ?: FarmStockEntity() }

    suspend fun getStock(): FarmStockEntity = dao.getStock() ?: FarmStockEntity()

    suspend fun getReport(date: String): DailyReportEntity? = dao.getReport(date)

    suspend fun getLines(date: String): List<FarmLineEntity> = dao.getLines(date)

    suspend fun getExtras(date: String): List<ExtraItemEntity> = dao.getExtras(date)

    suspend fun getSales(date: String): List<SaleLineEntity> = dao.getSales(date)

    suspend fun getEggSale(date: String): EggSaleEntity? = dao.getEggSale(date)

    suspend fun getLatestEggSaleBefore(date: String): EggSaleEntity? = dao.getLatestEggSaleBefore(date)

    /** Saves the egg sale of one day (lines + cash/online) atomically. */
    suspend fun saveEggSale(sale: EggSaleEntity, lines: List<SaleLineEntity>) {
        db.withTransaction {
            dao.upsertEggSale(sale)
            dao.deleteSales(sale.date)
            dao.insertSales(lines)
        }
    }

    fun observeSchedule(): Flow<List<ScheduleItemEntity>> = dao.observeSchedule()

    // ---- sharing data with another phone ----

    /** A copy of everything that is shared, read in one go so it is consistent. */
    suspend fun exportAll(farmName: String, now: Long): SyncData =
        db.withTransaction {
            SyncData(
                farmName = farmName,
                exportedAt = now,
                reports = dao.getAllReports(),
                lines = dao.getAllLines(),
                extras = dao.getAllExtras(),
                eggSales = dao.getAllEggSales(),
                saleLines = dao.getAllSaleLines(),
                feedTxns = dao.getAllFeedTxns(),
                birdRecords = dao.getAllBirdRecords(),
                stock = dao.getStock()
            )
        }

    /**
     * Brings the records of another phone into this one. For every record (a day's report, a day's egg sale,
     * a feed entry) the newer version wins; nothing is removed. Stock is copied from the file only if it is newer.
     */
    suspend fun merge(incoming: SyncData): MergeResult =
        db.withTransaction {
            var reports = Counts()
            var eggSales = Counts()
            var feed = Counts()
            var birds = Counts()

            val linesByDate = incoming.lines.groupBy { it.reportDate }
            val extrasByDate = incoming.extras.groupBy { it.reportDate }
            incoming.reports.forEach { r ->
                val action = SyncMerge.decide(r.updatedAt, dao.getReport(r.date)?.updatedAt)
                reports = reports.with(action)
                if (action != MergeAction.KEEP) {
                    dao.upsertReport(r)
                    dao.deleteLines(r.date)
                    dao.insertLines((linesByDate[r.date] ?: emptyList()).map { it.copy(id = 0) })
                    dao.deleteExtras(r.date)
                    dao.insertExtras((extrasByDate[r.date] ?: emptyList()).map { it.copy(id = 0) })
                }
            }

            val saleLinesByDate = incoming.saleLines.groupBy { it.reportDate }
            incoming.eggSales.forEach { e ->
                val action = SyncMerge.decide(e.updatedAt, dao.getEggSale(e.date)?.updatedAt)
                eggSales = eggSales.with(action)
                if (action != MergeAction.KEEP) {
                    dao.upsertEggSale(e)
                    dao.deleteSales(e.date)
                    dao.insertSales((saleLinesByDate[e.date] ?: emptyList()).map { it.copy(id = 0) })
                }
            }

            incoming.feedTxns.forEach { t ->
                val action = SyncMerge.decide(t.updatedAt, dao.getFeedTxn(t.id)?.updatedAt)
                feed = feed.with(action)
                if (action != MergeAction.KEEP) dao.upsertFeedTxn(t)
            }

            // A day of farm records is merged as a whole: the newer day wins.
            incoming.birdRecords.groupBy { it.date }.forEach { (date, rows) ->
                val local = dao.getBirdRecords(date)
                val action = SyncMerge.decide(rows.maxOf { it.updatedAt }, local.maxOfOrNull { it.updatedAt })
                birds = birds.with(action)
                if (action != MergeAction.KEEP) {
                    dao.deleteBirdRecords(date)
                    dao.insertBirdRecords(rows.map { it.copy(id = 0) })
                }
            }

            var stockReplaced = false
            var newStock: FarmStockEntity? = null
            incoming.stock?.let { s ->
                if (SyncMerge.decide(s.updatedAt, dao.getStock()?.updatedAt) != MergeAction.KEEP) {
                    val copy = s.copy(id = 1)
                    dao.upsertStock(copy)
                    stockReplaced = true
                    newStock = copy
                }
            }
            MergeResult(reports, eggSales, feed, stockReplaced, newStock, birds)
        }

    // ---- farm records (birds) ----

    suspend fun getBirdRecords(date: String): List<BirdRecordEntity> = dao.getBirdRecords(date)

    fun observeBirdRecords(): Flow<List<BirdRecordEntity>> = dao.observeBirdRecords()

    /** The last saved day before [date] and its records, or null if there is none. */
    suspend fun getLatestBirdDayBefore(date: String): Pair<String, List<BirdRecordEntity>>? {
        val d = dao.getLatestBirdDateBefore(date) ?: return null
        return d to dao.getBirdRecords(d)
    }

    /** Replaces all farm records of one date. An empty list clears the day. */
    suspend fun saveBirdDay(date: String, rows: List<BirdRecordEntity>) {
        db.withTransaction {
            dao.deleteBirdRecords(date)
            dao.insertBirdRecords(rows)
        }
    }

    // ---- feed purchase ----

    fun observeFeedTxns(): Flow<List<FeedTxnEntity>> = dao.observeFeedTxns()

    /** Saves a feed purchase, payment or old balance. The In-Stock screen is separate and is never changed here. */
    suspend fun addFeedEntry(txn: FeedTxnEntity) = dao.upsertFeedTxn(txn)

    enum class DeleteResult { DELETED, NOT_FOUND }

    /** Marks an entry as deleted (kept in the database so the delete can reach another phone). */
    suspend fun deleteFeedTxn(id: String, now: Long): DeleteResult =
        db.withTransaction {
            val t = dao.getFeedTxn(id)
            if (t == null || t.deleted) return@withTransaction DeleteResult.NOT_FOUND
            dao.upsertFeedTxn(t.copy(deleted = true, updatedAt = now))
            DeleteResult.DELETED
        }

    suspend fun getSchedule(): List<ScheduleItemEntity> = dao.getSchedule()

    /** Replaces the whole schedule; returns the new row ids in the same order as [items]. */
    suspend fun replaceSchedule(items: List<ScheduleItemEntity>): List<Long> =
        db.withTransaction {
            dao.clearSchedule()
            dao.insertSchedule(items)
        }

    /** All saved data between two ISO dates (inclusive), for the monthly dashboard. */
    suspend fun getMonth(start: String, end: String) = MonthData(
        reports = dao.getReportsBetween(start, end),
        lines = dao.getLinesBetween(start, end),
        extras = dao.getExtrasBetween(start, end),
        sales = dao.getSalesBetween(start, end),
        eggSales = dao.getEggSalesBetween(start, end)
    )

    suspend fun saveStock(stock: FarmStockEntity) = dao.upsertStock(stock)

    /** Saves report + lines (and optionally the updated stock) atomically. */
    suspend fun saveReport(
        report: DailyReportEntity,
        lines: List<FarmLineEntity>,
        extras: List<ExtraItemEntity>,
        newStock: FarmStockEntity?
    ) {
        db.withTransaction {
            dao.upsertReport(report)
            dao.deleteLines(report.date)
            dao.insertLines(lines)
            dao.deleteExtras(report.date)
            dao.insertExtras(extras)
            if (newStock != null) dao.upsertStock(newStock)
        }
    }
}
