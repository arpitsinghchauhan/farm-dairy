package com.farmdiary.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.room.withTransaction
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** v1 -> v2: adds user-defined extra expenditure items. Existing data is kept. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `extra_item` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`reportDate` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`amount` REAL NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_extra_item_reportDate` ON `extra_item` (`reportDate`)")
    }
}

/** v2 -> v3: adds the farm login (account) table. Existing data is kept. */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `account` (" +
                "`id` INTEGER PRIMARY KEY NOT NULL, " +
                "`phone` TEXT NOT NULL, " +
                "`credentialHash` TEXT NOT NULL, " +
                "`createdAt` INTEGER NOT NULL)"
        )
    }
}

/** v3 -> v4: production is now entered in trays, so old egg counts are converted (30 eggs = 1 tray). */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("UPDATE farm_line SET eggs = eggs / 30.0")
    }
}

/** v4 -> v5: egg sale lines + cash/online received. Old "Egg Sell" amounts become one sale line, marked as received in cash. */
val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN cashReceived REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN onlineReceived REAL NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `sale_line` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`reportDate` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`trays` REAL NOT NULL, " +
                "`rate` REAL NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sale_line_reportDate` ON `sale_line` (`reportDate`)")
        db.execSQL(
            "INSERT INTO sale_line (reportDate, position, name, trays, rate) " +
                "SELECT date, 0, 'Egg Sell', 1, eggSell FROM daily_report WHERE eggSell > 0"
        )
        db.execSQL("UPDATE daily_report SET cashReceived = eggSell WHERE eggSell > 0")
    }
}

@Database(
    entities = [
        DailyReportEntity::class,
        FarmLineEntity::class,
        FarmStockEntity::class,
        ExtraItemEntity::class,
        AccountEntity::class,
        SaleLineEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): FarmDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "farm_diary.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { instance = it }
        }
    }
}

data class MonthData(
    val reports: List<DailyReportEntity>,
    val lines: List<FarmLineEntity>,
    val extras: List<ExtraItemEntity>,
    val sales: List<SaleLineEntity>
)

class FarmRepository(private val db: AppDatabase) {
    private val dao = db.dao()

    fun observeReports(): Flow<List<DailyReportEntity>> = dao.observeReports()

    fun observeStock(): Flow<FarmStockEntity> = dao.observeStock().map { it ?: FarmStockEntity() }

    suspend fun getStock(): FarmStockEntity = dao.getStock() ?: FarmStockEntity()

    suspend fun getReport(date: String): DailyReportEntity? = dao.getReport(date)

    suspend fun getLines(date: String): List<FarmLineEntity> = dao.getLines(date)

    suspend fun getExtras(date: String): List<ExtraItemEntity> = dao.getExtras(date)

    suspend fun getSales(date: String): List<SaleLineEntity> = dao.getSales(date)

    /** All saved data between two ISO dates (inclusive), for the monthly dashboard. */
    suspend fun getMonth(start: String, end: String) = MonthData(
        reports = dao.getReportsBetween(start, end),
        lines = dao.getLinesBetween(start, end),
        extras = dao.getExtrasBetween(start, end),
        sales = dao.getSalesBetween(start, end)
    )

    suspend fun saveStock(stock: FarmStockEntity) = dao.upsertStock(stock)

    /** Saves report + lines (and optionally the updated stock) atomically. */
    suspend fun saveReport(
        report: DailyReportEntity,
        lines: List<FarmLineEntity>,
        extras: List<ExtraItemEntity>,
        sales: List<SaleLineEntity>,
        newStock: FarmStockEntity?
    ) {
        db.withTransaction {
            dao.upsertReport(report)
            dao.deleteLines(report.date)
            dao.insertLines(lines)
            dao.deleteExtras(report.date)
            dao.insertExtras(extras)
            dao.deleteSales(report.date)
            dao.insertSales(sales)
            if (newStock != null) dao.upsertStock(newStock)
        }
    }
}
