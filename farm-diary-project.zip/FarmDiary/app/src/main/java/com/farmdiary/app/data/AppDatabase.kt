package com.farmdiary.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.room.withTransaction
import androidx.sqlite.db.SupportSQLiteDatabase
import com.farmdiary.app.sync.Counts
import com.farmdiary.app.sync.MergeAction
import com.farmdiary.app.sync.MergeResult
import com.farmdiary.app.sync.SyncData
import com.farmdiary.app.sync.SyncMerge
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** v1 -> v2: adds user-defined extra expenditure items. Existing data is kept. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `extra_item` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`reportDate` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`amount` REAL NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_extra_item_reportDate` ON `extra_item` (`reportDate`)")
    }
}

/** v2 -> v3: adds the farm login (account) table. Existing data is kept. */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `account` (" +
                "`id` INTEGER PRIMARY KEY NOT NULL, " +
                "`phone` TEXT NOT NULL, " +
                "`credentialHash` TEXT NOT NULL, " +
                "`createdAt` INTEGER NOT NULL)"
        )
    }
}

/** v3 -> v4: production is now entered in trays, so old egg counts are converted (30 eggs = 1 tray). */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("UPDATE farm_line SET eggs = eggs / 30.0")
    }
}

/** v4 -> v5: egg sale lines + cash/online received. Old "Egg Sell" amounts become one sale line, marked as received in cash. */
val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN cashReceived REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN onlineReceived REAL NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `sale_line` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`reportDate` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`trays` REAL NOT NULL, " +
                "`rate` REAL NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sale_line_reportDate` ON `sale_line` (`reportDate`)")
        db.execSQL(
            "INSERT INTO sale_line (reportDate, position, name, trays, rate) " +
                "SELECT date, 0, 'Egg Sell', 1, eggSell FROM daily_report WHERE eggSell > 0"
        )
        db.execSQL("UPDATE daily_report SET cashReceived = eggSell WHERE eggSell > 0")
    }
}

/**
 * v5 -> v6: water tanks, tray stock used, mortality per farm, a separate egg-sale header table
 * (cash / online per day) and the scheduler. Existing data is kept; old cash / online amounts are copied.
 */
val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN waterTanks REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN confirmedTrayUsed REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN openingTrays REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN closingTrays REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE farm_line ADD COLUMN mortality INTEGER NOT NULL DEFAULT 0")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `egg_sale` (" +
                "`date` TEXT NOT NULL, " +
                "`cashReceived` REAL NOT NULL, " +
                "`onlineReceived` REAL NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`date`))"
        )
        db.execSQL(
            "INSERT INTO egg_sale (date, cashReceived, onlineReceived, updatedAt) " +
                "SELECT date, cashReceived, onlineReceived, updatedAt FROM daily_report " +
                "WHERE cashReceived > 0 OR onlineReceived > 0 OR date IN (SELECT reportDate FROM sale_line)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `schedule_item` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`title` TEXT NOT NULL, " +
                "`details` TEXT NOT NULL, " +
                "`hour` INTEGER NOT NULL, " +
                "`minute` INTEGER NOT NULL, " +
                "`reminderOn` INTEGER NOT NULL)"
        )
    }
}

/** v6 -> v7: egg sale gets previous balance, advance paid and revised rate. Existing sales are kept. */
val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE egg_sale ADD COLUMN previousBalance REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE egg_sale ADD COLUMN advancePaid REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE egg_sale ADD COLUMN closingBalance REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sale_line ADD COLUMN revisedRate REAL NOT NULL DEFAULT 0")
        // Old sales had no previous balance or advance, so their closing balance is what was left to receive.
        db.execSQL(
            "UPDATE egg_sale SET closingBalance = " +
                "(SELECT COALESCE(SUM(trays * rate), 0) FROM sale_line WHERE sale_line.reportDate = egg_sale.date) " +
                "- cashReceived - onlineReceived"
        )
    }
}

/** v7 -> v8: feed purchase ledger (purchases and payments to the supplier). */
/**
 * v8 -> v9: egg price is now entered per EGG (a tray = 30 eggs), and a confirmed report remembers the egg stock of its day.
 * Old prices were per tray, so they are divided by 30 and every old sale keeps exactly the same amount.
 */
val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("UPDATE sale_line SET rate = rate / 30.0, revisedRate = revisedRate / 30.0")
        db.execSQL("ALTER TABLE daily_report ADD COLUMN closingEggTrays INTEGER NOT NULL DEFAULT -1")
    }
}

/** v9 -> v10: Farm Records (per farm, per date). */
val MIGRATION_9_10 = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `bird_record` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`date` TEXT NOT NULL, " +
                "`position` INTEGER NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`dayNo` INTEGER NOT NULL, " +
                "`feedPerBirdGrams` REAL NOT NULL, " +
                "`feedBags` REAL NOT NULL, " +
                "`stoneBags` REAL NOT NULL, " +
                "`production` REAL NOT NULL, " +
                "`mortality` INTEGER NOT NULL, " +
                "`breakage` INTEGER NOT NULL, " +
                "`waterTanks` REAL NOT NULL, " +
                "`medicines` TEXT NOT NULL, " +
                "`notes` TEXT NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_bird_record_date` ON `bird_record` (`date`)")
    }
}

/** v13 -> v14: scheduler tasks can be daily, weekly or monthly. */
val MIGRATION_13_14 = object : Migration(13, 14) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE schedule_item ADD COLUMN kind TEXT NOT NULL DEFAULT 'DAILY'")
        db.execSQL("ALTER TABLE schedule_item ADD COLUMN dayOfWeek INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE schedule_item ADD COLUMN dayOfMonth INTEGER NOT NULL DEFAULT 1")
    }
}

/** v18 -> v19: stock left of a past date, written by hand. */
val MIGRATION_18_19 = object : Migration(18, 19) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `stock_day` (" +
                "`date` TEXT NOT NULL, " +
                "`feedLeft` REAL NOT NULL, " +
                "`trayLeft` INTEGER NOT NULL, " +
                "`eggTrays` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`date`))"
        )
    }
}

/** v17 -> v18: a confirmed report remembers how much it changed the egg stock. */
val MIGRATION_17_18 = object : Migration(17, 18) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN eggNet REAL NOT NULL DEFAULT 0")
    }
}

/** v16 -> v17: the Daily Report gets the egg rate of the day, and each farm line the age of its birds. */
val MIGRATION_16_17 = object : Migration(16, 17) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE daily_report ADD COLUMN eggRate REAL NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE farm_line ADD COLUMN dayNo INTEGER NOT NULL DEFAULT 0")
    }
}

/** v15 -> v16: an employee gets a monthly salary. */
val MIGRATION_15_16 = object : Migration(15, 16) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE employee ADD COLUMN monthlySalary REAL NOT NULL DEFAULT 0")
    }
}

/** v14 -> v15: employees and the cash / online payments given to them. */
val MIGRATION_14_15 = object : Migration(14, 15) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `employee` (" +
                "`id` TEXT NOT NULL, " +
                "`name` TEXT NOT NULL, " +
                "`deleted` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`id`))"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `employee_payment` (" +
                "`id` TEXT NOT NULL, " +
                "`employeeId` TEXT NOT NULL, " +
                "`date` TEXT NOT NULL, " +
                "`mode` TEXT NOT NULL, " +
                "`amount` REAL NOT NULL, " +
                "`note` TEXT NOT NULL, " +
                "`deleted` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`id`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_employee_payment_date` ON `employee_payment` (`date`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_employee_payment_employeeId` ON `employee_payment` (`employeeId`)")
    }
}

/** v12 -> v13: the revised rate is now a price cut per egg (it used to be the new price). */
val MIGRATION_12_13 = object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "UPDATE sale_line SET revisedRate = CASE WHEN revisedRate > 0 AND revisedRate < rate " +
                "THEN rate - revisedRate ELSE 0 END"
        )
    }
}

/** v11 -> v12: the purchase table also holds medicine purchases. */
val MIGRATION_11_12 = object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE feed_txn ADD COLUMN category TEXT NOT NULL DEFAULT 'FEED'")
        db.execSQL("ALTER TABLE feed_txn ADD COLUMN item TEXT NOT NULL DEFAULT ''")
    }
}

/** v10 -> v11: farm records get the bird count at the start of the day. */
val MIGRATION_10_11 = object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE bird_record ADD COLUMN birdsStart INTEGER NOT NULL DEFAULT 0")
    }
}

val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `feed_txn` (" +
                "`id` TEXT NOT NULL, " +
                "`date` TEXT NOT NULL, " +
                "`type` TEXT NOT NULL, " +
                "`bags` REAL NOT NULL, " +
                "`rate` REAL NOT NULL, " +
                "`discount` REAL NOT NULL, " +
                "`amount` REAL NOT NULL, " +
                "`note` TEXT NOT NULL, " +
                "`deleted` INTEGER NOT NULL, " +
                "`createdAt` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`id`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_feed_txn_date` ON `feed_txn` (`date`)")
    }
}

@Database(
    entities = [
        DailyReportEntity::class,
        FarmLineEntity::class,
        FarmStockEntity::class,
        ExtraItemEntity::class,
        AccountEntity::class,
        SaleLineEntity::class,
        EggSaleEntity::class,
        ScheduleItemEntity::class,
        FeedTxnEntity::class,
        BirdRecordEntity::class,
        EmployeeEntity::class,
        EmployeePaymentEntity::class,
        StockDayEntity::class
    ],
    version = 19,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): FarmDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "farm_diary.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18, MIGRATION_18_19).build().also { instance = it }
        }
    }
}

data class MonthData(
    val reports: List<DailyReportEntity>,
    val lines: List<FarmLineEntity>,
    val extras: List<ExtraItemEntity>,
    val sales: List<SaleLineEntity>,
    val eggSales: List<EggSaleEntity>,
    val birds: List<BirdRecordEntity> = emptyList()
)

class FarmRepository(private val db: AppDatabase) {
    private val dao = db.dao()

    fun observeReports(): Flow<List<DailyReportEntity>> = dao.observeReports()

    fun observeStock(): Flow<FarmStockEntity> = dao.observeStock().map { it ?: FarmStockEntity() }

    suspend fun getStock(): FarmStockEntity = dao.getStock() ?: FarmStockEntity()

    suspend fun getReport(date: String): DailyReportEntity? = dao.getReport(date)

    suspend fun getLines(date: String): List<FarmLineEntity> = dao.getLines(date)

    suspend fun getExtras(date: String): List<ExtraItemEntity> = dao.getExtras(date)

    suspend fun getSales(date: String): List<SaleLineEntity> = dao.getSales(date)

    suspend fun getEggSale(date: String): EggSaleEntity? = dao.getEggSale(date)

    suspend fun getLatestEggSaleBefore(date: String): EggSaleEntity? = dao.getLatestEggSaleBefore(date)

    /** Saves the egg sale of one day (lines + cash/online) atomically. */
    suspend fun saveEggSale(sale: EggSaleEntity, lines: List<SaleLineEntity>) {
        db.withTransaction {
            dao.upsertEggSale(sale)
            dao.deleteSales(sale.date)
            dao.insertSales(lines)
        }
    }

    fun observeSchedule(): Flow<List<ScheduleItemEntity>> = dao.observeSchedule()

    // ---- sharing data with another phone ----

    /** A copy of everything that is shared, read in one go so it is consistent. */
    suspend fun exportAll(farmName: String, now: Long, scheduleUpdatedAt: Long = 0L, farmCount: Int = 0): SyncData =
        db.withTransaction {
            SyncData(
                farmName = farmName,
                exportedAt = now,
                reports = dao.getAllReports(),
                lines = dao.getAllLines(),
                extras = dao.getAllExtras(),
                eggSales = dao.getAllEggSales(),
                saleLines = dao.getAllSaleLines(),
                feedTxns = dao.getAllFeedTxns(),
                birdRecords = dao.getAllBirdRecords(),
                employees = dao.getAllEmployees(),
                employeePayments = dao.getAllEmployeePayments(),
                stockDays = dao.getAllStockDays(),
                schedule = dao.getSchedule(),
                scheduleUpdatedAt = scheduleUpdatedAt,
                farmCount = farmCount,
                stock = dao.getStock()
            )
        }

    /**
     * Brings the records of another phone into this one. For every record (a day's report, a day's egg sale,
     * a feed entry) the newer version wins; nothing is removed. Stock is copied from the file only if it is newer.
     */
    suspend fun merge(incoming: SyncData, localScheduleUpdatedAt: Long = 0L): MergeResult =
        db.withTransaction {
            var reports = Counts()
            var eggSales = Counts()
            var feed = Counts()
            var birds = Counts()
            var employees = Counts()
            var employeePayments = Counts()
            var stockDays = Counts()

            val linesByDate = incoming.lines.groupBy { it.reportDate }
            val extrasByDate = incoming.extras.groupBy { it.reportDate }
            incoming.reports.forEach { r ->
                val action = SyncMerge.decide(r.updatedAt, dao.getReport(r.date)?.updatedAt)
                reports = reports.with(action)
                if (action != MergeAction.KEEP) {
                    dao.upsertReport(r)
                    dao.deleteLines(r.date)
                    dao.insertLines((linesByDate[r.date] ?: emptyList()).map { it.copy(id = 0) })
                    dao.deleteExtras(r.date)
                    dao.insertExtras((extrasByDate[r.date] ?: emptyList()).map { it.copy(id = 0) })
                }
            }

            val saleLinesByDate = incoming.saleLines.groupBy { it.reportDate }
            incoming.eggSales.forEach { e ->
                val action = SyncMerge.decide(e.updatedAt, dao.getEggSale(e.date)?.updatedAt)
                eggSales = eggSales.with(action)
                if (action != MergeAction.KEEP) {
                    dao.upsertEggSale(e)
                    dao.deleteSales(e.date)
                    dao.insertSales((saleLinesByDate[e.date] ?: emptyList()).map { it.copy(id = 0) })
                }
            }

            incoming.feedTxns.forEach { t ->
                val action = SyncMerge.decide(t.updatedAt, dao.getFeedTxn(t.id)?.updatedAt)
                feed = feed.with(action)
                if (action != MergeAction.KEEP) dao.upsertFeedTxn(t)
            }

            incoming.employees.forEach { e ->
                val action = SyncMerge.decide(e.updatedAt, dao.getEmployee(e.id)?.updatedAt)
                employees = employees.with(action)
                if (action != MergeAction.KEEP) dao.upsertEmployee(e)
            }
            incoming.employeePayments.forEach { t ->
                val action = SyncMerge.decide(t.updatedAt, dao.getEmployeePayment(t.id)?.updatedAt)
                employeePayments = employeePayments.with(action)
                if (action != MergeAction.KEEP) dao.upsertEmployeePayment(t)
            }

            incoming.stockDays.forEach { t ->
                val action = SyncMerge.decide(t.updatedAt, dao.getStockDay(t.date)?.updatedAt)
                stockDays = stockDays.with(action)
                if (action != MergeAction.KEEP) dao.upsertStockDay(t)
            }

            // A day of farm records is merged as a whole: the newer day wins.
            incoming.birdRecords.groupBy { it.date }.forEach { (date, rows) ->
                val local = dao.getBirdRecords(date)
                val action = SyncMerge.decide(rows.maxOf { it.updatedAt }, local.maxOfOrNull { it.updatedAt })
                birds = birds.with(action)
                if (action != MergeAction.KEEP) {
                    dao.deleteBirdRecords(date)
                    dao.insertBirdRecords(rows.map { it.copy(id = 0) })
                }
            }

            // The Scheduler is one list: the newer saved list replaces the other one as a whole.
            val scheduleReplaced = incoming.scheduleUpdatedAt > localScheduleUpdatedAt
            if (scheduleReplaced) {
                dao.clearSchedule()
                dao.insertSchedule(incoming.schedule.map { it.copy(id = 0) })
            }

            var stockReplaced = false
            var newStock: FarmStockEntity? = null
            incoming.stock?.let { s ->
                if (SyncMerge.decide(s.updatedAt, dao.getStock()?.updatedAt) != MergeAction.KEEP) {
                    val copy = s.copy(id = 1)
                    dao.upsertStock(copy)
                    stockReplaced = true
                    newStock = copy
                }
            }
            MergeResult(reports, eggSales, feed, stockReplaced, newStock, birds, scheduleReplaced, incoming.schedule.size, employees, employeePayments, stockDays)
        }

    suspend fun getEggSaleHistory(): Pair<List<EggSaleEntity>, List<SaleLineEntity>> =
        db.withTransaction { dao.getAllEggSales() to dao.getAllSaleLines() }

    // ---- farm records (birds) ----

    suspend fun getBirdRecords(date: String): List<BirdRecordEntity> = dao.getBirdRecords(date)

    fun observeBirdRecords(): Flow<List<BirdRecordEntity>> = dao.observeBirdRecords()

    /** The last saved day before [date] and its records, or null if there is none. */
    suspend fun getLatestBirdDayBefore(date: String): Pair<String, List<BirdRecordEntity>>? {
        val d = dao.getLatestBirdDateBefore(date) ?: return null
        return d to dao.getBirdRecords(d)
    }

    /** Replaces all farm records of one date. An empty list clears the day. */
    suspend fun saveBirdDay(date: String, rows: List<BirdRecordEntity>) {
        db.withTransaction {
            dao.deleteBirdRecords(date)
            dao.insertBirdRecords(rows)
        }
    }

    // ---- feed purchase ----

    fun observeFeedTxns(): Flow<List<FeedTxnEntity>> = dao.observeFeedTxns()

    /** Saves a feed purchase, payment or old balance. The In-Stock screen is separate and is never changed here. */
    suspend fun addFeedEntry(txn: FeedTxnEntity) = dao.upsertFeedTxn(txn)

    enum class DeleteResult { DELETED, NOT_FOUND }

    /** Marks an entry as deleted (kept in the database so the delete can reach another phone). */
    suspend fun deleteFeedTxn(id: String, now: Long): DeleteResult =
        db.withTransaction {
            val t = dao.getFeedTxn(id)
            if (t == null || t.deleted) return@withTransaction DeleteResult.NOT_FOUND
            dao.upsertFeedTxn(t.copy(deleted = true, updatedAt = now))
            DeleteResult.DELETED
        }

    // ---- employees ----

    fun observeEmployees(): Flow<List<EmployeeEntity>> = dao.observeEmployees()

    fun observeEmployeePayments(): Flow<List<EmployeePaymentEntity>> = dao.observeEmployeePayments()

    /** Adds an employee unless there are already [max] active ones. Returns false when the limit is reached. */
    suspend fun addEmployee(e: EmployeeEntity, max: Int): Boolean =
        db.withTransaction {
            if (dao.countEmployees() >= max) return@withTransaction false
            dao.upsertEmployee(e)
            true
        }

    suspend fun getEmployee(id: String): EmployeeEntity? = dao.getEmployee(id)

    suspend fun saveEmployee(e: EmployeeEntity) = dao.upsertEmployee(e)

    suspend fun saveEmployeePayment(p: EmployeePaymentEntity) = dao.upsertEmployeePayment(p)

    suspend fun getEmployeePayment(id: String): EmployeePaymentEntity? = dao.getEmployeePayment(id)

    suspend fun getSchedule(): List<ScheduleItemEntity> = dao.getSchedule()

    /** Replaces the whole schedule; returns the new row ids in the same order as [items]. */
    suspend fun replaceSchedule(items: List<ScheduleItemEntity>): List<Long> =
        db.withTransaction {
            dao.clearSchedule()
            dao.insertSchedule(items)
        }

    /** All saved data between two ISO dates (inclusive), for the monthly dashboard. */
    suspend fun getMonth(start: String, end: String) = MonthData(
        reports = dao.getReportsBetween(start, end),
        lines = dao.getLinesBetween(start, end),
        extras = dao.getExtrasBetween(start, end),
        sales = dao.getSalesBetween(start, end),
        eggSales = dao.getEggSalesBetween(start, end),
        birds = dao.getBirdRecordsBetween(start, end)
    )

    fun observeStockDays(): Flow<List<StockDayEntity>> = dao.observeStockDays()

    /**
     * Writes the stock left of one past date (a null figure is left as it is / blank).
     * A date with a confirmed Daily Report changes that report's record, so the report shows the same numbers;
     * any other date gets a hand-written stock record. The stock now (Home) is never touched.
     */
    suspend fun setDayStock(date: String, feedLeft: Double?, traysLeft: Int?, eggTrays: Int?, now: Long) {
        db.withTransaction {
            val r = dao.getReport(date)
            if (r != null && r.confirmed) {
                dao.upsertReport(
                    r.copy(
                        closingFeed = feedLeft ?: r.closingFeed,
                        openingFeed = (feedLeft ?: r.closingFeed) + r.confirmedFeedUsed,
                        closingTrays = traysLeft?.toDouble() ?: r.closingTrays,
                        openingTrays = (traysLeft?.toDouble() ?: r.closingTrays) + r.confirmedTrayUsed,
                        closingEggTrays = eggTrays ?: r.closingEggTrays,
                        updatedAt = now
                    )
                )
            } else {
                val old = dao.getStockDay(date)
                dao.upsertStockDay(
                    StockDayEntity(
                        date = date,
                        feedLeft = feedLeft ?: old?.feedLeft ?: -1.0,
                        trayLeft = traysLeft ?: old?.trayLeft ?: -1,
                        eggTrays = eggTrays ?: old?.eggTrays ?: -1,
                        updatedAt = now
                    )
                )
            }
        }
    }

    suspend fun getLinesOf(date: String): List<FarmLineEntity> = dao.getLines(date)

    suspend fun getLatestReportBefore(date: String): DailyReportEntity? = dao.getLatestReportBefore(date)

    /**
     * Keeps Farm Records in step with a saved Daily Report: bags used, production and mortality of each farm are written
     * to the farm records of that date. A farm that has no record yet gets one (birds and age counted forward from the last day).
     */
    suspend fun linkReportToBirds(date: String, lines: List<FarmLineEntity>, now: Long) {
        db.withTransaction {
            val existing = dao.getBirdRecords(date)
            val byPos = existing.associateBy { it.position }
            val prev = if (existing.isEmpty()) getLatestBirdDayBefore(date) else null
            val gap = prev?.let { java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.parse(it.first), java.time.LocalDate.parse(date)).coerceAtLeast(0) } ?: 0L
            val result = existing.associateBy { it.position }.toMutableMap()
            var touched = false
            lines.forEach { l ->
                val r = byPos[l.position]
                if (r != null) {
                    if (r.feedBags != l.feedBags || r.production != l.trays || r.mortality != l.mortality) touched = true
                    result[l.position] = r.copy(feedBags = l.feedBags, production = l.trays, mortality = l.mortality)
                } else if (l.feedBags > 0 || l.trays > 0 || l.mortality > 0) {
                    touched = true
                    val p = prev?.second?.firstOrNull { it.position == l.position }
                    result[l.position] = BirdRecordEntity(
                        date = date, position = l.position, name = l.name,
                        dayNo = if (p != null && p.dayNo > 0) (p.dayNo + gap).toInt() else l.dayNo,
                        feedPerBirdGrams = 0.0, feedBags = l.feedBags, stoneBags = 0.0, production = l.trays,
                        mortality = l.mortality, breakage = 0, waterTanks = 0.0, medicines = "", notes = "",
                        updatedAt = now,
                        birdsStart = if (p != null && p.birdsStart > 0) (p.birdsStart - p.mortality).coerceAtLeast(0) else 0
                    )
                }
            }
            if (touched) {
                dao.deleteBirdRecords(date)
                dao.insertBirdRecords(result.values.sortedBy { it.position }.map { it.copy(id = 0, updatedAt = now) })
            }
        }
    }

    /** The last day before [date] whose farm lines have an age written, with those lines. */
    suspend fun getLatestAgedLinesBefore(date: String): Pair<String, List<FarmLineEntity>>? {
        val d = dao.getLatestAgedLineDateBefore(date) ?: return null
        return d to dao.getLines(d)
    }

    suspend fun saveStock(stock: FarmStockEntity) = dao.upsertStock(stock)

    /** Saves report + lines (and optionally the updated stock) atomically. */
    suspend fun saveReport(
        report: DailyReportEntity,
        lines: List<FarmLineEntity>,
        extras: List<ExtraItemEntity>,
        newStock: FarmStockEntity?
    ) {
        db.withTransaction {
            dao.upsertReport(report)
            dao.deleteLines(report.date)
            dao.insertLines(lines)
            dao.deleteExtras(report.date)
            dao.insertExtras(extras)
            if (newStock != null) dao.upsertStock(newStock)
        }
    }
}
