package com.farmdiary.app.domain

import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.SaleLineEntity
import java.time.LocalDate
import java.time.YearMonth

data class DayTotals(val day: Int, val expenditure: Double, val income: Double)

data class MonthSummary(
    val month: YearMonth,
    val days: List<DayTotals>,
    val reportCount: Int,
    val expenditure: Double,
    val income: Double,
    val cash: Double,
    val online: Double,
    val traysProduced: Double,
    val traysSold: Double,
    val birdsDied: Int,
    val waterTanks: Double
) {
    val profit: Double get() = income - expenditure
    val balanceToReceive: Double get() = income - cash - online
}

object Dashboard {
    fun build(
        month: YearMonth,
        reports: List<DailyReportEntity>,
        lines: List<FarmLineEntity>,
        extras: List<ExtraItemEntity>,
        sales: List<SaleLineEntity>,
        eggSales: List<EggSaleEntity>
    ): MonthSummary {
        val expenditureByDate = HashMap<String, Double>()
        fun addExpense(date: String, amount: Double) {
            expenditureByDate[date] = (expenditureByDate[date] ?: 0.0) + amount
        }
        reports.forEach {
            addExpense(
                it.date,
                it.trayQty * it.trayRate + it.labour + it.light + it.stoneQty * it.stoneRate
            )
        }
        lines.forEach { addExpense(it.reportDate, it.feedBags * it.feedRate) }
        extras.forEach { addExpense(it.reportDate, it.amount) }

        // Income comes from the Egg Sell entries, so a sale counts even if no report was saved that day.
        val incomeByDate = HashMap<String, Double>()
        sales.forEach { incomeByDate[it.reportDate] = (incomeByDate[it.reportDate] ?: 0.0) + it.trays * it.rate }

        val days = (1..month.lengthOfMonth()).map { d ->
            val key = month.atDay(d).toString()
            DayTotals(d, expenditureByDate[key] ?: 0.0, incomeByDate[key] ?: 0.0)
        }
        return MonthSummary(
            month = month,
            days = days,
            reportCount = reports.size,
            expenditure = days.sumOf { it.expenditure },
            income = days.sumOf { it.income },
            cash = eggSales.sumOf { it.cashReceived },
            online = eggSales.sumOf { it.onlineReceived },
            traysProduced = lines.sumOf { it.trays },
            traysSold = sales.sumOf { it.trays },
            birdsDied = lines.sumOf { it.mortality },
            waterTanks = reports.sumOf { it.waterTanks }
        )
    }
}
