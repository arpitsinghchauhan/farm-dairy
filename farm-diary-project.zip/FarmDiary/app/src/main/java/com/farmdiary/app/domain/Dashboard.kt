package com.farmdiary.app.domain

import com.farmdiary.app.data.BirdRecordEntity
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.SaleLineEntity
import java.time.LocalDate
import java.time.YearMonth

data class DayTotals(val day: Int, val expenditure: Double, val income: Double, val eggRate: Double = 0.0)

/** One farm's month for the dashboard graphs. A value of 0 means nothing was written that day. */
data class FarmDay(val day: Int, val birdsLeft: Int, val productionPercent: Double)

data class FarmSeries(val position: Int, val name: String, val days: List<FarmDay>) {
    val hasBirds: Boolean get() = days.any { it.birdsLeft > 0 }
    val hasProduction: Boolean get() = days.any { it.productionPercent > 0.0 }
}

data class MonthSummary(
    val month: YearMonth,
    val days: List<DayTotals>,
    val reportCount: Int,
    val expenditure: Double,
    val income: Double,
    val cash: Double,
    val online: Double,
    val advance: Double,
    val outstanding: Double,
    val traysProduced: Double,
    val traysSold: Double,
    val birdsDied: Int,
    val farms: List<FarmSeries> = emptyList()
) {
    val hasEggRate: Boolean get() = days.any { it.eggRate > 0.0 }
    val profit: Double get() = income - expenditure
    val balanceToReceive: Double get() = income - cash - online - advance
}

object Dashboard {
    fun build(
        month: YearMonth,
        reports: List<DailyReportEntity>,
        lines: List<FarmLineEntity>,
        extras: List<ExtraItemEntity>,
        sales: List<SaleLineEntity>,
        eggSales: List<EggSaleEntity>,
        birds: List<BirdRecordEntity> = emptyList()
    ): MonthSummary {
        val expenditureByDate = HashMap<String, Double>()
        fun addExpense(date: String, amount: Double) {
            expenditureByDate[date] = (expenditureByDate[date] ?: 0.0) + amount
        }
        reports.forEach {
            addExpense(
                it.date,
                it.trayQty * it.trayRate + it.labour + it.light + it.stoneQty * it.stoneRate
            )
        }
        lines.forEach { addExpense(it.reportDate, it.feedBags * it.feedRate) }
        extras.forEach { addExpense(it.reportDate, it.amount) }

        // Income comes from the Egg Sell entries, so a sale counts even if no report was saved that day.
        val incomeByDate = HashMap<String, Double>()
        sales.forEach { incomeByDate[it.reportDate] = (incomeByDate[it.reportDate] ?: 0.0) + it.amount }

        val rateByDate = reports.associate { it.date to it.eggRate }

        val days = (1..month.lengthOfMonth()).map { d ->
            val key = month.atDay(d).toString()
            DayTotals(d, expenditureByDate[key] ?: 0.0, incomeByDate[key] ?: 0.0, rateByDate[key] ?: 0.0)
        }
        return MonthSummary(
            month = month,
            days = days,
            reportCount = reports.size,
            expenditure = days.sumOf { it.expenditure },
            income = days.sumOf { it.income },
            cash = eggSales.sumOf { it.cashReceived },
            online = eggSales.sumOf { it.onlineReceived },
            advance = eggSales.sumOf { it.advancePaid },
            outstanding = eggSales.maxByOrNull { it.date }?.closingBalance ?: 0.0,
            traysProduced = lines.sumOf { it.trays },
            traysSold = sales.sumOf { it.trays },
            birdsDied = lines.sumOf { it.mortality },
            farms = farmSeries(month, birds)
        )
    }

    /** Birds left and production % of every farm (by its row number), day by day. */
    fun farmSeries(month: YearMonth, birds: List<BirdRecordEntity>): List<FarmSeries> =
        birds.groupBy { it.position }.toSortedMap().map { (pos, rows) ->
            val byDate = rows.associateBy { it.date }
            val name = rows.maxByOrNull { it.date }?.name ?: "S.No. ${pos + 1}"
            FarmSeries(
                pos, name,
                (1..month.lengthOfMonth()).map { d ->
                    val r = byDate[month.atDay(d).toString()]
                    if (r == null || r.birdsStart <= 0) {
                        FarmDay(d, 0, 0.0)
                    } else {
                        FarmDay(d, (r.birdsStart - r.mortality).coerceAtLeast(0), BirdRecords.productionPercent(r.production, r.birdsStart))
                    }
                }
            )
        }
}
