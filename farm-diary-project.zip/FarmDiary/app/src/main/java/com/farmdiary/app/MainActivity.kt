package com.farmdiary.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.farmdiary.app.ui.AuthScreen
import com.farmdiary.app.ui.DashboardScreen
import com.farmdiary.app.ui.BirdHistoryScreen
import com.farmdiary.app.ui.BirdScreen
import com.farmdiary.app.ui.EggSaleHistoryScreen
import com.farmdiary.app.ui.EggSellScreen
import com.farmdiary.app.ui.EmployeeDetailScreen
import com.farmdiary.app.ui.EmployeeListScreen
import com.farmdiary.app.ui.FeedBuyScreen
import com.farmdiary.app.ui.FeedHubScreen
import com.farmdiary.app.ui.FeedPaymentScreen
import com.farmdiary.app.ui.FeedReportScreen
import com.farmdiary.app.ui.ShareScreen
import com.farmdiary.app.ui.SchedulerScreen
import com.farmdiary.app.ui.FarmDiaryTheme
import com.farmdiary.app.ui.HomeScreen
import com.farmdiary.app.ui.ReportScreen
import com.farmdiary.app.ui.SavedReportsScreen
import com.farmdiary.app.ui.StockScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(this)
        AppLog.i("App opened")
        StockAlerts.scheduleDaily(this)
        // Low stock alerts need the notification permission; ask once.
        val settings = getSharedPreferences("settings", MODE_PRIVATE)
        if (android.os.Build.VERSION.SDK_INT >= 33 && !Reminders.canNotify(this) && !settings.getBoolean("asked_notifications", false)) {
            settings.edit().putBoolean("asked_notifications", true).apply()
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        Reminders.ensureChannel(this)
        com.farmdiary.app.ui.Palette.load(this)
        setContent {
            FarmDiaryTheme {
                val auth: AuthViewModel = viewModel()
                val authState by auth.state.collectAsState()
                when (authState) {
                    AuthState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    AuthState.NeedSetup, AuthState.NeedPin, AuthState.LoggedOut -> AuthScreen(auth)
                    AuthState.LoggedIn -> {
                        val nav = rememberNavController()
                        val vm: FarmViewModel = viewModel()
                        val dash: DashboardViewModel = viewModel()
                        val sched: SchedulerViewModel = viewModel()
                        val feed: FeedViewModel = viewModel()
                        val med: MedicineViewModel = viewModel()
                        val share: ShareViewModel = viewModel()
                        val bird: BirdViewModel = viewModel()
                        val emp: EmployeeViewModel = viewModel()
                        share.onFarmNameImported = { vm.refreshFarmName() }
                                        NavHost(navController = nav, startDestination = "home") {
                            composable("home") {
                                HomeScreen(
                                    vm = vm,
                                    onDailyReport = {
                                        vm.setDate(java.time.LocalDate.now())
                                        nav.navigate("report")
                                    },
                                    onStock = { nav.navigate("stock") },
                                    onSaved = { nav.navigate("saved") },
                                    onLogout = { auth.logout() },
                                    onDashboard = { nav.navigate("dashboard") },
                                    onEggSell = {
                                        vm.setDate(java.time.LocalDate.now())
                                        nav.navigate("eggsell")
                                    },
                                    onScheduler = { nav.navigate("scheduler") },
                                    onFeed = { nav.navigate("feed") },
                                    onMedicine = { nav.navigate("med") },
                                    onShare = { nav.navigate("share") },
                                    onBirds = {
                                        bird.open(java.time.LocalDate.now())
                                        nav.navigate("birds")
                                    },
                                    onEmployees = { nav.navigate("employees") },
                                    sched = sched
                                )
                            }
                            composable("report") {
                                ReportScreen(vm, onEggSell = { nav.navigate("eggsell") }) { nav.popBackStack() }
                            }
                            composable("eggsell") {
                                EggSellScreen(vm, onHistory = { nav.navigate("eggsellhistory") }) { nav.popBackStack() }
                            }
                            composable("eggsellhistory") {
                                EggSaleHistoryScreen(
                                    vm = vm,
                                    onOpen = { d ->
                                        vm.setDate(d)
                                        nav.popBackStack()
                                    },
                                    onBack = { nav.popBackStack() }
                                )
                            }
                            composable("scheduler") { SchedulerScreen(sched) { nav.popBackStack() } }
                            composable("stock") { StockScreen(vm) { nav.popBackStack() } }
                            composable("dashboard") { DashboardScreen(dash) { nav.popBackStack() } }
                            composable("feed") {
                                FeedHubScreen(
                                    feed = feed,
                                    onBuy = { nav.navigate("feedbuy") },
                                    onOnline = { nav.navigate("feedonline") },
                                    onCash = { nav.navigate("feedcash") },
                                    onOpening = { nav.navigate("feedopening") },
                                    onReport = { nav.navigate("feedreport") },
                                    onBack = { nav.popBackStack() }
                                )
                            }
                            composable("feedbuy") { FeedBuyScreen(feed, java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("feedonline") { FeedPaymentScreen(feed, "ONLINE", java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("feedcash") { FeedPaymentScreen(feed, "CASH", java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("feedopening") { FeedPaymentScreen(feed, "OPENING", java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("feedreport") {
                                FeedReportScreen(feed, onOpen = { t ->
                                    nav.navigate(
                                        when (t.type) {
                                            "BUY" -> "feedbuy"
                                            "ONLINE" -> "feedonline"
                                            "CASH" -> "feedcash"
                                            else -> "feedopening"
                                        }
                                    )
                                }) { nav.popBackStack() }
                            }
                            composable("med") {
                                FeedHubScreen(
                                    feed = med,
                                    onBuy = { nav.navigate("medbuy") },
                                    onOnline = { nav.navigate("medonline") },
                                    onCash = { nav.navigate("medcash") },
                                    onOpening = { nav.navigate("medopening") },
                                    onReport = { nav.navigate("medreport") },
                                    onBack = { nav.popBackStack() }
                                )
                            }
                            composable("medbuy") { FeedBuyScreen(med, java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("medonline") { FeedPaymentScreen(med, "ONLINE", java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("medcash") { FeedPaymentScreen(med, "CASH", java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("medopening") { FeedPaymentScreen(med, "OPENING", java.time.LocalDate.now()) { nav.popBackStack() } }
                            composable("medreport") {
                                FeedReportScreen(med, onOpen = { t ->
                                    nav.navigate(
                                        when (t.type) {
                                            "BUY" -> "medbuy"
                                            "ONLINE" -> "medonline"
                                            "CASH" -> "medcash"
                                            else -> "medopening"
                                        }
                                    )
                                }) { nav.popBackStack() }
                            }
                            composable("birds") {
                                BirdScreen(bird, onHistory = { nav.navigate("birdhistory") }) { nav.popBackStack() }
                            }
                            composable("birdhistory") {
                                BirdHistoryScreen(
                                    bird = bird,
                                    onOpen = { d ->
                                        bird.open(d)
                                        nav.popBackStack()
                                    },
                                    onBack = { nav.popBackStack() }
                                )
                            }
                            composable("employees") {
                                EmployeeListScreen(emp, onOpen = { id -> nav.navigate("employee/$id") }) { nav.popBackStack() }
                            }
                            composable("employee/{id}") { entry ->
                                EmployeeDetailScreen(emp, entry.arguments?.getString("id") ?: "") { nav.popBackStack() }
                            }
                            composable("share") { ShareScreen(share) { nav.popBackStack() } }
                            composable("saved") {
                                SavedReportsScreen(
                                    vm = vm,
                                    onOpen = { d ->
                                        vm.setDate(d)
                                        nav.navigate("report")
                                    },
                                    onBack = { nav.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
