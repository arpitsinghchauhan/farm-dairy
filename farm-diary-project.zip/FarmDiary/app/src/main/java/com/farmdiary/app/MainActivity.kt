package com.farmdiary.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.farmdiary.app.ui.AuthScreen
import com.farmdiary.app.ui.DashboardScreen
import com.farmdiary.app.ui.EggSellScreen
import com.farmdiary.app.ui.SchedulerScreen
import com.farmdiary.app.ui.FarmDiaryTheme
import com.farmdiary.app.ui.HomeScreen
import com.farmdiary.app.ui.ReportScreen
import com.farmdiary.app.ui.SavedReportsScreen
import com.farmdiary.app.ui.StockScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminders.ensureChannel(this)
        setContent {
            FarmDiaryTheme {
                val auth: AuthViewModel = viewModel()
                val authState by auth.state.collectAsState()
                when (authState) {
                    AuthState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    AuthState.NeedSetup, AuthState.LoggedOut -> AuthScreen(auth)
                    AuthState.LoggedIn -> {
                        val nav = rememberNavController()
                        val vm: FarmViewModel = viewModel()
                        val dash: DashboardViewModel = viewModel()
                        val sched: SchedulerViewModel = viewModel()
                        NavHost(navController = nav, startDestination = "home") {
                            composable("home") {
                                HomeScreen(
                                    vm = vm,
                                    onDailyReport = { nav.navigate("report") },
                                    onStock = { nav.navigate("stock") },
                                    onSaved = { nav.navigate("saved") },
                                    onLogout = { auth.logout() },
                                    onDashboard = { nav.navigate("dashboard") },
                                    onEggSell = { nav.navigate("eggsell") },
                                    onScheduler = { nav.navigate("scheduler") },
                                    sched = sched
                                )
                            }
                            composable("report") {
                                ReportScreen(vm, onEggSell = { nav.navigate("eggsell") }) { nav.popBackStack() }
                            }
                            composable("eggsell") { EggSellScreen(vm) { nav.popBackStack() } }
                            composable("scheduler") { SchedulerScreen(sched) { nav.popBackStack() } }
                            composable("stock") { StockScreen(vm) { nav.popBackStack() } }
                            composable("dashboard") { DashboardScreen(dash) { nav.popBackStack() } }
                            composable("saved") {
                                SavedReportsScreen(
                                    vm = vm,
                                    onOpen = { d ->
                                        vm.setDate(d)
                                        nav.navigate("report")
                                    },
                                    onBack = { nav.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
