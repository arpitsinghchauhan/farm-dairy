package com.farmdiary.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.farmdiary.app.ui.FarmDiaryTheme
import com.farmdiary.app.ui.HomeScreen
import com.farmdiary.app.ui.ReportScreen
import com.farmdiary.app.ui.SavedReportsScreen
import com.farmdiary.app.ui.StockScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FarmDiaryTheme {
                val nav = rememberNavController()
                val vm: FarmViewModel = viewModel()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            vm = vm,
                            onDailyReport = { nav.navigate("report") },
                            onStock = { nav.navigate("stock") },
                            onSaved = { nav.navigate("saved") }
                        )
                    }
                    composable("report") { ReportScreen(vm) { nav.popBackStack() } }
                    composable("stock") { StockScreen(vm) { nav.popBackStack() } }
                    composable("saved") {
                        SavedReportsScreen(
                            vm = vm,
                            onOpen = { d ->
                                vm.setDate(d)
                                nav.navigate("report")
                            },
                            onBack = { nav.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
