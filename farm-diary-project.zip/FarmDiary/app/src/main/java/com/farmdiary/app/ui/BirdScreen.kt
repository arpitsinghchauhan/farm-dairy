package com.farmdiary.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.BirdViewModel
import com.farmdiary.app.domain.MAX_BIRD_FARMS
import com.farmdiary.app.domain.MAX_MEDICINES

@Composable
fun BirdScreen(bird: BirdViewModel, onHistory: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val date by bird.date.collectAsState()
    val farms by bird.farms.collectAsState()
    val errors by bird.errors.collectAsState()
    val message by bird.message.collectAsState()
    val pdfUri by bird.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    OpenPdfEffect(pdfUri) { bird.clearOpenPdf() }
    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            bird.clearMessage()
        }
    }

    Scaffold(
        topBar = { FarmTopBar("Farm Records", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Panel)
                    .border(1.dp, Sun, RoundedCornerShape(20.dp))
                    .clickable { showDatePicker(context, date) { bird.setDate(it) } }
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("📅 Date (tap to change)", fontSize = 16.sp, color = TextLo)
                Text(date.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
            }

            farms.forEachIndexed { index, f ->
                SectionCard("Farm ${index + 1}", "🐔") {
                    OutlinedTextField(
                        value = f.name,
                        onValueChange = { v -> if (v.length <= 30) bird.edit(f.key) { it.copy(name = v) } },
                        label = { Text("Farm name (e.g. Shed ${index + 1})") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("Day (age of birds)", f.day, { v -> bird.edit(f.key) { it.copy(day = v) } }, Modifier.weight(1f), integer = true)
                        NumField("Feed per bird (grams)", f.feedPerBird, { v -> bird.edit(f.key) { it.copy(feedPerBird = v) } }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("Feed bags used", f.feedBags, { v -> bird.edit(f.key) { it.copy(feedBags = v) } }, Modifier.weight(1f))
                        NumField("Stone bags used", f.stoneBags, { v -> bird.edit(f.key) { it.copy(stoneBags = v) } }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("Production (trays)", f.production, { v -> bird.edit(f.key) { it.copy(production = v) } }, Modifier.weight(1f))
                        NumField("Mortality (birds)", f.mortality, { v -> bird.edit(f.key) { it.copy(mortality = v) } }, Modifier.weight(1f), integer = true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("Breakage (eggs)", f.breakage, { v -> bird.edit(f.key) { it.copy(breakage = v) } }, Modifier.weight(1f), integer = true)
                        NumField("Water tanks used", f.waterTanks, { v -> bird.edit(f.key) { it.copy(waterTanks = v) } }, Modifier.weight(1f))
                    }

                    Text("Medicines used today", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    f.medicines.forEachIndexed { i, m ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = m,
                                onValueChange = { v -> bird.editMedicine(f.key, i, v) },
                                label = { Text("Medicine ${i + 1}") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { bird.removeMedicine(f.key, i) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove medicine ${i + 1}")
                            }
                        }
                    }
                    if (f.medicines.size < MAX_MEDICINES) {
                        OutlinedButton(onClick = { bird.addMedicine(f.key) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Text("  Add medicine")
                        }
                    }

                    OutlinedTextField(
                        value = f.notes,
                        onValueChange = { v -> if (v.length <= 300) bird.edit(f.key) { it.copy(notes = v) } },
                        label = { Text("Notes") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp)
                    )

                    if (farms.size > 1) {
                        TextButton(onClick = { bird.removeFarm(f.key) }) {
                            Text("Remove this farm", fontSize = 16.sp, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            if (farms.size < MAX_BIRD_FARMS) {
                OutlinedButton(onClick = { bird.addFarm() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text("  Add another farm (up to $MAX_BIRD_FARMS)", fontSize = 18.sp)
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") {
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }

            GradientButton(
                text = "✅  Save Farm Records",
                onClick = { bird.save() },
                modifier = Modifier.fillMaxWidth()
            )
            GradientButton(
                text = "📄  Save and Download PDF",
                onClick = { bird.saveAndDownloadPdf() },
                brush = VioletBrush,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("🗂️  History of saved days", fontSize = 18.sp)
            }
            Text(
                "Saved for the date above. Change the date to see or write another day. " +
                    "A new day starts with the same farm names and the day number counted forward.",
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}
