package com.farmdiary.app.domain

import java.security.MessageDigest

object Credentials {
    const val PIN_MIN = 4
    const val PIN_MAX = 6

    fun isValidPhone(phone: String) = phone.length == 10 && phone.all { it.isDigit() }

    /** A PIN is 4 to 6 digits. */
    fun isValidPin(pin: String) = pin.length in PIN_MIN..PIN_MAX && pin.all { it.isDigit() }

    /** Questions to choose from when the login is created. */
    val QUESTIONS = listOf(
        "What is your mother's first name?",
        "What was the name of your first pet?",
        "In which town or village were you born?",
        "What is the name of your first school?",
        "What is your favourite food?"
    )

    fun isValidAnswer(answer: String) = answer.trim().length >= 2

    /** The answer is not case or space sensitive. */
    fun answerHash(phone: String, answer: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest("$phone|ans:${answer.trim().lowercase()}|farmdiary-v2".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /** Same phone + same PIN always give the same hash, on any device. */
    fun hash(phone: String, pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest("$phone|pin:$pin|farmdiary-v2".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
