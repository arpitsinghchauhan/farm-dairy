package com.farmdiary.app.domain

import java.security.MessageDigest
import java.time.LocalDate

object Credentials {
    fun isValidPhone(phone: String) = phone.length == 10 && phone.all { it.isDigit() }

    fun isValidDob(dob: LocalDate?, today: LocalDate = LocalDate.now()): Boolean =
        dob != null && dob.isBefore(today) && dob.year >= 1900

    /** Same phone + same date of birth always give the same hash, on any device. */
    fun hash(phone: String, dob: LocalDate): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest("$phone|$dob|farmdiary-v1".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
