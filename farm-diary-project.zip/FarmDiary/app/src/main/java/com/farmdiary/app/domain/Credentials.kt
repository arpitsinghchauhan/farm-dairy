package com.farmdiary.app.domain

import java.security.MessageDigest

object Credentials {
    const val PIN_MIN = 4
    const val PIN_MAX = 6

    fun isValidPhone(phone: String) = phone.length == 10 && phone.all { it.isDigit() }

    /** A PIN is 4 to 6 digits. */
    fun isValidPin(pin: String) = pin.length in PIN_MIN..PIN_MAX && pin.all { it.isDigit() }

    /** Same phone + same PIN always give the same hash, on any device. */
    fun hash(phone: String, pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest("$phone|pin:$pin|farmdiary-v2".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
