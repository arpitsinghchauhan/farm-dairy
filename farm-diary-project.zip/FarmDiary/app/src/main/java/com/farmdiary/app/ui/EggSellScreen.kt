package com.farmdiary.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.MAX_SALE_LINES

@Composable
fun EggSellScreen(vm: FarmViewModel, onBack: () -> Unit) {
    val sale by vm.sale.collectAsState()
    val errors by vm.saleErrors.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val farmName by vm.farmName.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var askDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }
    OpenPdfEffect(pdfUri) { vm.clearOpenPdf() }

    val leave: () -> Unit = {
        if (sale.dirty) {
            askDiscard = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = leave)

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved changes in this egg sale.") },
            confirmButton = {
                TextButton(onClick = {
                    askDiscard = false
                    vm.reload()
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = { TextButton(onClick = { askDiscard = false }) { Text("Keep editing") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Egg Sell", leave) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (farmName.isNotBlank()) {
                Text(farmName, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(sale.date.format(displayDateFormat), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
                if (sale.isNil) {
                    Text(
                        "NIL",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextHi,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(PanelHi)
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }
            Text(
                "What you save here is added to the Daily Report of this date automatically. " +
                    "To change the date, go back and tap the date on the Home screen.",
                fontSize = 16.sp,
                color = TextLo
            )

            SectionCard("Egg Sale", "🥚") {
                sale.sales.forEachIndexed { i, line ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = line.name,
                                onValueChange = { v -> vm.editSale(line.key) { it.copy(name = v) } },
                                label = { Text("Egg size (e.g. Large)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            if (sale.sales.size > 1) {
                                IconButton(onClick = { vm.removeSale(line.key) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove size ${i + 1}")
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumField(
                                "Trays sold", line.trays,
                                { v -> vm.editSale(line.key) { it.copy(trays = v) } },
                                Modifier.weight(1f)
                            )
                            NumField(
                                "Price per tray", line.rate,
                                { v -> vm.editSale(line.key) { it.copy(rate = v) } },
                                Modifier.weight(1f)
                            )
                        }
                        CalcRow("Amount", Calc.money(line.amount))
                    }
                }
                if (sale.sales.size < MAX_SALE_LINES) {
                    OutlinedButton(onClick = { vm.addSale() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add another egg size")
                    }
                }
                CalcRow("Total sale (${Calc.fmt(sale.totalTraysSold)} trays)", Calc.money(sale.totalIncome), bold = true)
            }

            SectionCard("Money Received", "💵") {
                NumField("Cash received", sale.cashReceived, { vm.editCash(it) }, Modifier.fillMaxWidth())
                NumField("Online received", sale.onlineReceived, { vm.editOnline(it) }, Modifier.fillMaxWidth())
                CalcRow(
                    "Balance to receive", Calc.money(sale.balance),
                    bold = true, error = sale.balance < -1e-9
                )
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") {
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }

            GradientButton(
                text = "💾  Save Egg Sale",
                onClick = { vm.saveSale() },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(
                onClick = { vm.markNil() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("No egg sold today (NIL)", fontSize = 20.sp) }
            GradientButton(
                text = "📄  Download PDF",
                onClick = { vm.downloadSalePdf() },
                enabled = !sale.dirty,
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
            if (sale.dirty) {
                Text("Press Save Egg Sale first, then you can download the PDF.", fontSize = 16.sp, color = TextLo)
            }
        }
    }
}
