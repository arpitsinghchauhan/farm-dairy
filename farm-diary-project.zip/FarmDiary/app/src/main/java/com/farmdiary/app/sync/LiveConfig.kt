package com.farmdiary.app.sync

import java.security.SecureRandom

/**
 * What a phone needs to join the live sync of a farm: the Firebase project, its web API key and the farm code.
 * The three are written as one text so it can be sent to the other phones: LD1|project|key|code.
 */
data class LiveConfig(val projectId: String, val apiKey: String, val farmCode: String) {
    fun encode(): String = "LD1|$projectId|$apiKey|$farmCode"

    companion object {
        private val PROJECT = Regex("[a-z0-9][a-z0-9-]{3,60}")
        private val KEY = Regex("[A-Za-z0-9_-]{20,80}")
        private val CODE = Regex("[A-Za-z0-9]{16,64}")

        fun newCode(random: SecureRandom = SecureRandom()): String {
            val alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            return (1..24).map { alphabet[random.nextInt(alphabet.length)] }.joinToString("")
        }

        /** The checked config, or null if the text is not a valid sync code. */
        fun parse(text: String): LiveConfig? {
            val p = text.trim().split("|")
            if (p.size != 4 || p[0] != "LD1") return null
            val c = LiveConfig(p[1].trim(), p[2].trim(), p[3].trim())
            return if (valid(c)) c else null
        }

        fun valid(c: LiveConfig): Boolean = PROJECT.matches(c.projectId) && KEY.matches(c.apiKey) && CODE.matches(c.farmCode)

        fun problems(projectId: String, apiKey: String): List<String> {
            val out = mutableListOf<String>()
            if (!PROJECT.matches(projectId.trim())) out += "The Project ID is not right. It has small letters, digits and dashes."
            if (!KEY.matches(apiKey.trim())) out += "The Web API key is not right. Copy it again from Project settings."
            return out
        }
    }
}
