package com.farmdiary.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AccountEntity
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.domain.Credentials
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** NeedPin: an older login (made with a date of birth) must set its PIN once. */
enum class AuthState { Loading, NeedSetup, NeedPin, LoggedOut, Forgot, LoggedIn }

class AuthViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val prefs = app.getSharedPreferences("session", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(AuthState.Loading)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        prefs.edit().putBoolean(KEY_IN, false).apply()
        viewModelScope.launch {
            _state.value = when {
                dao.getAccount() == null -> AuthState.NeedSetup
                // Every time the app is opened again it starts at the login page.
                !prefs.getBoolean(KEY_PIN, false) -> AuthState.NeedPin
                else -> AuthState.LoggedOut
            }
        }
    }

    fun clearError() { _error.value = null }

    /**
     * Creates the login (mobile number + a PIN you set), sets the PIN for an older login once, or checks the PIN on later logins.
     * [confirmPin] is only used when a PIN is being set.
     */
    fun submit(phone: String, pin: String, confirmPin: String, question: String = "", answer: String = "") {
        if (!Credentials.isValidPhone(phone)) {
            _error.value = "Please enter a 10 digit mobile number."
            return
        }
        if (!Credentials.isValidPin(pin)) {
            _error.value = "Please enter a PIN of 4 to 6 digits."
            return
        }
        val setting = _state.value == AuthState.NeedSetup || _state.value == AuthState.NeedPin
        if (setting && pin != confirmPin) {
            _error.value = "The two PINs are not the same."
            return
        }
        val creating = _state.value == AuthState.NeedSetup
        if (creating && (question.isBlank() || !Credentials.isValidAnswer(answer))) {
            _error.value = "Please choose a security question and write its answer (used if you forget the PIN)."
            return
        }
        val hash = Credentials.hash(phone, pin)
        viewModelScope.launch {
            try {
                val account = dao.getAccount()
                if (account == null) {
                    dao.upsertAccount(AccountEntity(1, phone, hash, System.currentTimeMillis(), question, Credentials.answerHash(phone, answer)))
                    prefs.edit().putBoolean(KEY_PIN, true).apply()
                } else if (_state.value == AuthState.NeedPin) {
                    // One-time change of an older login: the mobile number must be the same one.
                    if (account.phone != phone) {
                        _error.value = "This is not the mobile number of this farm login."
                        return@launch
                    }
                    dao.upsertAccount(account.copy(credentialHash = hash))
                    prefs.edit().putBoolean(KEY_PIN, true).apply()
                } else if (account.phone != phone || account.credentialHash != hash) {
                    _error.value = "Mobile number or PIN is wrong. Please try again."
                    return@launch
                }
                prefs.edit().putBoolean(KEY_IN, true).putString(KEY_PHONE, phone).apply()
                _error.value = null
                _state.value = AuthState.LoggedIn
            } catch (e: Exception) {
                AppLog.e("login failed", e)
                _error.value = "Something went wrong. Please try again."
            }
        }
    }

    // ---- forgot PIN, change PIN, security question ----------------------------

    private val _question = MutableStateFlow("")
    /** The security question of this login (empty if none was set yet). */
    val question: StateFlow<String> = _question.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()
    fun clearNotice() { _notice.value = null }

    private val _hasQuestion = MutableStateFlow(true)
    /** False while the login has no security question (the Home page then asks for one). */
    val hasQuestion: StateFlow<Boolean> = _hasQuestion.asStateFlow()

    fun refreshQuestion() {
        viewModelScope.launch {
            val a = dao.getAccount()
            _question.value = a?.securityQuestion ?: ""
            _hasQuestion.value = a == null || a.securityQuestion.isNotBlank()
        }
    }

    fun startForgot() {
        _error.value = null
        _notice.value = null
        viewModelScope.launch {
            _question.value = dao.getAccount()?.securityQuestion ?: ""
            _state.value = AuthState.Forgot
        }
    }

    fun cancelForgot() { _error.value = null; _state.value = AuthState.LoggedOut }

    /** Forgot PIN: the right mobile number and answer to the security question let the user set a new PIN. */
    fun resetPin(phone: String, answer: String, newPin: String, confirmPin: String) {
        if (!Credentials.isValidPhone(phone)) { _error.value = "Please enter a 10 digit mobile number."; return }
        if (!Credentials.isValidAnswer(answer)) { _error.value = "Please write the answer."; return }
        if (!Credentials.isValidPin(newPin)) { _error.value = "Please enter a PIN of 4 to 6 digits."; return }
        if (newPin != confirmPin) { _error.value = "The two PINs are not the same."; return }
        viewModelScope.launch {
            try {
                val a = dao.getAccount()
                when {
                    a == null || a.phone != phone || a.securityQuestion.isBlank() || a.answerHash != Credentials.answerHash(phone, answer) ->
                        _error.value = if (a != null && a.securityQuestion.isBlank())
                            "No security question was set on this login, so the PIN cannot be reset here."
                        else "The mobile number or the answer is wrong."
                    else -> {
                        dao.upsertAccount(a.copy(credentialHash = Credentials.hash(phone, newPin)))
                        prefs.edit().putBoolean(KEY_PIN, true).apply()
                        _error.value = null
                        _notice.value = "PIN changed. Please login with the new PIN."
                        _state.value = AuthState.LoggedOut
                    }
                }
            } catch (e: Exception) {
                AppLog.e("reset PIN failed", e)
                _error.value = "Something went wrong. Please try again."
            }
        }
    }

    /** Change PIN from the Home gear menu. [done] gets null when it worked, or the problem. */
    fun changePin(current: String, newPin: String, confirmPin: String, done: (String?) -> Unit) {
        if (!Credentials.isValidPin(newPin)) { done("Please enter a new PIN of 4 to 6 digits."); return }
        if (newPin != confirmPin) { done("The two new PINs are not the same."); return }
        viewModelScope.launch {
            try {
                val a = dao.getAccount() ?: run { done("No login found."); return@launch }
                if (a.credentialHash != Credentials.hash(a.phone, current)) { done("The current PIN is wrong."); return@launch }
                dao.upsertAccount(a.copy(credentialHash = Credentials.hash(a.phone, newPin)))
                AppLog.i("PIN changed")
                done(null)
            } catch (e: Exception) {
                AppLog.e("change PIN failed", e)
                done("Something went wrong. Please try again.")
            }
        }
    }

    /** Sets or changes the security question (asks for the PIN). */
    fun setQuestion(pin: String, question: String, answer: String, done: (String?) -> Unit) {
        if (question.isBlank() || !Credentials.isValidAnswer(answer)) { done("Please choose a question and write its answer."); return }
        viewModelScope.launch {
            try {
                val a = dao.getAccount() ?: run { done("No login found."); return@launch }
                if (a.credentialHash != Credentials.hash(a.phone, pin)) { done("The PIN is wrong."); return@launch }
                dao.upsertAccount(a.copy(securityQuestion = question, answerHash = Credentials.answerHash(a.phone, answer)))
                _question.value = question
                _hasQuestion.value = true
                AppLog.i("Security question set")
                done(null)
            } catch (e: Exception) {
                AppLog.e("set question failed", e)
                done("Something went wrong. Please try again.")
            }
        }
    }

    /** The mobile number used at the last login, so it does not have to be typed again. */
    fun savedPhone(): String = prefs.getString(KEY_PHONE, "") ?: ""

    fun logout() {
        prefs.edit().putBoolean(KEY_IN, false).apply()
        _error.value = null
        _state.value = if (prefs.getBoolean(KEY_PIN, false)) AuthState.LoggedOut else AuthState.NeedPin
    }

    private companion object {
        const val KEY_IN = "logged_in"
        const val KEY_PIN = "pin_set"
        const val KEY_PHONE = "last_phone"
    }
}
