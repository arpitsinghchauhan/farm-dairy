package com.farmdiary.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AccountEntity
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.domain.Credentials
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** NeedPin: an older login (made with a date of birth) must set its PIN once. */
enum class AuthState { Loading, NeedSetup, NeedPin, LoggedOut, LoggedIn }

class AuthViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val prefs = app.getSharedPreferences("session", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(AuthState.Loading)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        prefs.edit().putBoolean(KEY_IN, false).apply()
        viewModelScope.launch {
            _state.value = when {
                dao.getAccount() == null -> AuthState.NeedSetup
                // Every time the app is opened again it starts at the login page.
                !prefs.getBoolean(KEY_PIN, false) -> AuthState.NeedPin
                else -> AuthState.LoggedOut
            }
        }
    }

    fun clearError() { _error.value = null }

    /**
     * Creates the login (mobile number + a PIN you set), sets the PIN for an older login once, or checks the PIN on later logins.
     * [confirmPin] is only used when a PIN is being set.
     */
    fun submit(phone: String, pin: String, confirmPin: String) {
        if (!Credentials.isValidPhone(phone)) {
            _error.value = "Please enter a 10 digit mobile number."
            return
        }
        if (!Credentials.isValidPin(pin)) {
            _error.value = "Please enter a PIN of 4 to 6 digits."
            return
        }
        val setting = _state.value == AuthState.NeedSetup || _state.value == AuthState.NeedPin
        if (setting && pin != confirmPin) {
            _error.value = "The two PINs are not the same."
            return
        }
        val hash = Credentials.hash(phone, pin)
        viewModelScope.launch {
            try {
                val account = dao.getAccount()
                if (account == null) {
                    dao.upsertAccount(AccountEntity(1, phone, hash, System.currentTimeMillis()))
                    prefs.edit().putBoolean(KEY_PIN, true).apply()
                } else if (_state.value == AuthState.NeedPin) {
                    // One-time change of an older login: the mobile number must be the same one.
                    if (account.phone != phone) {
                        _error.value = "This is not the mobile number of this farm login."
                        return@launch
                    }
                    dao.upsertAccount(account.copy(credentialHash = hash))
                    prefs.edit().putBoolean(KEY_PIN, true).apply()
                } else if (account.phone != phone || account.credentialHash != hash) {
                    _error.value = "Mobile number or PIN is wrong. Please try again."
                    return@launch
                }
                prefs.edit().putBoolean(KEY_IN, true).apply()
                _error.value = null
                _state.value = AuthState.LoggedIn
            } catch (e: Exception) {
                AppLog.e("login failed", e)
                _error.value = "Something went wrong. Please try again."
            }
        }
    }

    fun logout() {
        prefs.edit().putBoolean(KEY_IN, false).apply()
        _error.value = null
        _state.value = if (prefs.getBoolean(KEY_PIN, false)) AuthState.LoggedOut else AuthState.NeedPin
    }

    private companion object {
        const val KEY_IN = "logged_in"
        const val KEY_PIN = "pin_set"
    }
}
