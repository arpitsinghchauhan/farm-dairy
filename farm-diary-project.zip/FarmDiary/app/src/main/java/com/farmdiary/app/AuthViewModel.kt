package com.farmdiary.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AccountEntity
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.domain.Credentials
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class AuthState { Loading, NeedSetup, LoggedOut, LoggedIn }

class AuthViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val prefs = app.getSharedPreferences("session", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(AuthState.Loading)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        viewModelScope.launch {
            _state.value = when {
                dao.getAccount() == null -> AuthState.NeedSetup
                prefs.getBoolean(KEY_IN, false) -> AuthState.LoggedIn
                else -> AuthState.LoggedOut
            }
        }
    }

    fun clearError() { _error.value = null }

    /** Creates the login the first time, or checks it on later logins. */
    fun submit(phone: String, dob: LocalDate?) {
        if (!Credentials.isValidPhone(phone)) {
            _error.value = "Please enter a 10 digit mobile number."
            return
        }
        if (!Credentials.isValidDob(dob)) {
            _error.value = "Please choose your date of birth."
            return
        }
        val hash = Credentials.hash(phone, dob!!)
        viewModelScope.launch {
            try {
                val account = dao.getAccount()
                if (account == null) {
                    dao.upsertAccount(AccountEntity(1, phone, hash, System.currentTimeMillis()))
                } else if (account.phone != phone || account.credentialHash != hash) {
                    _error.value = "Mobile number or date of birth is wrong. Please try again."
                    return@launch
                }
                prefs.edit().putBoolean(KEY_IN, true).apply()
                _error.value = null
                _state.value = AuthState.LoggedIn
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "login failed", e)
                _error.value = "Something went wrong. Please try again."
            }
        }
    }

    fun logout() {
        prefs.edit().putBoolean(KEY_IN, false).apply()
        _error.value = null
        _state.value = AuthState.LoggedOut
    }

    private companion object { const val KEY_IN = "logged_in" }
}
