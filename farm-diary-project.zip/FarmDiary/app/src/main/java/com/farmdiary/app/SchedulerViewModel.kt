package com.farmdiary.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.data.ScheduleItemEntity
import com.farmdiary.app.domain.MAX_SCHEDULE_ITEMS
import com.farmdiary.app.domain.ScheduleForm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SchedulerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** What is saved (used by the Home screen to show the next task). */
    val saved: StateFlow<List<ScheduleItemEntity>> = repo.observeSchedule()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _items = MutableStateFlow<List<ScheduleForm>>(emptyList())
    val items: StateFlow<List<ScheduleForm>> = _items.asStateFlow()

    private val _dirty = MutableStateFlow(false)
    val dirty: StateFlow<Boolean> = _dirty.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private var keySeed = 1L

    init {
        viewModelScope.launch {
            seedDefaultsOnce()
            reload()
        }
    }

    fun clearMessage() { _message.value = null }
    fun say(text: String) { _message.value = text }

    /** The first time only: put the usual farm tasks in the list. They can be changed or deleted. */
    private suspend fun seedDefaultsOnce() {
        if (prefs.getBoolean(KEY_SEEDED, false)) return
        if (repo.getSchedule().isEmpty()) {
            repo.replaceSchedule(
                listOf(
                    ScheduleItemEntity(title = "Feed time", details = "Give feed to all farms", hour = 7, minute = 0, reminderOn = false),
                    ScheduleItemEntity(title = "Water intake", details = "Fill the water tanks (1 tank = 1000 L)", hour = 9, minute = 0, reminderOn = false),
                    ScheduleItemEntity(title = "Balance feed time", details = "Give the remaining feed", hour = 15, minute = 0, reminderOn = false)
                )
            )
        }
        prefs.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    fun reload() {
        viewModelScope.launch {
            _items.value = repo.getSchedule().map {
                ScheduleForm(keySeed++, it.id, it.title, it.details, it.hour, it.minute, it.reminderOn)
            }
            _dirty.value = false
        }
    }

    private fun change(transform: (List<ScheduleForm>) -> List<ScheduleForm>) {
        _items.update(transform)
        _dirty.value = true
    }

    fun add() {
        if (_items.value.size >= MAX_SCHEDULE_ITEMS) {
            _message.value = "You can add up to $MAX_SCHEDULE_ITEMS tasks."
            return
        }
        change { it + ScheduleForm(keySeed++, title = "", hour = 12, minute = 0) }
    }

    fun edit(key: Long, transform: (ScheduleForm) -> ScheduleForm) =
        change { list -> list.map { if (it.key == key) transform(it) else it } }

    fun remove(key: Long) = change { list -> list.filterNot { it.key == key } }

    fun save() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            try {
                val entities = _items.value
                    .sortedWith(compareBy({ it.hour }, { it.minute }))
                    .map {
                        ScheduleItemEntity(
                            title = it.title.trim().ifEmpty { "Farm task" },
                            details = it.details.trim(),
                            hour = it.hour,
                            minute = it.minute,
                            reminderOn = it.reminderOn
                        )
                    }
                // Old alarms use the old row ids, so remove them before the rows are replaced.
                repo.getSchedule().forEach { Reminders.cancel(ctx, it.id) }
                val ids = repo.replaceSchedule(entities)
                Reminders.ensureChannel(ctx)
                entities.forEachIndexed { i, e ->
                    if (e.reminderOn) Reminders.schedule(ctx, ids[i], e.title, e.details, e.hour, e.minute)
                }
                reload()
                _message.value = "Schedule saved."
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "schedule save failed", e)
                _message.value = "Unable to save the schedule. Please try again."
            }
        }
    }

    private companion object { const val KEY_SEEDED = "schedule_seeded" }
}
