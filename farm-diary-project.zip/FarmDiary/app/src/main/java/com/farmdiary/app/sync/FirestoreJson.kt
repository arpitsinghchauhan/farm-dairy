package com.farmdiary.app.sync

import org.json.JSONArray
import org.json.JSONObject

/** One change piece found in the shared database. [ts] is the time the server stored it (ISO text, for example 2026-10-28T10:15:30.123456Z). */
data class RemoteChange(val name: String, val deviceId: String, val ts: String, val payload: String)

/** The JSON that goes to and comes from the Firestore REST service. No network here, so it can be tested. */
object FirestoreJson {
    fun docsRoot(projectId: String) = "projects/$projectId/databases/(default)/documents"

    fun changesPath(farmCode: String) = "farms/$farmCode/changes"

    /** A commit that stores one piece. The server writes the time (REQUEST_TIME), so phone clocks cannot disturb the order. */
    fun commitBody(projectId: String, farmCode: String, docId: String, deviceId: String, payload: String): String =
        commitDocBody(
            projectId, changesPath(farmCode) + "/" + docId,
            mapOf("deviceId" to deviceId, "payload" to payload), listOf("ts"), mustNotExist = true
        )

    /** A commit that writes one document of text fields. [serverTimes] are fields the server fills with its own time. */
    fun commitDocBody(
        projectId: String, path: String, strings: Map<String, String>,
        serverTimes: List<String> = emptyList(), mustNotExist: Boolean = false
    ): String {
        val fields = JSONObject()
        strings.forEach { (k, v) -> fields.put(k, JSONObject().put("stringValue", v)) }
        val write = JSONObject().put("update", JSONObject().put("name", docsRoot(projectId) + "/" + path).put("fields", fields))
        if (serverTimes.isNotEmpty()) {
            write.put(
                "updateTransforms",
                JSONArray(serverTimes.map { JSONObject().put("fieldPath", it).put("setToServerValue", "REQUEST_TIME") })
            )
        }
        if (mustNotExist) write.put("currentDocument", JSONObject().put("exists", false))
        return JSONObject().put("writes", JSONArray().put(write)).toString()
    }

    private fun stringFields(doc: JSONObject): Map<String, String> {
        val f = doc.optJSONObject("fields") ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        f.keys().forEach { k -> f.optJSONObject(k)?.let { if (it.has("stringValue")) out[k] = it.optString("stringValue", "") } }
        return out
    }

    /** The text fields of one document (the answer of a get). */
    fun parseDocStrings(text: String): Map<String, String> = stringFields(JSONObject(text))

    /** The documents of a list answer: the last part of each name (the document id) and its text fields. */
    fun parseDocList(text: String): List<Pair<String, Map<String, String>>> {
        val arr = JSONObject(text).optJSONArray("documents") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val d = arr.optJSONObject(i) ?: return@mapNotNull null
            d.optString("name", "").substringAfterLast('/') to stringFields(d)
        }
    }

    fun authBody(email: String, password: String): String =
        JSONObject().put("email", email.trim()).put("password", password).put("returnSecureToken", true).toString()

    fun resetBody(email: String): String =
        JSONObject().put("requestType", "PASSWORD_RESET").put("email", email.trim()).toString()

    /** The user id in a sign-in answer ("localId") or a refresh answer ("user_id"). */
    fun parseUid(text: String): String {
        val o = JSONObject(text)
        return o.optString("localId", o.optString("user_id", ""))
    }

    /** Pieces stored at or after [sinceIso], oldest first. */
    fun queryBody(sinceIso: String, limit: Int): String {
        val query = JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", "changes")))
            .put(
                "where",
                JSONObject().put(
                    "fieldFilter",
                    JSONObject()
                        .put("field", JSONObject().put("fieldPath", "ts"))
                        .put("op", "GREATER_THAN_OR_EQUAL")
                        .put("value", JSONObject().put("timestampValue", sinceIso))
                )
            )
            .put("orderBy", JSONArray().put(JSONObject().put("field", JSONObject().put("fieldPath", "ts")).put("direction", "ASCENDING")))
            .put("limit", limit)
        return JSONObject().put("structuredQuery", query).toString()
    }

    /** The pieces in a runQuery answer. Rows without a document (an empty answer) are skipped. */
    fun parseQuery(text: String): List<RemoteChange> {
        val arr = JSONArray(text)
        val out = ArrayList<RemoteChange>()
        for (i in 0 until arr.length()) {
            val doc = arr.optJSONObject(i)?.optJSONObject("document") ?: continue
            val f = doc.optJSONObject("fields") ?: continue
            val payload = f.optJSONObject("payload")?.optString("stringValue", "") ?: ""
            val ts = f.optJSONObject("ts")?.optString("timestampValue", "") ?: ""
            if (payload.isEmpty() || ts.isEmpty()) continue
            out += RemoteChange(
                name = doc.optString("name", ""),
                deviceId = f.optJSONObject("deviceId")?.optString("stringValue", "") ?: "",
                ts = ts, payload = payload
            )
        }
        return out
    }

    fun signInBody(): String = JSONObject().put("returnSecureToken", true).toString()

    fun refreshBody(refreshToken: String): String =
        "grant_type=refresh_token&refresh_token=" + java.net.URLEncoder.encode(refreshToken, "UTF-8")

    /** idToken, refreshToken and the seconds it lasts, from a sign-in answer ("idToken") or a refresh answer ("id_token"). */
    fun parseToken(text: String): Triple<String, String, Long>? {
        val o = JSONObject(text)
        val id = o.optString("idToken", o.optString("id_token", ""))
        val refresh = o.optString("refreshToken", o.optString("refresh_token", ""))
        val secs = o.optString("expiresIn", o.optString("expires_in", "3600")).toLongOrNull() ?: 3600L
        return if (id.isEmpty() || refresh.isEmpty()) null else Triple(id, refresh, secs)
    }

    /** The message Google sends back when a call fails, for the screen and the log. */
    fun errorText(text: String): String =
        try {
            JSONObject(text).optJSONObject("error")?.optString("message", "") ?: ""
        } catch (e: Exception) {
            ""
        }
}
