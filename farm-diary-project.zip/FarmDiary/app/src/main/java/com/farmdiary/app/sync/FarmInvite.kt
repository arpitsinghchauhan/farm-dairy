package com.farmdiary.app.sync

import java.security.SecureRandom

/**
 * What a staff member needs to join a farm: the farm's id and a secret that the owner made for the invite.
 * It is written as one text: LDF-farmid-secret.
 */
data class FarmInvite(val farmId: String, val secret: String) {
    fun encode(): String = "LDF-$farmId-$secret"

    companion object {
        private val FORMAT = Regex("LDF-([a-z0-9]{10,24})-([A-Za-z0-9]{6,16})")

        fun newFarmId(random: SecureRandom = SecureRandom()): String {
            val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
            return (1..14).map { alphabet[random.nextInt(alphabet.length)] }.joinToString("")
        }

        fun newSecret(random: SecureRandom = SecureRandom()): String {
            val alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
            return (1..8).map { alphabet[random.nextInt(alphabet.length)] }.joinToString("")
        }

        fun parse(text: String): FarmInvite? {
            val m = FORMAT.matchEntire(text.trim()) ?: return null
            return FarmInvite(m.groupValues[1], m.groupValues[2])
        }
    }
}

object AccountRules {
    fun validate(email: String, password: String): List<String> {
        val out = mutableListOf<String>()
        val e = email.trim()
        if (!Regex("[^@\\s]+@[^@\\s]+\\.[^@\\s]+").matches(e)) out += "Please write a valid email address."
        if (password.length < 6) out += "The password needs at least 6 characters."
        return out
    }

    fun validFarmName(name: String): Boolean = name.trim().length in 2..40
}
