package com.farmdiary.app

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.domain.FileNames
import com.farmdiary.app.sync.MergeResult
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import com.farmdiary.app.sync.SyncFormatException
import com.farmdiary.app.sync.SyncSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

/** Share this phone's data as a file, and merge a file received from another phone. */
class ShareViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _shareUri = MutableStateFlow<Uri?>(null)
    /** Set when the file is ready; the screen opens the share sheet and then calls [shareHandled]. */
    val shareUri: StateFlow<Uri?> = _shareUri.asStateFlow()

    private val _pending = MutableStateFlow<SyncData?>(null)
    val pending: StateFlow<SyncData?> = _pending.asStateFlow()

    private val _pendingText = MutableStateFlow("")
    val pendingText: StateFlow<String> = _pendingText.asStateFlow()

    private val _result = MutableStateFlow<List<String>?>(null)
    val result: StateFlow<List<String>?> = _result.asStateFlow()

    /** Set when an import brought in a farm name for a phone that had none. */
    var onFarmNameImported: ((String) -> Unit)? = null

    fun clearMessage() { _message.value = null }
    fun shareHandled() { _shareUri.value = null }
    fun cancelImport() { _pending.value = null }
    fun clearResult() { _result.value = null }

    private fun farmName() = prefs.getString("farm_name", "") ?: ""

    private suspend fun buildJson(): String {
        val data = repo.exportAll(farmName(), System.currentTimeMillis())
        return SyncCodec.toJson(data)
    }

    private fun fileName() = FileNames.named(farmName(), LocalDate.now(), "Data", "json")

    fun prepareShare() {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val dir = File(getApplication<Application>().cacheDir, "shared").apply { mkdirs() }
                    dir.listFiles()?.forEach { it.delete() }
                    val file = File(dir, fileName())
                    file.writeText(buildJson(), Charsets.UTF_8)
                    FileProvider.getUriForFile(
                        getApplication(), "${getApplication<Application>().packageName}.fileprovider", file
                    )
                }
                _shareUri.value = uri
            } catch (e: Exception) {
                _message.value = "Could not prepare the file. Please try again."
            } finally {
                _busy.value = false
            }
        }
    }

    fun saveCopy() {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                val name = fileName()
                withContext(Dispatchers.IO) {
                    val json = buildJson()
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "application/json")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val resolver = getApplication<Application>().contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("no uri")
                    resolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("no stream")
                }
                _message.value = "Saved in your Downloads folder as $name"
            } catch (e: Exception) {
                _message.value = "Could not save the file. Please try again."
            } finally {
                _busy.value = false
            }
        }
    }

    fun readFile(uri: Uri) {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val stream = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("cannot open")
                    stream.use { readBounded(it) }
                }
                val data = SyncCodec.fromJson(text)
                _pendingText.value = SyncSummary.preview(data)
                _pending.value = data
            } catch (e: SyncFormatException) {
                _message.value = e.message ?: "This is not a Farm Diary data file."
            } catch (e: TooBig) {
                _message.value = "This file is too big to be a Farm Diary data file."
            } catch (e: Exception) {
                _message.value = "Could not read this file. Please choose a Farm Diary data file."
            } finally {
                _busy.value = false
            }
        }
    }

    private class TooBig : Exception()

    private fun readBounded(input: java.io.InputStream): String {
        val limit = 30 * 1024 * 1024
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > limit) throw TooBig()
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }

    fun confirmImport() {
        val data = _pending.value ?: return
        if (_busy.value) return
        _busy.value = true
        _pending.value = null
        viewModelScope.launch {
            try {
                val r: MergeResult = repo.merge(data)
                if (farmName().isBlank() && data.farmName.isNotBlank()) {
                    prefs.edit().putString("farm_name", data.farmName.trim().take(40)).apply()
                    onFarmNameImported?.invoke(data.farmName.trim().take(40))
                }
                _result.value = SyncSummary.describe(r)
            } catch (e: Exception) {
                _message.value = "Import failed and nothing was changed. Please try again."
            } finally {
                _busy.value = false
            }
        }
    }
}
