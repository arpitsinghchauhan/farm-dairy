package com.farmdiary.app

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.domain.FileNames
import com.farmdiary.app.sync.MergeResult
import com.farmdiary.app.sync.SyncCodec
import com.farmdiary.app.sync.SyncData
import com.farmdiary.app.sync.SyncFormatException
import com.farmdiary.app.sync.SyncSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** What happened to the file the user picked. Shown on the Share Data screen until the user closes it. */
sealed interface ImportStatus {
    data object Idle : ImportStatus
    data class Reading(val name: String) : ImportStatus
    /** The file was read and is valid. Nothing is added until the user confirms. */
    data class Ready(val name: String, val sizeText: String, val summary: String) : ImportStatus
    data class Failed(val name: String, val reason: String) : ImportStatus
    data class Done(val name: String, val lines: List<String>) : ImportStatus
}

/** Share this phone's data as a file, and merge a file received from another phone. */
class ShareViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val whenFmt = DateTimeFormatter.ofPattern("dd MMM yyyy, h:mm a", Locale.ENGLISH)

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _shareUri = MutableStateFlow<Uri?>(null)
    /** Set when the file is ready; the screen opens the share sheet and then calls [shareHandled]. */
    val shareUri: StateFlow<Uri?> = _shareUri.asStateFlow()

    private val _status = MutableStateFlow<ImportStatus>(ImportStatus.Idle)
    val status: StateFlow<ImportStatus> = _status.asStateFlow()

    private var pending: SyncData? = null

    private val _lastImport = MutableStateFlow(prefs.getString("last_import", "") ?: "")
    /** For example "20 Oct 2026, 1:30 AM from Farm_Data_19-Oct-2026.json", or empty if nothing was added yet. */
    val lastImport: StateFlow<String> = _lastImport.asStateFlow()

    private val _lastExport = MutableStateFlow(prefs.getString("last_export", "") ?: "")
    val lastExport: StateFlow<String> = _lastExport.asStateFlow()

    /** Set when an import brought in a farm name for a phone that had none. */
    var onFarmNameImported: ((String) -> Unit)? = null

    fun clearMessage() { _message.value = null }
    fun shareHandled() { _shareUri.value = null }
    fun closeStatus() { pending = null; _status.value = ImportStatus.Idle }

    private fun farmName() = prefs.getString("farm_name", "") ?: ""
    private fun nowText() = LocalDateTime.now().format(whenFmt)

    private suspend fun buildJson(): String {
        val data = repo.exportAll(farmName(), System.currentTimeMillis(), prefs.getLong("schedule_updated_at", 0L), prefs.getInt("farm_count", 2))
        return SyncCodec.toJson(data)
    }

    private fun fileName() = FileNames.named(farmName(), LocalDate.now(), "Data", "json")

    private fun remember(key: String, text: String) {
        prefs.edit().putString(key, text).apply()
    }

    fun prepareShare() {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                val name = fileName()
                val uri = withContext(Dispatchers.IO) {
                    val dir = File(getApplication<Application>().cacheDir, "shared").apply { mkdirs() }
                    dir.listFiles()?.forEach { it.delete() }
                    val file = File(dir, name)
                    file.writeText(buildJson(), Charsets.UTF_8)
                    FileProvider.getUriForFile(
                        getApplication(), "${getApplication<Application>().packageName}.fileprovider", file
                    )
                }
                _shareUri.value = uri
                AppLog.i("Data file prepared for sharing")
                _lastExport.value = "${nowText()} (shared as $name)"
                remember("last_export", _lastExport.value)
            } catch (e: Exception) {
                _message.value = "Could not prepare the file: ${e.javaClass.simpleName}: ${e.message}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun saveCopy() {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                val name = fileName()
                withContext(Dispatchers.IO) {
                    val json = buildJson()
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "application/json")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val resolver = getApplication<Application>().contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("The phone would not create the file")
                    resolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("The phone would not open the file")
                }
                AppLog.i("Data file saved in Downloads")
                _lastExport.value = "${nowText()} (saved in Downloads as $name)"
                remember("last_export", _lastExport.value)
                _message.value = "Saved in your Downloads folder as $name"
            } catch (e: Exception) {
                _message.value = "Could not save the file: ${e.javaClass.simpleName}: ${e.message}"
            } finally {
                _busy.value = false
            }
        }
    }

    /** Saves the log file in Downloads. */
    fun saveLog() {
        viewModelScope.launch {
            val version = try {
                getApplication<Application>().packageManager.getPackageInfo(getApplication<Application>().packageName, 0).versionName ?: ""
            } catch (e: Exception) { "" }
            val name = withContext(Dispatchers.IO) { AppLog.saveToDownloads(getApplication(), version) }
            _message.value = if (name == null) "Could not save the log file." else "Log saved in your Downloads folder as $name"
        }
    }

    private fun describeFile(uri: Uri): Pair<String, Long> {
        var name = ""
        var size = -1L
        try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0) ?: ""
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
        } catch (e: Exception) {
            // The name is only for display.
        }
        return name.ifEmpty { uri.lastPathSegment ?: "chosen file" } to size
    }

    private fun sizeText(bytes: Long): String = when {
        bytes < 0 -> ""
        bytes < 1024 -> "$bytes bytes"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> String.format(Locale.ENGLISH, "%.1f MB", bytes / 1048576.0)
    }

    /** Called with the file the user picked. The result is shown as a status card, never as a quick pop-up. */
    fun readFile(uri: Uri?) {
        if (uri == null) {
            _status.value = ImportStatus.Failed("", "No file was chosen. Please try again and tap the data file.")
            return
        }
        if (_busy.value) return
        _busy.value = true
        val (name, size) = describeFile(uri)
        _status.value = ImportStatus.Reading(name)
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val stream = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("The phone would not open this file")
                    stream.use { readBounded(it) }
                }
                if (text.isBlank()) throw SyncFormatException("The file is empty.")
                val data = SyncCodec.fromJson(text)
                pending = data
                _status.value = ImportStatus.Ready(name, sizeText(size), SyncSummary.preview(data))
            } catch (e: SyncFormatException) {
                _status.value = ImportStatus.Failed(name, e.message ?: "This is not a Farm Diary data file.")
            } catch (e: TooBig) {
                _status.value = ImportStatus.Failed(name, "This file is too big to be a Farm Diary data file.")
            } catch (e: Exception) {
                AppLog.e("readFile failed", e)
                _status.value = ImportStatus.Failed(name, "Could not read this file. (${e.javaClass.simpleName}: ${e.message})")
            } finally {
                _busy.value = false
            }
        }
    }

    private class TooBig : Exception()

    private fun readBounded(input: java.io.InputStream): String {
        val limit = 30 * 1024 * 1024
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > limit) throw TooBig()
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }

    fun confirmImport() {
        val data = pending ?: return
        val shown = _status.value
        val name = (shown as? ImportStatus.Ready)?.name ?: "data file"
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            try {
                val oldTasks = repo.getSchedule()
                val r: MergeResult = repo.merge(data, prefs.getLong("schedule_updated_at", 0L))
                if (r.scheduleReplaced) {
                    // The schedule came from the file: stop the old alarms and set the new ones.
                    val ctx = getApplication<Application>()
                    prefs.edit().putLong("schedule_updated_at", data.scheduleUpdatedAt).apply()
                    oldTasks.forEach { Reminders.cancel(ctx, it.id) }
                    Reminders.ensureChannel(ctx)
                    repo.getSchedule().filter { it.reminderOn }.forEach {
                        Reminders.schedule(ctx, it.id, it.title, it.details, it.hour, it.minute, it.kind, it.dayOfWeek, it.dayOfMonth)
                    }
                }
                if (farmName().isBlank() && data.farmName.isNotBlank()) {
                    prefs.edit().putString("farm_name", data.farmName.trim().take(40)).apply()
                    onFarmNameImported?.invoke(data.farmName.trim().take(40))
                }
                // The number of farms: take the file's number if it is bigger, so every farm row shows.
                if (data.farmCount > prefs.getInt("farm_count", 2)) {
                    prefs.edit().putInt("farm_count", data.farmCount.coerceIn(1, 5)).apply()
                    onFarmNameImported?.invoke(farmName())
                }
                pending = null
                AppLog.i("Data added from a shared file")
                _status.value = ImportStatus.Done(name, SyncSummary.describe(r))
                _lastImport.value = "${nowText()} from $name"
                remember("last_import", _lastImport.value)
            } catch (e: Exception) {
                AppLog.e("merge failed", e)
                _status.value = ImportStatus.Failed(
                    name, "Adding the data failed and nothing was changed. (${e.javaClass.simpleName}: ${e.message})"
                )
            } finally {
                _busy.value = false
            }
        }
    }
}
