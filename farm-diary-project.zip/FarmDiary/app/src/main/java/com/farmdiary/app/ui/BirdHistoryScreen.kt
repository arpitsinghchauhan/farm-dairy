package com.farmdiary.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.BirdViewModel
import com.farmdiary.app.domain.BirdDaySummary
import com.farmdiary.app.domain.Calc
import java.time.LocalDate

/** Every date with saved farm records, newest first. Tap a day to open and edit it. */
@Composable
fun BirdHistoryScreen(bird: BirdViewModel, onOpen: (LocalDate) -> Unit, onBack: () -> Unit) {
    val history by bird.history.collectAsState()
    val message by bird.message.collectAsState()
    val pdfUri by bird.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var toDelete by remember { mutableStateOf<BirdDaySummary?>(null) }

    OpenPdfEffect(pdfUri) { bird.clearOpenPdf() }
    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            bird.clearMessage()
        }
    }

    toDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this day?") },
            text = { Text("All farm records of ${LocalDate.parse(d.date).format(displayDateFormat)} will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    bird.deleteDay(LocalDate.parse(d.date))
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep it") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Farm Records History", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (history.isEmpty()) {
                Text("No farm records saved yet.", fontSize = 18.sp)
            }
            history.forEach { d ->
                val date = LocalDate.parse(d.date)
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(date) },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(date.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
                        Text(d.farmNames.joinToString(", "), fontSize = 16.sp, color = TextLo)
                        CalcRow("Production", "${Calc.fmt(d.production)} trays")
                        CalcRow("Mortality", "${d.mortality} birds")
                        CalcRow("Feed bags used", "${Calc.fmt(d.feedBags)} bags")
                        if (d.breakage > 0) CalcRow("Breakage", "${d.breakage} eggs")
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { bird.downloadPdf(date) }) { Text("📄 PDF", fontSize = 18.sp) }
                            TextButton(onClick = { toDelete = d }) {
                                Text("Delete", fontSize = 18.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}
