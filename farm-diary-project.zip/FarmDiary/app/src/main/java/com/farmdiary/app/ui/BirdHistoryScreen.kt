package com.farmdiary.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.BirdViewModel
import com.farmdiary.app.domain.BirdDaySummary
import com.farmdiary.app.domain.BirdMonthly
import com.farmdiary.app.domain.Calc
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.compositeOver
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Every date with saved farm records, newest first. Tap a day to open and edit it. */
@Composable
fun BirdHistoryScreen(bird: BirdViewModel, onOpen: (LocalDate) -> Unit, onBack: () -> Unit) {
    val history by bird.history.collectAsState()
    val records by bird.records.collectAsState()
    var month by remember { mutableStateOf(YearMonth.now()) }
    val monthly = remember(records, month) { BirdMonthly.build(records, month) }
    val message by bird.message.collectAsState()
    val pdfUri by bird.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var toDelete by remember { mutableStateOf<BirdDaySummary?>(null) }

    OpenPdfEffect(pdfUri) { bird.clearOpenPdf() }
    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            bird.clearMessage()
        }
    }

    toDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this day?") },
            text = { Text("All farm records of ${LocalDate.parse(d.date).format(displayDateFormat)} will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    bird.deleteDay(LocalDate.parse(d.date))
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep it") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Farm Records History", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AccentCard("Month: ${month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH))}", "📆", MintBrush, Mint) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("◀ Earlier", fontSize = 18.sp) }
                    TextButton(onClick = { month = month.plusMonths(1) }) { Text("Later ▶", fontSize = 18.sp) }
                }
                if (monthly.isEmpty()) {
                    Text("No farm records in this month.", fontSize = 17.sp)
                }
                monthly.forEach { f ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(f.name, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
                        if (f.birdsAtStart > 0) {
                            CalcRow("Birds at start of month", "${f.birdsAtStart} birds")
                        }
                        CalcRow(
                            "Mortality this month",
                            "${f.mortality} birds" + if (f.birdsAtStart > 0) " (${Calc.fmt(Math.round(f.mortalityPercent * 100) / 100.0)}%)" else ""
                        )
                        if (f.birdsAtStart > 0) {
                            CalcRow("Birds left now", "${f.birdsAtEnd} birds", bold = true)
                        } else {
                            Text("Bird count was not written, so only mortality is shown.", fontSize = 15.sp, color = TextLo)
                        }
                        CalcRow("Production", "${Calc.fmt(f.production)} trays")
                        CalcRow("Feed bags used", "${Calc.fmt(f.feedBags)} bags")
                        CalcRow("Days saved", "${f.days}")
                    }
                }
            }

            if (history.isEmpty()) {
                Text("No farm records saved yet.", fontSize = 18.sp)
            }
            history.forEach { d ->
                val date = LocalDate.parse(d.date)
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(date) },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Sky.copy(alpha = 0.10f).compositeOver(Panel)),
                    border = BorderStroke(1.dp, Sky.copy(alpha = 0.6f))
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(date.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
                        Text(d.farmNames.joinToString(", "), fontSize = 16.sp, color = TextLo)
                        CalcRow("Production", "${Calc.fmt(d.production)} trays")
                        CalcRow("Mortality", "${d.mortality} birds")
                        if (d.birdsLeft > 0) CalcRow("Birds left", "${d.birdsLeft} birds", bold = true)
                        CalcRow("Feed bags used", "${Calc.fmt(d.feedBags)} bags")
                        if (d.breakage > 0) CalcRow("Breakage", "${d.breakage} eggs")
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { bird.downloadPdf(date) }) { Text("📄 PDF", fontSize = 18.sp) }
                            TextButton(onClick = { toDelete = d }) {
                                Text("Delete", fontSize = 18.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}
