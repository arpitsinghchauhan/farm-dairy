package com.farmdiary.app.sync

/** Splits all the data into one piece for each month, so the data files stay small however long the records go on. */
object SyncMonths {
    /** Every month ("2026-10") that has dated records, oldest first. */
    fun monthsOf(d: SyncData): List<String> =
        (d.reports.map { it.date } + d.eggSales.map { it.date } + d.feedTxns.map { it.date } +
            d.birdRecords.map { it.date } + d.employeePayments.map { it.date } + d.stockDays.map { it.date } + d.attendance.map { it.date } + d.illnesses.map { it.date } +
            d.specialDiscounts.map { it.date })
            .filter { it.length >= 7 }
            .map { it.substring(0, 7) }
            .distinct().sorted()

    /**
     * The records of one month. Things that have no date (employees, vendors, the stock now, the Scheduler, the farm name)
     * go into every month's file; adding them again is harmless because the newest copy wins.
     */
    fun forMonth(d: SyncData, month: String): SyncData = d.copy(
        reports = d.reports.filter { it.date.startsWith(month) },
        lines = d.lines.filter { it.reportDate.startsWith(month) },
        extras = d.extras.filter { it.reportDate.startsWith(month) },
        eggSales = d.eggSales.filter { it.date.startsWith(month) },
        saleLines = d.saleLines.filter { it.reportDate.startsWith(month) },
        feedTxns = d.feedTxns.filter { it.date.startsWith(month) },
        birdRecords = d.birdRecords.filter { it.date.startsWith(month) },
        employeePayments = d.employeePayments.filter { it.date.startsWith(month) },
        illnesses = d.illnesses.filter { it.date.startsWith(month) },
        attendance = d.attendance.filter { it.date.startsWith(month) },
        stockDays = d.stockDays.filter { it.date.startsWith(month) },
        specialDiscounts = d.specialDiscounts.filter { it.date.startsWith(month) }
    )
}
