package com.farmdiary.app.domain

import com.farmdiary.app.data.IllnessEntity

/** One medicine of a treatment with its dose for each bird (for example "Tylosin", "0.5 ml"). */
data class MedicineDose(val name: String = "", val dose: String = "")

object IllnessRules {
    const val MAX_MEDICINES = 10

    private fun clean(s: String) = s.replace('\n', ' ').replace('\t', ' ').trim()

    /** Medicines kept in one text: one line for each medicine, name and dose split by a tab. Blank rows are dropped. */
    fun encode(list: List<MedicineDose>): String =
        list.filter { it.name.isNotBlank() }
            .take(MAX_MEDICINES)
            .joinToString("\n") { clean(it.name) + "\t" + clean(it.dose) }

    fun decode(text: String): List<MedicineDose> =
        text.split("\n").filter { it.isNotBlank() }.map {
            val p = it.split("\t")
            MedicineDose(p.getOrElse(0) { "" }, p.getOrElse(1) { "" })
        }

    fun validate(illness: String, age: String, farm: String, medicines: List<MedicineDose>): List<String> {
        val out = mutableListOf<String>()
        if (illness.isBlank()) out += "Please write the illness name."
        else if (illness.trim().length > 60) out += "The illness name is too long (60 letters at most)."
        if (age.isBlank() || Calc.isInvalid(age)) out += "Please write the bird age in days (numbers only)."
        if (farm.isBlank()) out += "Please choose the farm."
        if (medicines.any { it.name.isBlank() && it.dose.isNotBlank() }) out += "A dose is written without a medicine name."
        if (medicines.count { it.name.isNotBlank() } > MAX_MEDICINES) out += "You can add up to $MAX_MEDICINES medicines."
        return out
    }

    /** "Day 245 (Week 35)" */
    fun ageText(days: Int): String = "Day $days" + if (days > 0) " (Week ${BirdRecords.weekOf(days)})" else ""

    fun medicinesOf(r: IllnessEntity): List<MedicineDose> = decode(r.medicines)
}
