package com.farmdiary.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.EmployeeViewModel
import com.farmdiary.app.data.EmployeePaymentEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.EmployeeCalc
import com.farmdiary.app.domain.EmployeeRules
import com.farmdiary.app.domain.PayMode
import java.time.YearMonth
import java.time.LocalDate

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    errors: List<String>,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontFamily = TitleFont, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 40) name = it },
                    label = { Text("Employee name") },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 20.sp),
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
                        focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
                        focusedLabelColor = Primary, unfocusedLabelColor = TextLo
                    ),
                    keyboardOptions = KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Words)
                )
                errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text("Save", fontSize = 18.sp) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", fontSize = 18.sp) } }
    )
}

/** List of employees (up to 10) with what each one has received. */
@Composable
fun EmployeeListScreen(vm: EmployeeViewModel, onOpen: (String) -> Unit, onBack: () -> Unit) {
    val employees by vm.employees.collectAsState()
    val payments by vm.payments.collectAsState()
    val message by vm.message.collectAsState()
    val errors by vm.errors.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var adding by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.clearErrors() }
    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    Scaffold(
        topBar = { FarmTopBar("Employees", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "${employees.size} of ${EmployeeRules.MAX_EMPLOYEES} employees",
                fontSize = 16.sp, color = TextLo
            )
            if (employees.isEmpty()) {
                Text("No employees yet. Tap “Add employee” to start.", fontSize = 18.sp, color = TextHi)
            }
            employees.forEach { e ->
                val t = EmployeeCalc.totals(payments.filter { it.employeeId == e.id })
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Panel)
                        .border(1.dp, LineSoft, RoundedCornerShape(24.dp))
                        .clickable { onOpen(e.id) }
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(PrimaryTonal),
                        contentAlignment = Alignment.Center
                    ) { Text("👤", fontSize = 28.sp) }
                    Column(Modifier.weight(1f)) {
                        Text(e.name, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont, color = TextHi)
                        Text("Cash ${Calc.money(t.cash)}  •  Online ${Calc.money(t.online)}", fontSize = 14.sp, color = TextLo)
                    }
                    Text(Calc.money(t.total), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Primary)
                }
            }
            if (employees.size < EmployeeRules.MAX_EMPLOYEES) {
                GradientButton(
                    text = "+ Add employee",
                    onClick = { vm.clearErrors(); adding = true },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text("You have reached the limit of ${EmployeeRules.MAX_EMPLOYEES} employees.", fontSize = 16.sp, color = Sun)
            }
        }
    }

    if (adding) {
        NameDialog(
            title = "Add employee",
            initial = "",
            errors = errors,
            onConfirm = { vm.addEmployee(it) { adding = false } },
            onDismiss = { adding = false; vm.clearErrors() }
        )
    }
}

/** One employee: add a payment (cash / online) for any date, and see all payments by date. */
@Composable
fun EmployeeDetailScreen(vm: EmployeeViewModel, employeeId: String, onBack: () -> Unit) {
    val employees by vm.employees.collectAsState()
    val payments by vm.payments.collectAsState()
    val message by vm.message.collectAsState()
    val errors by vm.errors.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val employee = employees.firstOrNull { it.id == employeeId }

    var date by remember { mutableStateOf(LocalDate.now()) }
    var mode by remember { mutableStateOf(PayMode.CASH) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<EmployeePaymentEntity?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<EmployeePaymentEntity?>(null) }

    var month by remember { mutableStateOf(YearMonth.now()) }
    var salaryDialog by remember { mutableStateOf(false) }
    var salaryText by remember(employee?.id) { mutableStateOf(employee?.monthlySalary?.let { if (it > 0) Calc.fmt(it) else "" } ?: "") }
    val pdfUri by vm.openPdf.collectAsState()
    OpenPdfEffect(pdfUri) { vm.clearOpenPdf() }

    LaunchedEffect(Unit) { vm.clearErrors() }
    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    fun resetForm() {
        editing = null; amount = ""; note = ""; mode = PayMode.CASH
    }

    val mine = payments.filter { it.employeeId == employeeId }
    val totals = EmployeeCalc.totals(mine)
    val days = EmployeeCalc.byDate(payments, employeeId)

    Scaffold(
        topBar = { FarmTopBar(employee?.name ?: "Employee", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        if (employee == null) {
            Column(Modifier.padding(pad).padding(24.dp)) {
                Text("This employee was removed.", fontSize = 18.sp)
            }
            return@Scaffold
        }
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Monthly salary: its own button, apart from the cards
            GradientButton(
                text = "Monthly salary: " + (if (employee.monthlySalary > 0) Calc.money(employee.monthlySalary) else "not set"),
                onClick = { vm.clearErrors(); salaryDialog = true },
                modifier = Modifier.fillMaxWidth(),
                brush = MintBrush
            )

            // Entry form
            SectionCard(
                title = if (editing != null) "Edit payment" else "Add payment",
                icon = "💰"
            ) {
                DatePill(date) { date = it }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ModeChip("💵 Cash", mode == PayMode.CASH, Modifier.weight(1f)) { mode = PayMode.CASH }
                    ModeChip("📱 Online", mode == PayMode.ONLINE, Modifier.weight(1f)) { mode = PayMode.ONLINE }
                }
                NumField("Amount given (₹)", amount, { amount = it }, Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = note,
                    onValueChange = { if (it.length <= 100) note = it },
                    label = { Text("Note (optional)") },
                    singleLine = true,
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextHi, unfocusedTextColor = TextHi, cursorColor = Primary,
                        focusedBorderColor = Primary, unfocusedBorderColor = TextLo,
                        focusedLabelColor = Primary, unfocusedLabelColor = TextLo
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                GradientButton(
                    text = if (editing != null) "Update payment" else "Add payment",
                    onClick = {
                        vm.savePayment(employeeId, date, mode, amount, note, editing) { resetForm() }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                if (editing != null) {
                    TextButton(onClick = { resetForm(); vm.clearErrors() }) { Text("Cancel edit", fontSize = 16.sp) }
                }
            }

            // Salary and the monthly report
            SectionCard(title = "Monthly report", icon = "\uD83D\uDCC5") {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("\u25C0  Previous", fontSize = 16.sp) }
                    Text(
                        month.format(java.time.format.DateTimeFormatter.ofPattern("MMM yyyy", java.util.Locale.ENGLISH)),
                        fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun
                    )
                    TextButton(
                        onClick = { month = month.plusMonths(1) },
                        enabled = month < YearMonth.now()
                    ) { Text("Next  \u25B6", fontSize = 16.sp) }
                }
                val st = EmployeeCalc.statement(payments, employeeId, employee.monthlySalary, month)
                StatementRow("Monthly salary", Calc.money(st.salary))
                StatementRow("Paid in cash", Calc.money(st.cash))
                StatementRow("Paid online", Calc.money(st.online))
                StatementRow("Total paid", Calc.money(st.paid))
                if (st.leftToPay < -1e-9) {
                    StatementRow("Paid extra (advance)", Calc.money(-st.leftToPay), Sun, big = true)
                } else {
                    StatementRow("Left to pay", Calc.money(st.leftToPay), Coral, big = true)
                }
                if (employee.monthlySalary <= 0.0) {
                    Text("Set the monthly salary to see how much is left to pay.", fontSize = 14.sp, color = TextLo)
                }
                GradientButton(
                    text = "Download monthly report (PDF)",
                    onClick = { vm.downloadMonthPdf(employee.name, st) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // History by date
            Text("Payments by date", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, fontFamily = TitleFont, color = TextHi)
            if (days.isEmpty()) {
                Text("No payments yet.", fontSize = 16.sp, color = TextLo)
            }
            days.forEach { day ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Panel)
                        .border(1.dp, LineSoft, RoundedCornerShape(22.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            LocalDate.parse(day.date).format(displayDateFormat),
                            fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Sun
                        )
                        Text("Day total ${Calc.money(day.total)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primary)
                    }
                    day.entries.forEach { p ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    editing = p
                                    date = LocalDate.parse(p.date)
                                    mode = p.mode
                                    amount = Calc.fmt(p.amount)
                                    note = p.note
                                    vm.clearErrors()
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(if (p.mode == PayMode.ONLINE) "📱" else "💵", fontSize = 24.sp)
                            Column(Modifier.weight(1f)) {
                                Text(
                                    (if (p.mode == PayMode.ONLINE) "Online" else "Cash") + "  " + Calc.money(p.amount),
                                    fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextHi
                                )
                                if (p.note.isNotBlank()) Text(p.note, fontSize = 14.sp, color = TextLo)
                            }
                            IconButton(onClick = { confirmDelete = p }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Coral)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = { vm.clearErrors(); renaming = true }, modifier = Modifier.weight(1f)) {
                    Text("Change name", fontSize = 16.sp)
                }
                TextButton(onClick = { confirmRemove = true }, modifier = Modifier.weight(1f)) {
                    Text("Remove employee", fontSize = 16.sp, color = Coral)
                }
            }
        }
    }

    if (salaryDialog && employee != null) {
        AlertDialog(
            onDismissRequest = { salaryDialog = false },
            title = { Text("Monthly salary", fontFamily = TitleFont, fontWeight = FontWeight.SemiBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Monthly salary (\u20B9)", salaryText, { salaryText = it }, Modifier.fillMaxWidth())
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.setSalary(employeeId, salaryText) { salaryDialog = false } }) {
                    Text("Save", fontSize = 18.sp)
                }
            },
            dismissButton = { TextButton(onClick = { salaryDialog = false }) { Text("Cancel", fontSize = 18.sp) } }
        )
    }
    if (renaming && employee != null) {
        NameDialog(
            title = "Change name",
            initial = employee.name,
            errors = errors,
            onConfirm = { vm.rename(employeeId, it) { renaming = false } },
            onDismiss = { renaming = false; vm.clearErrors() }
        )
    }
    if (confirmRemove && employee != null) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text("Remove ${employee.name}?") },
            text = { Text("The employee and the payments will no longer show in the app.") },
            confirmButton = {
                TextButton(onClick = { confirmRemove = false; vm.removeEmployee(employeeId) { onBack() } }) {
                    Text("Remove", color = Coral, fontSize = 18.sp)
                }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel", fontSize = 18.sp) } }
        )
    }
    confirmDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete this payment?") },
            text = { Text("${if (p.mode == PayMode.ONLINE) "Online" else "Cash"} ${Calc.money(p.amount)} on ${LocalDate.parse(p.date).format(displayDateFormat)}") },
            confirmButton = {
                TextButton(onClick = {
                    if (editing?.id == p.id) resetForm()
                    vm.deletePayment(p.id)
                    confirmDelete = null
                }) { Text("Delete", color = Coral, fontSize = 18.sp) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel", fontSize = 18.sp) } }
        )
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Primary else PanelHi)
            .border(BorderStroke(1.dp, if (selected) Primary else LineSoft), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            color = if (selected) OnPrimary else TextHi
        )
    }
}

@Composable
private fun TotalBox(label: String, value: String, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(PanelHi)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Primary, maxLines = 1)
        Text(label, fontSize = 14.sp, color = TextLo)
    }
}

@Composable
private fun StatementRow(label: String, value: String, color: androidx.compose.ui.graphics.Color = TextHi, big: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = if (big) 20.sp else 17.sp, fontWeight = if (big) FontWeight.ExtraBold else FontWeight.Normal, color = if (big) color else TextLo)
        Text(value, fontSize = if (big) 22.sp else 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
    }
}
