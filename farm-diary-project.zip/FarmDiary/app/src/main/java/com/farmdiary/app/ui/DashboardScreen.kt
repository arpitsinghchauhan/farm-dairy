package com.farmdiary.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.DashboardViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.DayTotals
import java.time.format.DateTimeFormatter
import java.util.Locale

private val monthFormat = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)

@Composable
fun DashboardScreen(vm: DashboardViewModel, onBack: () -> Unit) {
    val month by vm.month.collectAsState()
    val summary by vm.summary.collectAsState()

    LaunchedEffect(Unit) { vm.refresh() }

    Scaffold(topBar = { FarmTopBar("Monthly Dashboard", onBack) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { vm.previous() }) { Text("\u2039 Prev") }
                Text(month.format(monthFormat), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Sun)
                OutlinedButton(onClick = { vm.next() }, enabled = vm.canGoNext) { Text("Next \u203A") }
            }

            val s = summary
            if (s == null || s.month != month) {
                Text("Loading...", fontSize = 18.sp)
                return@Column
            }
            if (s.reportCount == 0 && s.income <= 0.0) {
                Text("No reports saved for this month.", fontSize = 18.sp)
                return@Column
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(32.dp))
                    .background(if (s.profit >= 0) MintBrush else CoralBrush)
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    if (s.profit >= 0) "\uD83D\uDE80 Profit this month" else "\uD83D\uDCC9 Loss this month",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = OnBrush
                )
                Text(
                    Calc.money(Math.abs(s.profit)),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = OnBrush
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("\u2B06 Income", fontSize = 15.sp, color = OnBrush.copy(alpha = 0.75f))
                        Text(Calc.money(s.income), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = OnBrush)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("\u2B07 Expenditure", fontSize = 15.sp, color = OnBrush.copy(alpha = 0.75f))
                        Text(Calc.money(s.expenditure), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = OnBrush)
                    }
                }
            }

            SectionCard("Money Received", "\uD83D\uDCB5") {
                CalcRow("Cash received", Calc.money(s.cash))
                CalcRow("Online received", Calc.money(s.online))
                if (s.advance > 0.0) CalcRow("Advance paid", Calc.money(s.advance))
                CalcRow("Balance of this month", Calc.money(s.balanceToReceive))
                if (s.outstanding >= 0.0) {
                    CalcRow("Total balance", Calc.money(s.outstanding), bold = true)
                } else {
                    CalcRow("Advance in hand (credit)", Calc.money(-s.outstanding), bold = true)
                }
            }

            SectionCard("Eggs", "\uD83E\uDD5A") {
                CalcRow("Produced", "${Calc.fmt(s.traysProduced)} trays")
                CalcRow("Sold", "${Calc.fmt(s.traysSold)} trays")
            }

            SectionCard("Mortality", "\uD83D\uDC14") {
                CalcRow("Birds died", "${s.birdsDied} birds")
            }

            SectionCard("Daily Expenditure and Income", "\uD83D\uDCCA") {
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Legend(Coral, "Expenditure")
                    Legend(Mint, "Income")
                }
                MonthChart(s.days)
            }

            if (s.hasEggRate) {
                SectionCard("Egg Rate", "\uD83D\uDCB0") {
                    ValueLineChart(s.days.map { it.day }, s.days.map { it.eggRate }, Primary) { Math.round(it).toString() }
                }
            }
            if (s.farms.any { it.hasBirds }) {
                SectionCard("Total Birds Left", "\uD83D\uDC14") {
                    s.farms.filter { it.hasBirds }.forEach { f ->
                        CalcRow(f.name, "${f.latestBirdsLeft} birds", bold = true)
                    }
                }
            }
            if (s.farms.any { it.hasProduction }) {
                SectionCard("Production %", "\uD83E\uDD5A") {
                    s.farms.filter { it.hasProduction }.forEach { f ->
                        Text(f.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Sun)
                        ValueLineChart(f.days.map { it.day }, f.days.map { it.productionPercent }, Sky) { Math.round(it).toString() + "%" }
                    }
                }
            }
        }
    }
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(18.dp).background(color))
        Text(label, fontSize = 18.sp)
    }
}

@Composable
private fun MonthChart(days: List<DayTotals>) {
    val chartHeight = 200.dp
    val slot = 34.dp
    val max = days.maxOf { maxOf(it.expenditure, it.income) }.let { if (it <= 0.0) 1.0 else it }

    Row(Modifier.fillMaxWidth()) {
        Column(
            Modifier.height(chartHeight).width(52.dp).padding(end = 4.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            Text(Calc.money(max), fontSize = 14.sp)
            Text(Calc.money(max / 2), fontSize = 14.sp)
            Text(Calc.money(0.0), fontSize = 14.sp)
        }
        Box(Modifier.weight(1f)) {
            Column {
                Canvas(Modifier.fillMaxWidth().height(chartHeight)) {
                    val h = size.height
                    val slotPx = size.width / days.size
                    val barW = slotPx * 0.36f
                    val grid = LineSoft
                    listOf(0f, h / 2f, h).forEach {
                        drawLine(grid, Offset(0f, it), Offset(size.width, it), strokeWidth = 2f)
                    }
                    days.forEachIndexed { i, d ->
                        fun bar(value: Double, brush: Brush, x: Float) {
                            if (value <= 0.0) return
                            val bh = maxOf((value / max).toFloat() * h, 3f)
                            drawRoundRect(
                                brush = brush,
                                topLeft = Offset(x, h - bh),
                                size = Size(barW, bh),
                                cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                            )
                        }
                        bar(d.expenditure, CoralBrush, i * slotPx + slotPx * 0.10f)
                        bar(d.income, MintBrush, i * slotPx + slotPx * 0.54f)
                    }
                }
                Row {
                    days.forEach {
                        Box(Modifier.width(slot), contentAlignment = Alignment.Center) {
                            Text("${it.day}", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

/** A line over the month for one value (egg rate, production %). Days with no value are skipped. */
@Composable
private fun ValueLineChart(days: List<Int>, values: List<Double>, color: Color, label: (Double) -> String) {
    val chartHeight = 110.dp
    val shown = values.filter { it > 0.0 }
    val top = shown.maxOrNull() ?: 1.0
    val bottom = shown.minOrNull() ?: 0.0
    val pad = if (top - bottom < 1e-9) Math.max(top * 0.1, 0.5) else (top - bottom) * 0.15
    // Whole numbers only on the left, so the top and bottom are rounded out and the middle is a whole number too.
    val loI = Math.max(Math.floor(bottom - pad).toInt(), 0)
    var hiI = Math.ceil(top + pad).toInt()
    if (hiI - loI < 2) hiI = loI + 2
    if ((hiI - loI) % 2 == 1) hiI += 1
    val hi = hiI.toDouble()
    val lo = loI.toDouble()

    Row(Modifier.fillMaxWidth()) {
        Column(
            Modifier.height(chartHeight).width(52.dp).padding(end = 4.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            Text(label(hi), fontSize = 10.sp, softWrap = false)
            Text(label((hi + lo) / 2), fontSize = 10.sp, softWrap = false)
            Text(label(lo), fontSize = 10.sp, softWrap = false)
        }
        Box(Modifier.weight(1f)) {
            Column {
                Canvas(Modifier.fillMaxWidth().height(chartHeight)) {
                    val h = size.height
                    val slotPx = size.width / days.size
                    listOf(0f, h / 2f, h).forEach {
                        drawLine(LineSoft, Offset(0f, it), Offset(size.width, it), strokeWidth = 2f)
                    }
                    val points = values.mapIndexedNotNull { i, v ->
                        if (v <= 0.0) null else Offset(i * slotPx + slotPx / 2f, h - ((v - lo) / (hi - lo)).toFloat() * h)
                    }
                    for (k in 1 until points.size) {
                        drawLine(color, points[k - 1], points[k], strokeWidth = 4f)
                    }
                    points.forEach { drawCircle(color, radius = 5f, center = it) }
                }
                Row(Modifier.fillMaxWidth()) {
                    days.forEach {
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            if (it == 1 || it % 5 == 0) {
                                Text("$it", fontSize = 10.sp, softWrap = false, modifier = Modifier.wrapContentWidth(unbounded = true))
                            }
                        }
                    }
                }
            }
        }
    }
}
