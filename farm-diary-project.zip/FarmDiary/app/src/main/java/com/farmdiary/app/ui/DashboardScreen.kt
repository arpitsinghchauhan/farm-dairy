package com.farmdiary.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.DashboardViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.DayTotals
import java.time.format.DateTimeFormatter
import java.util.Locale

private val IncomeColor = Color(0xFF2E7D32)
private val monthFormat = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)

@Composable
fun DashboardScreen(vm: DashboardViewModel, onBack: () -> Unit) {
    val month by vm.month.collectAsState()
    val summary by vm.summary.collectAsState()

    LaunchedEffect(Unit) { vm.refresh() }

    Scaffold(topBar = { FarmTopBar("Monthly Dashboard", onBack) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { vm.previous() }) { Text("\u2039 Previous") }
                Text(month.format(monthFormat), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = FarmRed)
                OutlinedButton(onClick = { vm.next() }, enabled = vm.canGoNext) { Text("Next \u203A") }
            }

            val s = summary
            if (s == null || s.month != month) {
                Text("Loading...", fontSize = 18.sp)
                return@Column
            }
            if (s.reportCount == 0) {
                Text("No reports saved for this month.", fontSize = 18.sp)
                return@Column
            }
            Text("Based on ${s.reportCount} saved report(s) this month.", fontSize = 16.sp)

            SectionCard("Income and Expenditure") {
                CalcRow("Total income (egg sale)", Calc.money(s.income), bold = true)
                CalcRow("Total expenditure", Calc.money(s.expenditure), bold = true)
                CalcRow(
                    if (s.profit >= 0) "Profit" else "Loss",
                    Calc.money(Math.abs(s.profit)),
                    bold = true
                )
            }

            SectionCard("Money Received") {
                CalcRow("Cash received", Calc.money(s.cash))
                CalcRow("Online received", Calc.money(s.online))
                CalcRow("Balance to receive", Calc.money(s.balanceToReceive), bold = true)
            }

            SectionCard("Eggs (trays)") {
                CalcRow("Produced", "${Calc.fmt(s.traysProduced)} trays")
                CalcRow("Sold", "${Calc.fmt(s.traysSold)} trays")
            }

            SectionCard("Daily Expenditure and Income") {
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Legend(FarmRed, "Expenditure")
                    Legend(IncomeColor, "Income")
                }
                MonthChart(s.days)
                Text("Numbers below the bars are the dates of the month.", fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(18.dp).background(color))
        Text(label, fontSize = 18.sp)
    }
}

@Composable
private fun MonthChart(days: List<DayTotals>) {
    val chartHeight = 200.dp
    val slot = 34.dp
    val max = days.maxOf { maxOf(it.expenditure, it.income) }.let { if (it <= 0.0) 1.0 else it }

    Row(Modifier.fillMaxWidth()) {
        Column(
            Modifier.height(chartHeight).width(84.dp).padding(end = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            Text(Calc.money(max), fontSize = 14.sp)
            Text(Calc.money(max / 2), fontSize = 14.sp)
            Text(Calc.money(0.0), fontSize = 14.sp)
        }
        Box(Modifier.horizontalScroll(rememberScrollState())) {
            Column {
                Canvas(Modifier.width(slot * days.size).height(chartHeight)) {
                    val h = size.height
                    val slotPx = size.width / days.size
                    val barW = slotPx * 0.36f
                    val grid = Color(0xFFBDBDBD)
                    listOf(0f, h / 2f, h).forEach {
                        drawLine(grid, Offset(0f, it), Offset(size.width, it), strokeWidth = 2f)
                    }
                    days.forEachIndexed { i, d ->
                        fun bar(value: Double, color: Color, x: Float) {
                            if (value <= 0.0) return
                            val bh = maxOf((value / max).toFloat() * h, 3f)
                            drawRect(color, Offset(x, h - bh), Size(barW, bh))
                        }
                        bar(d.expenditure, FarmRed, i * slotPx + slotPx * 0.10f)
                        bar(d.income, IncomeColor, i * slotPx + slotPx * 0.54f)
                    }
                }
                Row {
                    days.forEach {
                        Box(Modifier.width(slot), contentAlignment = Alignment.Center) {
                            Text("${it.day}", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
