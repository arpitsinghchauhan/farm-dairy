package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.data.SpecialDiscountEntity
import com.farmdiary.app.data.VendorEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.PurchaseCategory
import com.farmdiary.app.domain.SpecialDiscountCalc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.UUID

/** Special discounts of feed vendors, with their own list and PDF (not part of the feed report). */
class SpecialDiscountViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val records: StateFlow<List<SpecialDiscountEntity>> = repo.observeSpecialDiscounts()
        .map { SpecialDiscountCalc.live(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** The feed vendors added on the Feed Purchase page. */
    val vendors: StateFlow<List<VendorEntity>> = repo.observeVendors()
        .map { list -> list.filter { it.category == PurchaseCategory.FEED && !it.deleted } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()
    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()

    fun clearMessage() { _message.value = null }
    fun clearErrors() { _errors.value = emptyList() }
    fun clearOpenPdf() { _openPdf.value = null }

    private var saving = false

    fun save(date: LocalDate, vendor: String, bags: String, perBag: String, existing: SpecialDiscountEntity?, onSaved: () -> Unit) {
        val problems = SpecialDiscountCalc.validate(bags, perBag, vendor, vendors.value.size)
        if (problems.isNotEmpty()) { _errors.value = problems; return }
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val b = Calc.parse(bags)
                val d = Calc.parse(perBag)
                repo.saveSpecialDiscount(
                    SpecialDiscountEntity(
                        id = existing?.id ?: UUID.randomUUID().toString(),
                        date = date.toString(), vendor = vendor, bags = b, discountPerBag = d,
                        total = SpecialDiscountCalc.total(b, d), deleted = false,
                        createdAt = existing?.createdAt ?: now, updatedAt = now
                    )
                )
                _errors.value = emptyList()
                _message.value = (if (existing != null) "Updated: " else "Saved: ") + Calc.money(SpecialDiscountCalc.total(b, d)) + " special discount."
                onSaved()
            } catch (e: Exception) {
                AppLog.e("special discount save failed", e)
                _message.value = "Unable to save. Please try again."
            } finally {
                saving = false
            }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            try {
                repo.deleteSpecialDiscount(id, System.currentTimeMillis())
                _message.value = "Entry deleted."
            } catch (e: Exception) {
                AppLog.e("special discount delete failed", e)
                _message.value = "Unable to delete. Please try again."
            }
        }
    }

    fun downloadPdf() {
        val farmName = prefs.getString("farm_name", "") ?: ""
        val list = records.value
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) { PdfExporter.createSpecialDiscount(getApplication(), list, farmName, LocalDate.now()) }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}
