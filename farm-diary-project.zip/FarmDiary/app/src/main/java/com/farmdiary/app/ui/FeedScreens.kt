package com.farmdiary.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.PurchaseViewModel
import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FeedCalc
import com.farmdiary.app.domain.FeedType
import java.time.LocalDate

private val DarkText: Color get() = OnBrush

@Composable
private fun SnackbarFor(message: String?, state: SnackbarHostState, onShown: () -> Unit) {
    LaunchedEffect(message) {
        message?.let {
            state.showSnackbar(it)
            onShown()
        }
    }
}

/** Big card with the balance owed to the supplier. */
@Composable
private fun OutstandingCard(outstanding: Double) {
    val credit = outstanding < -1e-9
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(if (credit) MintBrush else CoralBrush)
            .padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            if (credit) "Advance paid to supplier" else "You have to pay the supplier",
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            color = DarkText
        )
        Text(
            Calc.money(Math.abs(outstanding)),
            fontSize = 42.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = TitleFont,
            color = DarkText
        )
    }
}

private fun entryText(t: FeedTxnEntity, unit: String): String = when (t.type) {
    FeedType.BUY -> {
        val off = if (t.discount > 0) " (${Calc.fmt(t.discount)} off each)" else ""
        (if (t.item.isNotBlank()) "${t.item}: " else "") + "${Calc.fmt(t.bags)} $unit x ${Calc.fmt(t.rate)}$off"
    }
    FeedType.OPENING -> "Old balance"
    FeedType.ONLINE -> "Paid online"
    else -> "Paid cash"
}

/** Entries already saved on the picked date. The user can open one to change it, or delete it. */
@Composable
private fun SavedOnDateCard(
    date: LocalDate,
    entries: List<FeedTxnEntity>,
    unit: String,
    editingId: String?,
    onEdit: (FeedTxnEntity) -> Unit,
    onDelete: (FeedTxnEntity) -> Unit
) {
    var toDelete by remember { mutableStateOf<FeedTxnEntity?>(null) }
    toDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this entry?") },
            text = { Text("The balance you owe will change.") },
            confirmButton = { TextButton(onClick = { onDelete(t); toDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep it") } }
        )
    }
    AccentCard("Saved on ${date.format(displayDateFormat)}", "🗓️", SunBrush, Sun) {
        if (entries.isEmpty()) {
            Text("Nothing saved on this date yet.", fontSize = 17.sp, color = TextLo)
        }
        entries.forEach { t ->
            val open = t.id == editingId
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(entryText(t, unit), fontSize = 17.sp, fontWeight = if (open) FontWeight.ExtraBold else FontWeight.Normal)
                    Text(Calc.money(t.amount), fontSize = 16.sp, color = TextLo)
                    if (t.note.isNotBlank()) Text(t.note, fontSize = 14.sp, color = TextLo)
                }
                TextButton(onClick = { onEdit(t) }) { Text(if (open) "Editing" else "Change", fontSize = 16.sp) }
                IconButton(onClick = { toDelete = t }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete this entry")
                }
            }
        }
    }
}

@Composable
fun FeedHubScreen(
    feed: PurchaseViewModel,
    onBuy: () -> Unit,
    onOnline: () -> Unit,
    onCash: () -> Unit,
    onOpening: () -> Unit,
    onReport: () -> Unit,
    onBack: () -> Unit
) {
    val ledger by feed.ledger.collectAsState()

    val med = feed.isMedicine
    Scaffold(topBar = { FarmTopBar(if (med) "Medicine Purchase" else "Feed Purchase", onBack) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutstandingCard(ledger.outstanding)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                BigTile("🛒", "Buy", if (med) "Add medicines bought" else "Add new feed bags", SunBrush, dark = true, onClick = onBuy, modifier = Modifier.weight(1f))
                BigTile("📲", "Paid Online", "UPI or bank", VioletBrush, dark = false, onClick = onOnline, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                BigTile("💵", "Paid Cash", "Paid in cash", MintBrush, dark = true, onClick = onCash, modifier = Modifier.weight(1f))
                BigTile("📑", "Report", "Date-wise and PDF", PinkBrush, dark = false, onClick = onReport, modifier = Modifier.weight(1f))
            }
            BigTile(
                "📒", "Old Balance", "Add the balance you already owe",
                Brush.linearGradient(listOf(PanelHi, Panel)), dark = Palette.light, onClick = onOpening,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                if (med) {
                    "Already owe the medical store from before? Add it once in Old Balance. Buy adds to what you owe, Paid Online and Paid Cash reduce it."
                } else {
                    "Already owe the supplier from before? Add it once in Old Balance. Buy adds to what you owe, Paid Online and Paid Cash reduce it. Feed stock is separate, use In-Stock for that."
                },
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}

@Composable
fun FeedBuyScreen(feed: PurchaseViewModel, defaultDate: LocalDate, onBack: () -> Unit) {
    val errors by feed.errors.collectAsState()
    val message by feed.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    SnackbarFor(message, snackbar) { feed.clearMessage() }
    DisposableEffect(Unit) { onDispose { feed.clearErrors() } }

    val med = feed.isMedicine
    val unit = if (med) "units" else "bags"
    val ledger by feed.ledger.collectAsState()
    var date by remember { mutableStateOf(defaultDate) }
    var bags by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var item by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<FeedTxnEntity?>(null) }
    val clearForm = { bags = ""; rate = ""; discount = ""; note = ""; item = ""; editing = null }
    val dayEntries = ledger.rows.firstOrNull { it.date == date.toString() }?.entries.orEmpty().filter { it.type == FeedType.BUY }

    val b = Calc.parse(bags)
    val r = Calc.parse(rate)
    val d = Calc.parse(discount)
    val perBag = r - d
    val amount = FeedCalc.buyAmount(b, r, d)

    Scaffold(
        topBar = { FarmTopBar(if (med) "Buy Medicine" else "Buy Feed", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DatePill(date) { date = it; clearForm(); feed.clearErrors() }

            SavedOnDateCard(
                date = date, entries = dayEntries, unit = unit, editingId = editing?.id,
                onEdit = { t ->
                    editing = t
                    item = t.item
                    bags = Calc.fmt(t.bags); rate = Calc.fmt(t.rate)
                    discount = if (t.discount > 0) Calc.fmt(t.discount) else ""
                    note = t.note
                    feed.clearErrors()
                },
                onDelete = { t -> feed.delete(t.id); if (editing?.id == t.id) clearForm() }
            )

            SectionCard(if (editing != null) "Change this purchase" else if (med) "Medicine bought" else "Feed bought", "🛒") {
                if (med) {
                    OutlinedTextField(
                        value = item,
                        onValueChange = { if (it.length <= 60) { item = it; feed.clearErrors() } },
                        label = { Text("Medicine name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                NumField(if (med) "Number of units (bottles or packs)" else "Number of bags", bags, { bags = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                NumField(if (med) "Rate per unit" else "Feed rate per bag", rate, { rate = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                NumField(if (med) "Discount per unit (if any)" else "Discount per bag (if any)", discount, { discount = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = note,
                    onValueChange = { if (it.length <= 80) note = it },
                    label = { Text(if (med) "Shop or bill number (optional)" else "Supplier or bill number (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Amount", "🧮") {
                CalcRow(if (med) "Price per unit after discount" else "Price per bag after discount", Calc.money(if (perBag > 0) perBag else 0.0))
                CalcRow("Amount to pay", Calc.money(if (amount > 0) amount else 0.0), bold = true)
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") {
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }

            GradientButton(
                text = if (editing != null) "✅  Update Transaction" else "✅  Confirm Transaction",
                onClick = {
                    feed.confirmBuy(date, bags, rate, discount, note, item, editing) { clearForm() }
                },
                modifier = Modifier.fillMaxWidth()
            )
            if (editing != null) {
                TextButton(onClick = { clearForm(); feed.clearErrors() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel change", fontSize = 18.sp)
                }
            }
            Text(
                if (med) "The amount is added to what you owe the medical store."
                else "The amount is added to what you owe the supplier. This does not change your feed stock. " +
                    "Update the stock in In-Stock.",
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}

@Composable
fun FeedPaymentScreen(feed: PurchaseViewModel, type: String, defaultDate: LocalDate, onBack: () -> Unit) {
    val online = type == FeedType.ONLINE
    val opening = type == FeedType.OPENING
    val ledger by feed.ledger.collectAsState()
    val errors by feed.errors.collectAsState()
    val message by feed.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    SnackbarFor(message, snackbar) { feed.clearMessage() }
    DisposableEffect(Unit) { onDispose { feed.clearErrors() } }

    var date by remember { mutableStateOf(defaultDate) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<FeedTxnEntity?>(null) }
    val clearForm = { amount = ""; note = ""; editing = null }
    val dayEntries = ledger.rows.firstOrNull { it.date == date.toString() }?.entries.orEmpty().filter { it.type == type }

    // When a saved entry is being changed, show the balance without it so the numbers stay honest.
    val before = ledger.outstanding - (editing?.let { if (opening) it.amount else -it.amount } ?: 0.0)
    val after = if (opening) before + Calc.parse(amount) else before - Calc.parse(amount)

    Scaffold(
        topBar = { FarmTopBar(if (opening) "Old Balance" else if (online) "Paid Online" else "Paid Cash", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DatePill(date) { date = it; clearForm(); feed.clearErrors() }

            SavedOnDateCard(
                date = date, entries = dayEntries, unit = if (feed.isMedicine) "units" else "bags", editingId = editing?.id,
                onEdit = { t ->
                    editing = t
                    amount = Calc.fmt(t.amount)
                    note = t.note
                    feed.clearErrors()
                },
                onDelete = { t -> feed.delete(t.id); if (editing?.id == t.id) clearForm() }
            )

            if (opening) {
                Text(
                    "Use this if you already owe the supplier from before you started using the app. " +
                        "Enter the amount still to be paid, and the date it is outstanding till.",
                    fontSize = 17.sp,
                    color = TextLo
                )
            }
            SectionCard(
                if (opening) "Old balance" else if (online) "Paid online" else "Paid cash",
                if (opening) "📒" else if (online) "📲" else "💵"
            ) {
                NumField(if (opening) "Balance you owe" else "Amount paid", amount, { amount = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = note,
                    onValueChange = { if (it.length <= 80) note = it },
                    label = { Text(if (online) "Reference or UTR number (optional)" else if (opening) "Note, e.g. bills of Aug (optional)" else "Note (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Balance", "🧾") {
                if (before < -1e-9) {
                    CalcRow("Advance already paid", Calc.money(-before))
                } else {
                    CalcRow(if (opening) "Balance before adding this" else "Balance before this payment", Calc.money(before))
                }
                if (after < -1e-9) {
                    CalcRow("Advance paid to supplier after this", Calc.money(-after), bold = true)
                } else {
                    CalcRow(if (opening) "Total balance after adding this" else "Balance after this payment", Calc.money(after), bold = true)
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") {
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }

            GradientButton(
                text = if (editing != null) "✅  Update" else if (opening) "✅  Save Old Balance" else "✅  Confirm Payment",
                onClick = {
                    feed.confirmPayment(type, date, amount, note, editing) { clearForm() }
                },
                brush = if (opening) SunBrush else if (online) VioletBrush else MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
            if (editing != null) {
                TextButton(onClick = { clearForm(); feed.clearErrors() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel change", fontSize = 18.sp)
                }
            }
        }
    }
}

private fun entryLabel(t: FeedTxnEntity, unit: String): String = when (t.type) {
    FeedType.BUY -> {
        val off = if (t.discount > 0) " (${Calc.fmt(t.discount)} off each)" else ""
        "🛒 Bought " + (if (t.item.isNotBlank()) "${t.item}, " else "") + "${Calc.fmt(t.bags)} $unit x ${Calc.fmt(t.rate)}$off"
    }
    FeedType.OPENING -> "📒 Old balance"
    FeedType.ONLINE -> "📲 Paid online"
    else -> "💵 Paid cash"
}

@Composable
fun FeedReportScreen(feed: PurchaseViewModel, onBack: () -> Unit) {
    val ledger by feed.ledger.collectAsState()
    val message by feed.message.collectAsState()
    val pdfUri by feed.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    SnackbarFor(message, snackbar) { feed.clearMessage() }
    OpenPdfEffect(pdfUri) { feed.clearOpenPdf() }

    var toDelete by remember { mutableStateOf<FeedTxnEntity?>(null) }
    toDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this entry?") },
            text = {
                Text("The balance you owe will change.")
            },
            confirmButton = {
                TextButton(onClick = {
                    feed.delete(t.id)
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep it") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar(if (feed.isMedicine) "Medicine Report" else "Feed Report", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutstandingCard(ledger.outstanding)

            SectionCard("Total till now", "📊") {
                if (ledger.totalOpening > 0) CalcRow("Old balance", Calc.money(ledger.totalOpening))
                CalcRow(if (feed.isMedicine) "Medicine bought" else "Feed bought", "${Calc.fmt(ledger.totalBags)} ${if (feed.isMedicine) "units" else "bags"}")
                CalcRow("Purchase amount", Calc.money(ledger.totalBought))
                CalcRow("Paid online", Calc.money(ledger.totalOnline))
                CalcRow("Paid cash", Calc.money(ledger.totalCash))
                if (ledger.outstanding < -1e-9) {
                    CalcRow("Advance paid to supplier", Calc.money(-ledger.outstanding), bold = true)
                } else {
                    CalcRow("Outstanding balance", Calc.money(ledger.outstanding), bold = true)
                }
            }

            if (ledger.rows.isEmpty()) {
                Text(if (feed.isMedicine) "No medicine purchase entries yet." else "No feed purchase entries yet.", fontSize = 18.sp)
            }

            // Newest date first
            ledger.rows.asReversed().forEach { row ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                LocalDate.parse(row.date).format(displayDateFormat),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Sun
                            )
                            Text(
                                if (row.balance < -1e-9) "Advance ${Calc.money(-row.balance)}" else "Balance ${Calc.money(row.balance)}",
                                fontSize = 16.sp,
                                color = TextLo
                            )
                        }
                        row.entries.forEach { t ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(entryLabel(t, if (feed.isMedicine) "units" else "bags"), fontSize = 17.sp)
                                    if (t.note.isNotBlank()) Text(t.note, fontSize = 14.sp, color = TextLo)
                                }
                                Text(Calc.money(t.amount), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { toDelete = t }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete this entry")
                                }
                            }
                        }
                    }
                }
            }

            GradientButton(
                text = "📄  Download PDF",
                onClick = { feed.downloadPdf() },
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
