package com.farmdiary.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FeedViewModel
import com.farmdiary.app.data.FeedTxnEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.FeedCalc
import com.farmdiary.app.domain.FeedType
import java.time.LocalDate

private val DarkText = Color(0xFF1B1030)

/** Tap to change the date of a transaction. */
@Composable
private fun DatePill(date: LocalDate, onPicked: (LocalDate) -> Unit) {
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Panel)
            .border(1.dp, Sun, RoundedCornerShape(20.dp))
            .clickable { showDatePicker(context, date, onPicked) }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("📅 Date (tap to change)", fontSize = 16.sp, color = TextLo)
        Text(date.format(displayDateFormat), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Sun)
    }
}

@Composable
private fun SnackbarFor(message: String?, state: SnackbarHostState, onShown: () -> Unit) {
    LaunchedEffect(message) {
        message?.let {
            state.showSnackbar(it)
            onShown()
        }
    }
}

/** Big card with the balance owed to the supplier. */
@Composable
private fun OutstandingCard(outstanding: Double, stockBags: Double) {
    val credit = outstanding < -1e-9
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(if (credit) MintBrush else CoralBrush)
            .padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            if (credit) "Advance paid to supplier" else "You have to pay the supplier",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = DarkText
        )
        Text(
            Calc.money(Math.abs(outstanding)),
            fontSize = 44.sp,
            fontWeight = FontWeight.ExtraBold,
            color = DarkText
        )
        Text("🌾 Feed in stock: ${Calc.fmt(stockBags)} bags", fontSize = 18.sp, color = DarkText)
    }
}

@Composable
fun FeedHubScreen(
    feed: FeedViewModel,
    onBuy: () -> Unit,
    onOnline: () -> Unit,
    onCash: () -> Unit,
    onReport: () -> Unit,
    onBack: () -> Unit
) {
    val ledger by feed.ledger.collectAsState()
    val stock by feed.stock.collectAsState()

    Scaffold(topBar = { FarmTopBar("Feed Purchase", onBack) }) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutstandingCard(ledger.outstanding, stock.feedBags)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                BigTile("🛒", "Buy", "Add new feed bags", SunBrush, dark = true, onClick = onBuy, modifier = Modifier.weight(1f))
                BigTile("📲", "Paid Online", "UPI or bank", VioletBrush, dark = false, onClick = onOnline, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                BigTile("💵", "Paid Cash", "Paid in cash", MintBrush, dark = true, onClick = onCash, modifier = Modifier.weight(1f))
                BigTile("📑", "Report", "Date-wise and PDF", PinkBrush, dark = false, onClick = onReport, modifier = Modifier.weight(1f))
            }
            Text(
                "Buy adds the bags to your feed stock. Paid Online and Paid Cash reduce the money you owe.",
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}

@Composable
fun FeedBuyScreen(feed: FeedViewModel, defaultDate: LocalDate, onBack: () -> Unit) {
    val stock by feed.stock.collectAsState()
    val errors by feed.errors.collectAsState()
    val message by feed.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    SnackbarFor(message, snackbar) { feed.clearMessage() }
    DisposableEffect(Unit) { onDispose { feed.clearErrors() } }

    var date by remember { mutableStateOf(defaultDate) }
    var bags by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val b = Calc.parse(bags)
    val r = Calc.parse(rate)
    val d = Calc.parse(discount)
    val perBag = r - d
    val amount = FeedCalc.buyAmount(b, r, d)

    Scaffold(
        topBar = { FarmTopBar("Buy Feed", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DatePill(date) { date = it }

            SectionCard("Feed bought", "🛒") {
                NumField("Number of bags", bags, { bags = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                NumField("Feed rate per bag", rate, { rate = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                NumField("Discount per bag (if any)", discount, { discount = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = note,
                    onValueChange = { if (it.length <= 80) note = it },
                    label = { Text("Supplier or bill number (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Amount", "🧮") {
                CalcRow("Price per bag after discount", Calc.money(if (perBag > 0) perBag else 0.0))
                CalcRow("Amount to pay", Calc.money(if (amount > 0) amount else 0.0), bold = true)
                CalcRow("Feed in stock now", "${Calc.fmt(stock.feedBags)} bags")
                CalcRow("Stock after this purchase", "${Calc.fmt(stock.feedBags + b)} bags", bold = true)
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") {
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }

            GradientButton(
                text = "✅  Confirm Transaction",
                onClick = {
                    feed.confirmBuy(date, bags, rate, discount, note) {
                        bags = ""; rate = ""; discount = ""; note = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "When you confirm, the bags are added to your feed stock automatically. " +
                    "The amount is added to what you owe the supplier.",
                fontSize = 16.sp,
                color = TextLo
            )
        }
    }
}

@Composable
fun FeedPaymentScreen(feed: FeedViewModel, type: String, defaultDate: LocalDate, onBack: () -> Unit) {
    val online = type == FeedType.ONLINE
    val ledger by feed.ledger.collectAsState()
    val errors by feed.errors.collectAsState()
    val message by feed.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    SnackbarFor(message, snackbar) { feed.clearMessage() }
    DisposableEffect(Unit) { onDispose { feed.clearErrors() } }

    var date by remember { mutableStateOf(defaultDate) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val before = ledger.outstanding
    val after = before - Calc.parse(amount)

    Scaffold(
        topBar = { FarmTopBar(if (online) "Paid Online" else "Paid Cash", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            DatePill(date) { date = it }

            SectionCard(if (online) "Paid online" else "Paid cash", if (online) "📲" else "💵") {
                NumField("Amount paid", amount, { amount = it; feed.clearErrors() }, Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = note,
                    onValueChange = { if (it.length <= 80) note = it },
                    label = { Text(if (online) "Reference or UTR number (optional)" else "Note (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard("Balance", "🧾") {
                if (before < -1e-9) {
                    CalcRow("Advance already paid", Calc.money(-before))
                } else {
                    CalcRow("Balance before this payment", Calc.money(before))
                }
                if (after < -1e-9) {
                    CalcRow("Advance paid to supplier after this", Calc.money(-after), bold = true)
                } else {
                    CalcRow("Balance after this payment", Calc.money(after), bold = true)
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "⚠️") {
                    errors.forEach { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }

            GradientButton(
                text = "✅  Confirm Payment",
                onClick = {
                    feed.confirmPayment(type, date, amount, note) { amount = ""; note = "" }
                },
                brush = if (online) VioletBrush else MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

private fun entryLabel(t: FeedTxnEntity): String = when (t.type) {
    FeedType.BUY -> {
        val off = if (t.discount > 0) " (${Calc.fmt(t.discount)} off per bag)" else ""
        "🛒 Bought ${Calc.fmt(t.bags)} bags x ${Calc.fmt(t.rate)}$off"
    }
    FeedType.ONLINE -> "📲 Paid online"
    else -> "💵 Paid cash"
}

@Composable
fun FeedReportScreen(feed: FeedViewModel, onBack: () -> Unit) {
    val ledger by feed.ledger.collectAsState()
    val stock by feed.stock.collectAsState()
    val message by feed.message.collectAsState()
    val pdfUri by feed.openPdf.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    SnackbarFor(message, snackbar) { feed.clearMessage() }
    OpenPdfEffect(pdfUri) { feed.clearOpenPdf() }

    var toDelete by remember { mutableStateOf<FeedTxnEntity?>(null) }
    toDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this entry?") },
            text = {
                Text(
                    if (t.type == FeedType.BUY) {
                        "${Calc.fmt(t.bags)} bags will also be taken out of your feed stock."
                    } else {
                        "The balance you owe will change."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    feed.delete(t.id)
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Keep it") } }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Feed Report", onBack) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutstandingCard(ledger.outstanding, stock.feedBags)

            SectionCard("Total till now", "📊") {
                CalcRow("Feed bought", "${Calc.fmt(ledger.totalBags)} bags")
                CalcRow("Purchase amount", Calc.money(ledger.totalBought))
                CalcRow("Paid online", Calc.money(ledger.totalOnline))
                CalcRow("Paid cash", Calc.money(ledger.totalCash))
                if (ledger.outstanding < -1e-9) {
                    CalcRow("Advance paid to supplier", Calc.money(-ledger.outstanding), bold = true)
                } else {
                    CalcRow("Outstanding balance", Calc.money(ledger.outstanding), bold = true)
                }
            }

            if (ledger.rows.isEmpty()) {
                Text("No feed purchase entries yet.", fontSize = 18.sp)
            }

            // Newest date first
            ledger.rows.asReversed().forEach { row ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                LocalDate.parse(row.date).format(displayDateFormat),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Sun
                            )
                            Text(
                                if (row.balance < -1e-9) "Advance ${Calc.money(-row.balance)}" else "Balance ${Calc.money(row.balance)}",
                                fontSize = 16.sp,
                                color = TextLo
                            )
                        }
                        row.entries.forEach { t ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(entryLabel(t), fontSize = 17.sp)
                                    if (t.note.isNotBlank()) Text(t.note, fontSize = 14.sp, color = TextLo)
                                }
                                Text(Calc.money(t.amount), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { toDelete = t }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete this entry")
                                }
                            }
                        }
                    }
                }
            }

            GradientButton(
                text = "📄  Download PDF",
                onClick = { feed.downloadPdf() },
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
