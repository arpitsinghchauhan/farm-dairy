package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.EggSaleEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.data.SaleLineEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.EggSaleForm
import com.farmdiary.app.domain.ExtraItemForm
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.domain.MAX_EXTRA_ITEMS
import com.farmdiary.app.domain.MAX_SALE_LINES
import com.farmdiary.app.domain.ReportForm
import com.farmdiary.app.domain.ReportLinks
import com.farmdiary.app.domain.SaleLineForm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

class FarmViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _farmName = MutableStateFlow(prefs.getString("farm_name", "") ?: "")
    val farmName: StateFlow<String> = _farmName.asStateFlow()

    fun setFarmName(name: String) {
        val clean = name.trim().take(40)
        prefs.edit().putString("farm_name", clean).apply()
        _farmName.value = clean
    }

    /** Re-reads the farm name, e.g. after data from another phone was added. */
    fun refreshFarmName() {
        _farmName.value = prefs.getString("farm_name", "") ?: ""
        _farmCount.value = prefs.getInt("farm_count", 2).coerceIn(1, 5)
    }

    /** How many farms (S.No.) the Daily Report and Farm Records show. Set from the gear menu on Home. */
    private val _farmCount = MutableStateFlow(prefs.getInt("farm_count", 2).coerceIn(1, 5))
    val farmCount: StateFlow<Int> = _farmCount.asStateFlow()

    fun setFarmCount(n: Int) {
        val clean = n.coerceIn(1, 5)
        prefs.edit().putInt("farm_count", clean).apply()
        _farmCount.value = clean
    }

    private val _date = MutableStateFlow(LocalDate.now())
    val date: StateFlow<LocalDate> = _date.asStateFlow()

    private val _form = MutableStateFlow(ReportForm(LocalDate.now(), emptyList()))
    val form: StateFlow<ReportForm> = _form.asStateFlow()

    private val _sale = MutableStateFlow(EggSaleForm(LocalDate.now(), emptyList()))
    val sale: StateFlow<EggSaleForm> = _sale.asStateFlow()

    val stockDays: StateFlow<List<com.farmdiary.app.data.StockDayEntity>> = repo.observeStockDays()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Egg buyers added with the gear icon on the Egg Sell page. */
    val buyers: StateFlow<List<com.farmdiary.app.data.VendorEntity>> = repo.observeVendors()
        .map { list -> list.filter { it.category == BUYER && !it.deleted } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _buyerErrors = MutableStateFlow<List<String>>(emptyList())
    val buyerErrors: StateFlow<List<String>> = _buyerErrors.asStateFlow()
    fun clearBuyerErrors() { _buyerErrors.value = emptyList() }

    fun addBuyer(name: String, onDone: () -> Unit) {
        val problems = com.farmdiary.app.domain.VendorRules.validateName(name, buyers.value.map { it.name })
        if (problems.isNotEmpty()) { _buyerErrors.value = problems; return }
        viewModelScope.launch {
            try {
                val now = System.currentTimeMillis()
                val ok = repo.addVendor(
                    com.farmdiary.app.data.VendorEntity(java.util.UUID.randomUUID().toString(), BUYER, name.trim(), false, now, now),
                    MAX_BUYERS
                )
                if (ok) {
                    _buyerErrors.value = emptyList()
                    _message.value = "Buyer added: ${name.trim()}."
                    onDone()
                } else {
                    _buyerErrors.value = listOf("You can add up to $MAX_BUYERS buyers. Remove one first.")
                }
            } catch (e: Exception) {
                AppLog.e("addBuyer failed", e)
                _message.value = "Unable to add the buyer. Please try again."
            }
        }
    }

    fun removeBuyer(id: String) {
        viewModelScope.launch {
            try {
                repo.removeVendor(id, System.currentTimeMillis())
                _message.value = "Buyer removed. Old sales keep the name."
            } catch (e: Exception) {
                AppLog.e("removeBuyer failed", e)
                _message.value = "Unable to remove the buyer. Please try again."
            }
        }
    }

    val stock: StateFlow<FarmStockEntity> = repo.observeStock()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FarmStockEntity())

    val reports: StateFlow<List<DailyReportEntity>> = repo.observeReports()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()

    private val _saleErrors = MutableStateFlow<List<String>>(emptyList())
    val saleErrors: StateFlow<List<String>> = _saleErrors.asStateFlow()

    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()

    private var keySeed = 1L

    init {
        viewModelScope.launch {
            _date.collectLatest { load(it) }
        }
        // Low stock: warn once a day when the stock is low (the 8:00 AM check repeats it while it stays low).
        viewModelScope.launch {
            repo.observeStock().collectLatest { s ->
                if (s != null) StockAlerts.check(getApplication(), s, oncePerDay = true)
            }
        }
    }

    fun setDate(d: LocalDate) {
        _date.value = d
    }

    /** Every saved egg sale, newest first (the selling history). */
    suspend fun loadEggSaleHistory(): List<com.farmdiary.app.domain.EggSaleDayRow> {
        val (sales, lines) = repo.getEggSaleHistory()
        return com.farmdiary.app.domain.EggSaleHistory.build(sales, lines)
    }

    /** Selling history as a PDF: one line per day, days without a record count as zero. */
    fun downloadSaleHistoryPdf(rows: List<com.farmdiary.app.domain.EggSaleDayRow>) {
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.createEggSaleHistory(getApplication(), rows, _farmName.value, java.time.LocalDate.now())
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }

    fun notify(text: String) { _message.value = text }
    fun clearMessage() { _message.value = null }
    fun clearOpenPdf() { _openPdf.value = null }

    /** Re-reads the selected date from the database (used to discard unsaved edits). */
    fun reload() {
        viewModelScope.launch { load(_date.value) }
    }

    /** The sale of one buyer on one date, for the Egg Sell screen. */
    private suspend fun buildSaleForm(date: LocalDate, buyerName: String): EggSaleForm {
        val key = date.toString()
        val eggSale = repo.getEggSale(key, buyerName)
        val rows = repo.getSalesOf(key, buyerName).map {
            SaleLineForm(keySeed++, it.name, numText(it.trays), rateNum(it.rate), rateNum(it.revisedRate), rateNum(it.subsidy))
        }
        // A day that has no saved sale for this buyer yet starts from this buyer's last balance. The user can change it.
        val prior = if (eggSale == null) repo.getLatestEggSaleBefore(key, buyerName) else null
        val previousText = when {
            eggSale != null -> numText(eggSale.previousBalance)
            prior != null && prior.closingBalance > 0.0 -> numText(prior.closingBalance)
            else -> ""
        }
        val advanceText = when {
            eggSale != null -> numText(eggSale.advancePaid)
            prior != null && prior.closingBalance < 0.0 -> numText(-prior.closingBalance)
            else -> ""
        }
        return EggSaleForm(
            date = date,
            sales = rows.ifEmpty { listOf(SaleLineForm(keySeed++)) },
            cashReceived = numText(eggSale?.cashReceived ?: 0.0),
            onlineReceived = numText(eggSale?.onlineReceived ?: 0.0),
            previousBalance = previousText,
            advancePaid = advanceText,
            buyer = buyerName
        )
    }

    private suspend fun reloadSale(date: LocalDate, buyerName: String) {
        _saleErrors.value = emptyList()
        _sale.value = buildSaleForm(date, buyerName)
    }

    private suspend fun load(date: LocalDate, buyerChoice: String? = null) {
        _errors.value = emptyList()
        _saleErrors.value = emptyList()
        val key = date.toString()
        val report = repo.getReport(key)
        val lines = repo.getLines(key)
        val extras = repo.getExtras(key)
        // One day can have several buyers: the Egg Sell screen shows one buyer at a time, the Daily Report adds them all.
        val daySales = repo.getEggSalesOn(key)
        val buyerName = buyerChoice
            ?: daySales.firstOrNull()?.buyer
            ?: repo.getLatestAnyEggSaleBefore(key)?.buyer
            ?: ""
        fun toForms(rows: List<com.farmdiary.app.data.SaleLineEntity>) = rows.map {
            SaleLineForm(keySeed++, it.name, numText(it.trays), rateNum(it.rate), rateNum(it.revisedRate), rateNum(it.subsidy))
        }
        val dayForms = toForms(repo.getSales(key))
        val dayCash = numText(daySales.sumOf { it.cashReceived })
        val dayOnline = numText(daySales.sumOf { it.onlineReceived })
        val dayPrevious = numText(daySales.sumOf { it.previousBalance })
        val dayAdvance = numText(daySales.sumOf { it.advancePaid })

        // Egg Sell screen state (always at least one empty row to type in).
        _sale.value = buildSaleForm(date, buyerName)

        // A new report starts with the number of farms set on Home, and each farm's age counted forward.
        val count = _farmCount.value
        val aged = if (report == null) repo.getLatestAgedLinesBefore(key) else null
        val gap = aged?.let { java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(it.first), date).coerceAtLeast(0) } ?: 0L
        // Feed, tray and stone rates repeat the last confirmed report's rates until the user changes them.
        val rateSource = if (report == null || !report.confirmed) repo.getLatestConfirmedReportBefore(key) else null
        val rateLines = rateSource?.let { repo.getLinesOf(it.date) } ?: emptyList()
        fun blankLine(i: Int): FarmLineForm {
            val prior = aged?.second?.getOrNull(i)?.dayNo ?: 0
            return FarmLineForm(
                keySeed++, name = "S.No. ${i + 1}",
                feedRate = numText(rateLines.getOrNull(i)?.feedRate ?: 0.0),
                dayNo = if (prior > 0) (prior + gap).toString() else ""
            )
        }
        // The age of the birds comes from Farm Records of this date when it is written there.
        val birds = repo.getBirdRecords(key)
        val recordAge = birds.filter { it.dayNo > 0 }.associate { it.position to it.dayNo }
        // Light and labour repeat the last report's amounts until the user changes them.
        val lastReport = if (report == null) repo.getLatestReportBefore(key) else null
        fun withAge(list: List<FarmLineForm>) = list.mapIndexed { i, l ->
            recordAge[i]?.let { l.copy(dayNo = it.toString(), ageFromRecord = true) } ?: l
        }
        val built = if (report == null) {
            ReportForm(
                date = date,
                lines = withAge((0 until count).map { blankLine(it) }),
                labour = numText(lastReport?.labour ?: 0.0),
                light = numText(lastReport?.light ?: 0.0),
                trayRate = numText(rateSource?.trayRate ?: 0.0),
                stoneRate = numText(rateSource?.stoneRate ?: 0.0),
                sales = dayForms,
                cashReceived = dayCash,
                onlineReceived = dayOnline,
                previousBalance = dayPrevious,
                advancePaid = dayAdvance
            )
        } else {
            ReportForm(
                date = date,
                lines = withAge(lines.map {
                    FarmLineForm(
                        key = keySeed++,
                        name = it.name,
                        feedBags = numText(it.feedBags),
                        feedRate = numText(it.feedRate),
                        trays = numText(it.trays),
                        mortality = if (it.mortality == 0) "" else it.mortality.toString(),
                        dayNo = if (it.dayNo == 0) "" else it.dayNo.toString()
                    )
                }.let { saved -> if (saved.size >= count) saved else saved + (saved.size until count).map { i -> FarmLineForm(keySeed++, name = "S.No. ${i + 1}") } }),
                eggRate = rateNum(report.eggRate),
                trayQty = numText(report.trayQty),
                trayRate = numText(report.trayRate),
                labour = numText(report.labour),
                light = numText(report.light),
                stoneQty = numText(report.stoneQty),
                stoneRate = numText(report.stoneRate),
                sales = dayForms,
                cashReceived = dayCash,
                onlineReceived = dayOnline,
                previousBalance = dayPrevious,
                advancePaid = dayAdvance,
                extras = extras.filter { !it.income }.map { ExtraItemForm(keySeed++, it.name, numText(it.amount)) },
                otherIncome = extras.filter { it.income }.map { ExtraItemForm(keySeed++, it.name, numText(it.amount)) },
                confirmed = report.confirmed,
                confirmedFeedUsed = report.confirmedFeedUsed,
                confirmedTrayUsed = report.confirmedTrayUsed,
                confirmedTrayOpening = report.openingTrays,
                confirmedTrayClosing = report.closingTrays,
                confirmedOpening = report.openingFeed,
                confirmedClosing = report.closingFeed,
                confirmedEggTrays = report.closingEggTrays,
                confirmedEggNet = report.eggNet,
                createdAt = report.createdAt
            )
        }
        // A report not confirmed yet (a draft) also gets the rates for any rate box that is still empty.
        val withRates = if (report != null && !report.confirmed && rateSource != null) {
            built.copy(
                lines = built.lines.mapIndexed { i, l ->
                    if (l.feedRate.isBlank()) l.copy(feedRate = numText(rateLines.getOrNull(i)?.feedRate ?: 0.0)) else l
                },
                trayRate = built.trayRate.ifBlank { numText(rateSource.trayRate) },
                stoneRate = built.stoneRate.ifBlank { numText(rateSource.stoneRate) }
            )
        } else built
        val shown = ReportLinks.overlay(withRates, birds)
        _form.value = shown
    }

    /** Egg prices keep all their decimals (up to 9). */
    private fun rateNum(d: Double): String = if (d == 0.0) "" else Calc.rateText(d)

    private fun numText(d: Double): String = if (d == 0.0) "" else Calc.fmt(d)

    // ---- daily report form editing --------------------------------------

    fun edit(transform: (ReportForm) -> ReportForm) {
        _errors.value = emptyList()
        _form.update { transform(it).copy(dirty = true) }
    }

    fun editLine(key: Long, transform: (FarmLineForm) -> FarmLineForm) = edit { f ->
        f.copy(lines = f.lines.map { if (it.key == key) transform(it) else it })
    }

    fun addLine() = edit { f ->
        f.copy(lines = f.lines + FarmLineForm(keySeed++, name = "S.No. ${f.lines.size + 1}"))
    }

    fun removeLine(key: Long) = edit { f -> f.copy(lines = f.lines.filterNot { it.key == key }) }

    fun addExtra() {
        if (_form.value.extras.size >= MAX_EXTRA_ITEMS) {
            _message.value = "You can add up to $MAX_EXTRA_ITEMS extra items."
            return
        }
        edit { f -> f.copy(extras = f.extras + ExtraItemForm(keySeed++)) }
    }

    fun editExtra(key: Long, transform: (ExtraItemForm) -> ExtraItemForm) = edit { f ->
        f.copy(extras = f.extras.map { if (it.key == key) transform(it) else it })
    }

    fun addOtherIncome() {
        if (_form.value.otherIncome.size >= MAX_EXTRA_ITEMS) {
            _message.value = "You can add up to $MAX_EXTRA_ITEMS other income items."
            return
        }
        edit { f -> f.copy(otherIncome = f.otherIncome + ExtraItemForm(keySeed++)) }
    }

    fun editOtherIncome(key: Long, transform: (ExtraItemForm) -> ExtraItemForm) = edit { f ->
        f.copy(otherIncome = f.otherIncome.map { if (it.key == key) transform(it) else it })
    }

    fun removeOtherIncome(key: Long) = edit { f -> f.copy(otherIncome = f.otherIncome.filterNot { it.key == key }) }

    fun removeExtra(key: Long) = edit { f -> f.copy(extras = f.extras.filterNot { it.key == key }) }

    // ---- egg sell ---------------------------------------------------------

    private fun editSaleForm(transform: (EggSaleForm) -> EggSaleForm) {
        _saleErrors.value = emptyList()
        _sale.update { transform(it).copy(dirty = true) }
    }

    /** Picks the buyer: that buyer's sale of the date (lines, cash, online, balance) is loaded. */
    fun setBuyer(name: String) {
        val f = _sale.value
        if (name == f.buyer) return
        if (f.dirty) {
            _message.value = "Please save the egg sale before changing the buyer."
            return
        }
        viewModelScope.launch { reloadSale(f.date, name) }
    }

    fun addSale() {
        if (_sale.value.sales.size >= MAX_SALE_LINES) {
            _message.value = "You can add up to $MAX_SALE_LINES egg sizes."
            return
        }
        editSaleForm { f -> f.copy(sales = f.sales + SaleLineForm(keySeed++)) }
    }

    fun editSale(key: Long, transform: (SaleLineForm) -> SaleLineForm) = editSaleForm { f ->
        f.copy(sales = f.sales.map { if (it.key == key) transform(it) else it })
    }

    fun removeSale(key: Long) = editSaleForm { f ->
        val left = f.sales.filterNot { it.key == key }
        f.copy(sales = left.ifEmpty { listOf(SaleLineForm(keySeed++)) })
    }

    fun editCash(v: String) = editSaleForm { it.copy(cashReceived = v) }
    fun editOnline(v: String) = editSaleForm { it.copy(onlineReceived = v) }
    fun editPrevious(v: String) = editSaleForm { it.copy(previousBalance = v) }
    fun editAdvance(v: String) = editSaleForm { it.copy(advancePaid = v) }

    /** Clears the day's sale and saves it as NIL (no egg sold). */
    fun markNil() {
        _sale.update {
            it.copy(
                sales = listOf(SaleLineForm(keySeed++)),
                cashReceived = "",
                onlineReceived = "",
                advancePaid = "",
                dirty = true
            )
        }
        saveSale(nil = true)
    }

    fun saveSale(nil: Boolean = false) {
        viewModelScope.launch {
            val f = _sale.value
            val problems = Calc.validateSale(f)
            if (problems.isNotEmpty()) {
                _saleErrors.value = problems
                return@launch
            }
            try {
                val real = f.realLines()
                val key = f.date.toString()
                repo.saveEggSale(
                    EggSaleEntity(
                        date = key,
                        cashReceived = Calc.parse(f.cashReceived),
                        onlineReceived = Calc.parse(f.onlineReceived),
                        updatedAt = System.currentTimeMillis(),
                        previousBalance = f.previous,
                        advancePaid = f.advance,
                        closingBalance = f.balance,
                        buyer = f.buyer.trim()
                    ),
                    real.mapIndexed { i, s ->
                        SaleLineEntity(
                            reportDate = key,
                            position = i,
                            name = s.name.trim().ifEmpty { "Sale ${i + 1}" },
                            trays = Calc.parse(s.trays),
                            rate = Calc.parse(s.rate),
                            revisedRate = Calc.parse(s.revisedRate),
                            subsidy = Calc.parse(s.subsidy),
                            buyer = f.buyer.trim()
                        )
                    }
                )
                _sale.update { it.copy(sales = real.ifEmpty { listOf(SaleLineForm(keySeed++)) }, dirty = false) }
                // The Daily Report of the same date picks the sale up automatically (all buyers added together).
                if (_form.value.date == f.date) {
                    val daySales = repo.getEggSalesOn(key)
                    val dayLines = repo.getSales(key).map {
                        SaleLineForm(keySeed++, it.name, numText(it.trays), rateNum(it.rate), rateNum(it.revisedRate), rateNum(it.subsidy))
                    }
                    _form.update {
                        it.copy(
                            sales = dayLines,
                            cashReceived = numText(daySales.sumOf { s -> s.cashReceived }),
                            onlineReceived = numText(daySales.sumOf { s -> s.onlineReceived }),
                            previousBalance = numText(daySales.sumOf { s -> s.previousBalance }),
                            advancePaid = numText(daySales.sumOf { s -> s.advancePaid })
                        )
                    }
                }
                _message.value = if (nil || real.isEmpty()) {
                    "Saved as NIL (no egg sold). It is shown in the Daily Report."
                } else {
                    "Egg sale saved. It is added to the Daily Report of this date."
                }
            } catch (e: Exception) {
                AppLog.e("saveSale failed", e)
                _message.value = "Unable to save egg sale. Please try again."
            }
        }
    }

    fun downloadSalePdf() {
        val f = _sale.value
        if (f.dirty) {
            _message.value = "Please save the egg sale first."
            return
        }
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.createEggSale(getApplication(), f.copy(sales = f.realLines()), _farmName.value)
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }

    // ---- save / confirm daily report -------------------------------------

    fun saveDraft() {
        viewModelScope.launch {
            val f = _form.value
            if (f.hasInvalidNumbers()) {
                _errors.value = listOf("Please enter a valid quantity (numbers only, not negative).")
                return@launch
            }
            try {
                val now = System.currentTimeMillis()
                val created = if (f.createdAt == 0L) now else f.createdAt
                repo.saveReport(
                    toEntity(
                        f, confirmed = false,
                        feedUsed = f.confirmedFeedUsed, opening = f.confirmedOpening, closing = f.confirmedClosing,
                        trayUsed = f.confirmedTrayUsed, trayOpening = f.confirmedTrayOpening,
                        trayClosing = f.confirmedTrayClosing,
                        eggTrays = f.confirmedEggTrays, eggNet = f.confirmedEggNet,
                        created = created, updated = now
                    ),
                    toLines(f),
                    toExtras(f),
                    newStock = null
                )
                repo.linkReportToBirds(f.date.toString(), toLines(f), now)
                _form.update { it.copy(confirmed = false, createdAt = created, dirty = false) }
                _message.value = "Report saved successfully."
            } catch (e: Exception) {
                AppLog.e("saveDraft failed", e)
                _message.value = "Unable to save report. Please try again."
            }
        }
    }

    private var pastOpening: Pair<Double, Int> = 0.0 to 0

    fun confirm() {
        viewModelScope.launch {
            val f = _form.value
            val stock = repo.getStock()
            // A report of an earlier day never takes anything off the stock now and is not checked against it:
            // that day's stock record (written in In-Stock, or counted from the day before) is used instead.
            val past = f.date.isBefore(LocalDate.now())
            val key = f.date.toString()
            val manual = if (past) repo.getStockDayOn(key) else null
            val prior = if (past && !f.stockApplied) repo.getLatestConfirmedReportBefore(key) else null
            val plan = if (!past) Calc.planConfirm(f, stock.feedBags, stock.blankTrays) else {
                val usedFeed = f.feedUsed
                val usedTrays = Math.round(f.trayUsed).toInt()
                val feedClose = when {
                    f.stockApplied -> f.confirmedOpening - usedFeed
                    manual != null && manual.feedLeft >= 0 -> manual.feedLeft
                    else -> (prior?.closingFeed ?: stock.feedBags) - usedFeed
                }
                val trayClose = when {
                    f.stockApplied -> Math.round(f.confirmedTrayOpening).toInt() - usedTrays
                    manual != null && manual.trayLeft >= 0 -> manual.trayLeft
                    else -> (prior?.closingTrays?.let { Math.round(it).toInt() } ?: stock.blankTrays) - usedTrays
                }
                val feedOpen = if (f.stockApplied) f.confirmedOpening else feedClose + usedFeed
                val trayOpen = if (f.stockApplied) Math.round(f.confirmedTrayOpening).toInt() else trayClose + usedTrays
                Calc.StockPlan(emptyList(), feedClose, trayClose, stock.feedBags, stock.blankTrays).also {
                    pastOpening = feedOpen to trayOpen
                }
            }
            if (plan.problems.isNotEmpty()) {
                _errors.value = plan.problems
                return@launch
            }
            try {
                val now = System.currentTimeMillis()
                val created = if (f.createdAt == 0L) now else f.createdAt
                val used = f.feedUsed
                val opening = if (past) pastOpening.first else f.feedBase(stock.feedBags)
                val closing = plan.feedLeft
                val trayUsed = Math.round(f.trayUsed).toInt()
                val trayOpening = if (past) pastOpening.second else f.trayBase(stock.blankTrays)
                val trayClosing = plan.trayLeft
                // Egg stock is not worked out from production or sales. It is the value written in In-Stock:
                // the day's own record if there is one, otherwise the egg stock at that time.
                val eggNet = 0
                val eggStock = when {
                    f.stockApplied && f.confirmedEggTrays >= 0 -> f.confirmedEggTrays
                    past && manual != null && manual.eggTrays >= 0 -> manual.eggTrays
                    past && prior != null && prior.closingEggTrays >= 0 -> prior.closingEggTrays
                    else -> stock.eggTrays
                }
                val newEggNow = stock.eggTrays
                repo.saveReport(
                    toEntity(
                        f, confirmed = true,
                        feedUsed = used, opening = opening, closing = closing,
                        trayUsed = trayUsed.toDouble(), trayOpening = trayOpening.toDouble(),
                        trayClosing = trayClosing.toDouble(),
                        eggTrays = eggStock, eggNet = eggNet.toDouble(),
                        created = created, updated = now
                    ),
                    toLines(f),
                    toExtras(f),
                    newStock = if (past) null else stock.copy(id = 1, feedBags = plan.newFeed, blankTrays = plan.newTrays, eggTrays = newEggNow, updatedAt = now)
                )
                repo.linkReportToBirds(f.date.toString(), toLines(f), now)
                _form.update {
                    it.copy(
                        confirmed = true,
                        confirmedFeedUsed = used,
                        confirmedOpening = opening,
                        confirmedClosing = closing,
                        confirmedTrayUsed = trayUsed.toDouble(),
                        confirmedTrayOpening = trayOpening.toDouble(),
                        confirmedTrayClosing = trayClosing.toDouble(),
                        confirmedEggTrays = eggStock,
                        confirmedEggNet = eggNet.toDouble(),
                        createdAt = created,
                        dirty = false
                    )
                }
                _message.value = "Report confirmed. You can now download the PDF."
            } catch (e: Exception) {
                AppLog.e("confirm failed", e)
                _message.value = "Unable to confirm report. Please try again."
            }
        }
    }

    private fun toEntity(
        f: ReportForm,
        confirmed: Boolean,
        feedUsed: Double,
        opening: Double,
        closing: Double,
        trayUsed: Double,
        trayOpening: Double,
        trayClosing: Double,
        eggTrays: Int = -1,
        eggNet: Double = 0.0,
        created: Long,
        updated: Long
    ) = DailyReportEntity(
        date = f.date.toString(),
        trayQty = Calc.parse(f.trayQty),
        trayRate = Calc.parse(f.trayRate),
        labour = Calc.parse(f.labour),
        light = Calc.parse(f.light),
        stoneQty = Calc.parse(f.stoneQty),
        stoneRate = Calc.parse(f.stoneRate),
        eggSell = f.totalIncome,
        cashReceived = Calc.parse(f.cashReceived),
        onlineReceived = Calc.parse(f.onlineReceived),
        confirmedTrayUsed = trayUsed,
        openingTrays = trayOpening,
        closingTrays = trayClosing,
        closingEggTrays = eggTrays,
        confirmed = confirmed,
        confirmedFeedUsed = feedUsed,
        openingFeed = opening,
        closingFeed = closing,
        createdAt = created,
        updatedAt = updated,
        eggRate = Calc.parse(f.eggRate),
        eggNet = eggNet
    )

    private fun toExtras(f: ReportForm): List<ExtraItemEntity> =
        f.extras.mapIndexed { i, e ->
            ExtraItemEntity(
                reportDate = f.date.toString(),
                position = i,
                name = e.name.trim().ifEmpty { "Item ${i + 1}" },
                amount = Calc.parse(e.amount)
            )
        } + f.otherIncome.mapIndexed { i, e ->
            ExtraItemEntity(
                reportDate = f.date.toString(),
                position = f.extras.size + i,
                name = e.name.trim().ifEmpty { "Other income ${i + 1}" },
                amount = Calc.parse(e.amount),
                income = true
            )
        }

    private fun toLines(f: ReportForm): List<FarmLineEntity> =
        f.lines.mapIndexed { i, l ->
            FarmLineEntity(
                reportDate = f.date.toString(),
                position = i,
                name = l.name.trim().ifEmpty { "S.No. ${i + 1}" },
                feedBags = Calc.parse(l.feedBags),
                feedRate = Calc.parse(l.feedRate),
                trays = Calc.parse(l.trays),
                mortality = Math.round(Calc.parse(l.mortality)).toInt(),
                dayNo = Calc.parse(l.dayNo).toInt()
            )
        }

    // ---- stock ----------------------------------------------------------

    /** [blankBundles] is entered in bundles (1 bundle = 100 trays); the stock itself is kept in trays. */
    fun saveStock(feed: String, blankBundles: String, eggTrays: String) {
        if (Calc.isInvalid(feed) || Calc.isInvalid(blankBundles) || Calc.isInvalid(eggTrays)) {
            _message.value = "Please enter a valid quantity."
            return
        }
        viewModelScope.launch {
            try {
                repo.saveStock(
                    FarmStockEntity(
                        id = 1,
                        feedBags = Calc.parse(feed),
                        blankTrays = Math.round(Calc.parse(blankBundles) * Calc.TRAYS_PER_BUNDLE).toInt(),
                        eggTrays = Calc.parse(eggTrays).toInt(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
                _message.value = "Stock saved successfully."
            } catch (e: Exception) {
                AppLog.e("saveStock failed", e)
                _message.value = "Unable to save stock. Please try again."
            }
        }
    }

    /** Saves the stock left of a past date. The stock now (Home) does not change. Blank boxes are left as they are. */
    fun saveDayStock(date: LocalDate, feed: String, bundles: String, eggs: String) {
        if (Calc.isInvalid(feed) || Calc.isInvalid(bundles) || Calc.isInvalid(eggs)) {
            _message.value = "Please enter a valid quantity."
            return
        }
        if (feed.isBlank() && bundles.isBlank() && eggs.isBlank()) {
            _message.value = "Please write the stock left on this date."
            return
        }
        viewModelScope.launch {
            try {
                repo.setDayStock(
                    date.toString(),
                    if (feed.isBlank()) null else Calc.parse(feed),
                    if (bundles.isBlank()) null else Math.round(Calc.parse(bundles) * Calc.TRAYS_PER_BUNDLE).toInt(),
                    if (eggs.isBlank()) null else Calc.parse(eggs).toInt(),
                    System.currentTimeMillis()
                )
                _message.value = "Stock of this date saved."
                load(_date.value)
            } catch (e: Exception) {
                AppLog.e("saveDayStock failed", e)
                _message.value = "Unable to save. Please try again."
            }
        }
    }

    /** Adds newly bought feed bags on top of the current stock. */
    fun addFeedStock(text: String) {
        val n = Calc.parse(text)
        if (Calc.isInvalid(text) || n <= 0) {
            _message.value = "Please enter how many bags to add."
            return
        }
        viewModelScope.launch {
            try {
                val s = repo.getStock()
                val updated = s.copy(id = 1, feedBags = s.feedBags + n, updatedAt = System.currentTimeMillis())
                repo.saveStock(updated)
                _message.value = "Added ${Calc.fmt(n)} bags. Feed in stock is now ${Calc.fmt(updated.feedBags)} bags."
            } catch (e: Exception) {
                AppLog.e("addFeedStock failed", e)
                _message.value = "Unable to add stock. Please try again."
            }
        }
    }

    /** Adds newly bought tray bundles (1 bundle = 100 trays) on top of the current stock. */
    fun addTrayStock(bundlesText: String) {
        val bundles = Calc.parse(bundlesText)
        if (Calc.isInvalid(bundlesText) || bundles <= 0) {
            _message.value = "Please enter how many bundles to add."
            return
        }
        val trays = Math.round(bundles * Calc.TRAYS_PER_BUNDLE).toInt()
        viewModelScope.launch {
            try {
                val s = repo.getStock()
                val updated = s.copy(id = 1, blankTrays = s.blankTrays + trays, updatedAt = System.currentTimeMillis())
                repo.saveStock(updated)
                _message.value = "Added ${Calc.fmt(bundles)} bundles. Tray stock is now " +
                    "${Calc.fmt(Calc.bundles(updated.blankTrays.toDouble()))} bundles."
            } catch (e: Exception) {
                AppLog.e("addTrayStock failed", e)
                _message.value = "Unable to add stock. Please try again."
            }
        }
    }

    // ---- PDF ------------------------------------------------------------

    fun downloadPdf() {
        val f = _form.value
        if (!f.confirmed || f.dirty) {
            _message.value = "Please confirm the report first."
            return
        }
        viewModelScope.launch {
            val currentStock = repo.getStock()
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.create(getApplication(), f, currentStock, _farmName.value)
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}

private const val BUYER = "BUYER"
private const val MAX_BUYERS = 10
