package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.DailyReportEntity
import com.farmdiary.app.data.ExtraItemEntity
import com.farmdiary.app.data.FarmLineEntity
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.data.FarmStockEntity
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.ExtraItemForm
import com.farmdiary.app.domain.FarmLineForm
import com.farmdiary.app.domain.MAX_EXTRA_ITEMS
import com.farmdiary.app.domain.ReportForm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

class FarmViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _farmName = MutableStateFlow(prefs.getString("farm_name", "") ?: "")
    val farmName: StateFlow<String> = _farmName.asStateFlow()

    fun setFarmName(name: String) {
        val clean = name.trim().take(40)
        prefs.edit().putString("farm_name", clean).apply()
        _farmName.value = clean
    }

    private val _date = MutableStateFlow(LocalDate.now())
    val date: StateFlow<LocalDate> = _date.asStateFlow()

    private val _form = MutableStateFlow(ReportForm(LocalDate.now(), emptyList()))
    val form: StateFlow<ReportForm> = _form.asStateFlow()

    val stock: StateFlow<FarmStockEntity> = repo.observeStock()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FarmStockEntity())

    val reports: StateFlow<List<DailyReportEntity>> = repo.observeReports()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _errors = MutableStateFlow<List<String>>(emptyList())
    val errors: StateFlow<List<String>> = _errors.asStateFlow()

    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()

    private var keySeed = 1L

    init {
        viewModelScope.launch {
            _date.collectLatest { load(it) }
        }
    }

    fun setDate(d: LocalDate) {
        _date.value = d
    }

    fun clearMessage() { _message.value = null }
    fun clearOpenPdf() { _openPdf.value = null }

    /** Re-reads the selected date from the database (used to discard unsaved edits). */
    fun reload() {
        viewModelScope.launch { load(_date.value) }
    }

    private suspend fun load(date: LocalDate) {
        _errors.value = emptyList()
        val key = date.toString()
        val report = repo.getReport(key)
        val lines = repo.getLines(key)
        val extras = repo.getExtras(key)
        _form.value = if (report == null) {
            ReportForm(
                date = date,
                lines = listOf(
                    FarmLineForm(keySeed++, name = "S.No. 1"),
                    FarmLineForm(keySeed++, name = "S.No. 2")
                )
            )
        } else {
            ReportForm(
                date = date,
                lines = lines.map {
                    FarmLineForm(
                        key = keySeed++,
                        name = it.name,
                        feedBags = numText(it.feedBags),
                        feedRate = numText(it.feedRate),
                        trays = numText(it.trays)
                    )
                },
                trayQty = numText(report.trayQty),
                trayRate = numText(report.trayRate),
                labour = numText(report.labour),
                light = numText(report.light),
                stoneQty = numText(report.stoneQty),
                stoneRate = numText(report.stoneRate),
                eggSell = numText(report.eggSell),
                extras = extras.map { ExtraItemForm(keySeed++, it.name, numText(it.amount)) },
                confirmed = report.confirmed,
                confirmedFeedUsed = report.confirmedFeedUsed,
                confirmedOpening = report.openingFeed,
                confirmedClosing = report.closingFeed,
                createdAt = report.createdAt
            )
        }
    }

    private fun numText(d: Double): String = if (d == 0.0) "" else Calc.fmt(d)

    // ---- form editing -------------------------------------------------

    fun edit(transform: (ReportForm) -> ReportForm) {
        _errors.value = emptyList()
        _form.update { transform(it).copy(dirty = true) }
    }

    fun editLine(key: Long, transform: (FarmLineForm) -> FarmLineForm) = edit { f ->
        f.copy(lines = f.lines.map { if (it.key == key) transform(it) else it })
    }

    fun addLine() = edit { f ->
        f.copy(lines = f.lines + FarmLineForm(keySeed++, name = "S.No. ${f.lines.size + 1}"))
    }

    fun addExtra() {
        if (_form.value.extras.size >= MAX_EXTRA_ITEMS) {
            _message.value = "You can add up to $MAX_EXTRA_ITEMS extra items."
            return
        }
        edit { f -> f.copy(extras = f.extras + ExtraItemForm(keySeed++)) }
    }

    fun editExtra(key: Long, transform: (ExtraItemForm) -> ExtraItemForm) = edit { f ->
        f.copy(extras = f.extras.map { if (it.key == key) transform(it) else it })
    }

    fun removeExtra(key: Long) = edit { f -> f.copy(extras = f.extras.filterNot { it.key == key }) }

    fun removeLine(key: Long) = edit { f -> f.copy(lines = f.lines.filterNot { it.key == key }) }

    // ---- save / confirm -----------------------------------------------

    fun saveDraft() {
        viewModelScope.launch {
            val f = _form.value
            if (f.hasInvalidNumbers()) {
                _errors.value = listOf("Please enter a valid quantity (numbers only, not negative).")
                return@launch
            }
            try {
                val now = System.currentTimeMillis()
                val created = if (f.createdAt == 0L) now else f.createdAt
                repo.saveReport(
                    toEntity(f, confirmed = false, f.confirmedFeedUsed, f.confirmedOpening, f.confirmedClosing, created, now),
                    toLines(f),
                    toExtras(f),
                    newStock = null
                )
                _form.update { it.copy(confirmed = false, createdAt = created, dirty = false) }
                _message.value = "Report saved successfully."
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "saveDraft failed", e)
                _message.value = "Unable to save report. Please try again."
            }
        }
    }

    fun confirm() {
        viewModelScope.launch {
            val f = _form.value
            val stock = repo.getStock()
            // Stock before this report's earlier confirmation (if any) was applied.
            val available = stock.feedBags + f.confirmedFeedUsed
            val problems = Calc.validate(f, available)
            if (problems.isNotEmpty()) {
                _errors.value = problems
                return@launch
            }
            try {
                val now = System.currentTimeMillis()
                val created = if (f.createdAt == 0L) now else f.createdAt
                val used = f.feedUsed
                val closing = available - used
                repo.saveReport(
                    toEntity(f, confirmed = true, used, available, closing, created, now),
                    toLines(f),
                    toExtras(f),
                    newStock = stock.copy(id = 1, feedBags = closing, updatedAt = now)
                )
                _form.update {
                    it.copy(
                        confirmed = true,
                        confirmedFeedUsed = used,
                        confirmedOpening = available,
                        confirmedClosing = closing,
                        createdAt = created,
                        dirty = false
                    )
                }
                _message.value = "Report confirmed. You can now download the PDF."
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "confirm failed", e)
                _message.value = "Unable to confirm report. Please try again."
            }
        }
    }

    private fun toEntity(
        f: ReportForm,
        confirmed: Boolean,
        feedUsed: Double,
        opening: Double,
        closing: Double,
        created: Long,
        updated: Long
    ) = DailyReportEntity(
        date = f.date.toString(),
        trayQty = Calc.parse(f.trayQty),
        trayRate = Calc.parse(f.trayRate),
        labour = Calc.parse(f.labour),
        light = Calc.parse(f.light),
        stoneQty = Calc.parse(f.stoneQty),
        stoneRate = Calc.parse(f.stoneRate),
        eggSell = Calc.parse(f.eggSell),
        confirmed = confirmed,
        confirmedFeedUsed = feedUsed,
        openingFeed = opening,
        closingFeed = closing,
        createdAt = created,
        updatedAt = updated
    )

    private fun toExtras(f: ReportForm): List<ExtraItemEntity> =
        f.extras.mapIndexed { i, e ->
            ExtraItemEntity(
                reportDate = f.date.toString(),
                position = i,
                name = e.name.trim().ifEmpty { "Item ${i + 1}" },
                amount = Calc.parse(e.amount)
            )
        }

    private fun toLines(f: ReportForm): List<FarmLineEntity> =
        f.lines.mapIndexed { i, l ->
            FarmLineEntity(
                reportDate = f.date.toString(),
                position = i,
                name = l.name.trim().ifEmpty { "S.No. ${i + 1}" },
                feedBags = Calc.parse(l.feedBags),
                feedRate = Calc.parse(l.feedRate),
                trays = Calc.parse(l.trays)
            )
        }

    // ---- stock ----------------------------------------------------------

    fun saveStock(feed: String, blankTrays: String, eggTrays: String) {
        if (Calc.isInvalid(feed) || Calc.isInvalid(blankTrays) || Calc.isInvalid(eggTrays)) {
            _message.value = "Please enter a valid quantity."
            return
        }
        viewModelScope.launch {
            try {
                repo.saveStock(
                    FarmStockEntity(
                        id = 1,
                        feedBags = Calc.parse(feed),
                        blankTrays = Calc.parse(blankTrays).toInt(),
                        eggTrays = Calc.parse(eggTrays).toInt(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
                _message.value = "Stock saved successfully."
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "saveStock failed", e)
                _message.value = "Unable to save stock. Please try again."
            }
        }
    }

    // ---- PDF ------------------------------------------------------------

    fun downloadPdf() {
        val f = _form.value
        if (!f.confirmed || f.dirty) {
            _message.value = "Please confirm the report first."
            return
        }
        viewModelScope.launch {
            val currentStock = repo.getStock()
            val uri = withContext(Dispatchers.IO) {
                PdfExporter.create(getApplication(), f, currentStock, _farmName.value)
            }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}
