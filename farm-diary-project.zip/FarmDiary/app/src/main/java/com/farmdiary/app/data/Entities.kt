package com.farmdiary.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** One report per calendar day; the ISO date (yyyy-MM-dd) is the key. */
@Entity(tableName = "daily_report")
data class DailyReportEntity(
    @PrimaryKey val date: String,
    val trayQty: Double,
    val trayRate: Double,
    val labour: Double,
    val light: Double,
    val stoneQty: Double,
    val stoneRate: Double,
    /** Total egg sale amount (kept in the old "eggSell" column). */
    val eggSell: Double,
    @ColumnInfo(defaultValue = "0") val cashReceived: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val onlineReceived: Double = 0.0,
    /** Water used that day, in tanks of 1000 litres. */
    @ColumnInfo(defaultValue = "0") val waterTanks: Double = 0.0,
    /** Blank trays already taken out of stock by the last confirmation of this report. */
    @ColumnInfo(defaultValue = "0") val confirmedTrayUsed: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val openingTrays: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val closingTrays: Double = 0.0,
    /** Egg trays in stock when the report was confirmed; -1 = not recorded. */
    @ColumnInfo(defaultValue = "-1") val closingEggTrays: Int = -1,
    val confirmed: Boolean,
    /** Feed bags already deducted from stock by the last confirmation of this report. */
    val confirmedFeedUsed: Double,
    val openingFeed: Double,
    val closingFeed: Double,
    val createdAt: Long,
    val updatedAt: Long
)

/** One farm / S.No. line. The number of lines is variable. */
@Entity(tableName = "farm_line", indices = [Index("reportDate")])
data class FarmLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val feedBags: Double,
    val feedRate: Double,
    /** Production in trays. Column keeps its old name "eggs" so no table rebuild is needed. */
    @ColumnInfo(name = "eggs") val trays: Double,
    /** Birds that died on this farm that day. */
    @ColumnInfo(defaultValue = "0") val mortality: Int = 0
)

@Entity(tableName = "farm_stock")
data class FarmStockEntity(
    @PrimaryKey val id: Int = 1,
    val feedBags: Double = 0.0,
    val blankTrays: Int = 0,
    val eggTrays: Int = 0,
    val updatedAt: Long = 0
)

/** Extra expenditure item added by the user (e.g. Diesel). Up to 10 per report. */
@Entity(tableName = "extra_item", indices = [Index("reportDate")])
data class ExtraItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val amount: Double
)

/** The farm login for this phone: mobile number + hash of (phone, date of birth). */
@Entity(tableName = "account")
data class AccountEntity(
    @PrimaryKey val id: Int = 1,
    val phone: String,
    val credentialHash: String,
    val createdAt: Long
)

/** One egg sale line (e.g. size "Large": 30 trays at a price per tray). */
@Entity(tableName = "sale_line", indices = [Index("reportDate")])
data class SaleLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val trays: Double,
    /** Price of ONE egg. */
    val rate: Double,
    /** Price cut for one egg of this size (taken off the price of one egg). 0 means "no cut". */
    @ColumnInfo(defaultValue = "0") val revisedRate: Double = 0.0
) {
    val effectiveRate: Double get() = if (revisedRate > 0.0) Math.max(rate - revisedRate, 0.0) else rate
    /** trays x 30 eggs x price of one egg */
    val amount: Double get() = trays * com.farmdiary.app.domain.Calc.EGGS_PER_TRAY * effectiveRate
}

/** Cash / online money received for the egg sale of one day. The sale lines are in sale_line. */
@Entity(tableName = "egg_sale")
data class EggSaleEntity(
    @PrimaryKey val date: String,
    val cashReceived: Double,
    val onlineReceived: Double,
    val updatedAt: Long,
    /** Amount the buyer still owed before this day's sale (can be changed by the user). */
    @ColumnInfo(defaultValue = "0") val previousBalance: Double = 0.0,
    /** Advance money the buyer has paid. It is taken off the amount to receive. */
    @ColumnInfo(defaultValue = "0") val advancePaid: Double = 0.0,
    /** previous + sale - advance - cash - online. Negative means the buyer has paid in advance. */
    @ColumnInfo(defaultValue = "0") val closingBalance: Double = 0.0
)

/** One task in the daily scheduler (e.g. "Feed time" at 7:00 AM). */
@Entity(tableName = "schedule_item")
data class ScheduleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val details: String,
    val hour: Int,
    val minute: Int,
    val reminderOn: Boolean,
    /** DAILY, WEEKLY or MONTHLY */
    @ColumnInfo(defaultValue = "'DAILY'") val kind: String = "DAILY",
    /** For weekly tasks: 1 = Monday ... 7 = Sunday. */
    @ColumnInfo(defaultValue = "1") val dayOfWeek: Int = 1,
    /** For monthly tasks: 1 to 31. */
    @ColumnInfo(defaultValue = "1") val dayOfMonth: Int = 1
)

/**
 * One feed purchase or one payment to the feed supplier.
 * The id is a random text id (not a counter) so two phones can never create the same id.
 * Deleting only marks the row as deleted, so a delete can also travel to the other phone.
 */
@Entity(tableName = "feed_txn", indices = [Index("date")])
data class FeedTxnEntity(
    @PrimaryKey val id: String,
    val date: String,
    /** BUY, ONLINE or CASH */
    val type: String,
    val bags: Double,
    val rate: Double,
    val discount: Double,
    val amount: Double,
    val note: String,
    val deleted: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    /** FEED or MEDICINE: both purchase sections use the same table. */
    @ColumnInfo(defaultValue = "'FEED'") val category: String = "FEED",
    /** Medicine name (empty for feed). */
    @ColumnInfo(defaultValue = "''") val item: String = ""
)

/**
 * One farm's record for one date: age of the flock, feed per bird, bags, production, mortality, breakage,
 * water, medicines (one per line, up to 5) and notes. Up to 5 farms per date.
 * All rows of a date share the same updatedAt, so a whole day can be merged from another phone.
 */
@Entity(tableName = "bird_record", indices = [Index("date")])
data class BirdRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val position: Int,
    val name: String,
    /** Age of the flock in days. */
    val dayNo: Int,
    val feedPerBirdGrams: Double,
    val feedBags: Double,
    val stoneBags: Double,
    /** Production in trays. */
    val production: Double,
    val mortality: Int,
    /** Broken eggs (pieces). */
    val breakage: Int,
    val waterTanks: Double,
    val medicines: String,
    val notes: String,
    val updatedAt: Long,
    /** Live birds in this farm at the start of the day. The next day starts with this minus the mortality. */
    @ColumnInfo(defaultValue = "0") val birdsStart: Int = 0
)
