package com.farmdiary.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** One report per calendar day; the ISO date (yyyy-MM-dd) is the key. */
@Entity(tableName = "daily_report")
data class DailyReportEntity(
    @PrimaryKey val date: String,
    val trayQty: Double,
    val trayRate: Double,
    val labour: Double,
    val light: Double,
    val stoneQty: Double,
    val stoneRate: Double,
    /** Total egg sale amount (kept in the old "eggSell" column). */
    val eggSell: Double,
    @ColumnInfo(defaultValue = "0") val cashReceived: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val onlineReceived: Double = 0.0,
    /** Water used that day, in tanks of 1000 litres. */
    @ColumnInfo(defaultValue = "0") val waterTanks: Double = 0.0,
    /** Blank trays already taken out of stock by the last confirmation of this report. */
    @ColumnInfo(defaultValue = "0") val confirmedTrayUsed: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val openingTrays: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val closingTrays: Double = 0.0,
    val confirmed: Boolean,
    /** Feed bags already deducted from stock by the last confirmation of this report. */
    val confirmedFeedUsed: Double,
    val openingFeed: Double,
    val closingFeed: Double,
    val createdAt: Long,
    val updatedAt: Long
)

/** One farm / S.No. line. The number of lines is variable. */
@Entity(tableName = "farm_line", indices = [Index("reportDate")])
data class FarmLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val feedBags: Double,
    val feedRate: Double,
    /** Production in trays. Column keeps its old name "eggs" so no table rebuild is needed. */
    @ColumnInfo(name = "eggs") val trays: Double,
    /** Birds that died on this farm that day. */
    @ColumnInfo(defaultValue = "0") val mortality: Int = 0
)

@Entity(tableName = "farm_stock")
data class FarmStockEntity(
    @PrimaryKey val id: Int = 1,
    val feedBags: Double = 0.0,
    val blankTrays: Int = 0,
    val eggTrays: Int = 0,
    val updatedAt: Long = 0
)

/** Extra expenditure item added by the user (e.g. Diesel). Up to 10 per report. */
@Entity(tableName = "extra_item", indices = [Index("reportDate")])
data class ExtraItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val amount: Double
)

/** The farm login for this phone: mobile number + hash of (phone, date of birth). */
@Entity(tableName = "account")
data class AccountEntity(
    @PrimaryKey val id: Int = 1,
    val phone: String,
    val credentialHash: String,
    val createdAt: Long
)

/** One egg sale line (e.g. size "Large": 30 trays at a price per tray). */
@Entity(tableName = "sale_line", indices = [Index("reportDate")])
data class SaleLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val trays: Double,
    val rate: Double
)

/** Cash / online money received for the egg sale of one day. The sale lines are in sale_line. */
@Entity(tableName = "egg_sale")
data class EggSaleEntity(
    @PrimaryKey val date: String,
    val cashReceived: Double,
    val onlineReceived: Double,
    val updatedAt: Long
)

/** One task in the daily scheduler (e.g. "Feed time" at 7:00 AM). */
@Entity(tableName = "schedule_item")
data class ScheduleItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val details: String,
    val hour: Int,
    val minute: Int,
    val reminderOn: Boolean
)
