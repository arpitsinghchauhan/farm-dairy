package com.farmdiary.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** One report per calendar day; the ISO date (yyyy-MM-dd) is the key. */
@Entity(tableName = "daily_report")
data class DailyReportEntity(
    @PrimaryKey val date: String,
    val trayQty: Double,
    val trayRate: Double,
    val labour: Double,
    val light: Double,
    val stoneQty: Double,
    val stoneRate: Double,
    val eggSell: Double,
    val confirmed: Boolean,
    /** Feed bags already deducted from stock by the last confirmation of this report. */
    val confirmedFeedUsed: Double,
    val openingFeed: Double,
    val closingFeed: Double,
    val createdAt: Long,
    val updatedAt: Long
)

/** One farm / S.No. line. The number of lines is variable. */
@Entity(tableName = "farm_line", indices = [Index("reportDate")])
data class FarmLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val feedBags: Double,
    val feedRate: Double,
    val eggs: Double
)

@Entity(tableName = "farm_stock")
data class FarmStockEntity(
    @PrimaryKey val id: Int = 1,
    val feedBags: Double = 0.0,
    val blankTrays: Int = 0,
    val eggTrays: Int = 0,
    val updatedAt: Long = 0
)

/** Extra expenditure item added by the user (e.g. Diesel). Up to 10 per report. */
@Entity(tableName = "extra_item", indices = [Index("reportDate")])
data class ExtraItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportDate: String,
    val position: Int,
    val name: String,
    val amount: Double
)

/** The farm login for this phone: mobile number + hash of (phone, date of birth). */
@Entity(tableName = "account")
data class AccountEntity(
    @PrimaryKey val id: Int = 1,
    val phone: String,
    val credentialHash: String,
    val createdAt: Long
)
