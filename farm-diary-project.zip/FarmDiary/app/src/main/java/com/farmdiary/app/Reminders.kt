package com.farmdiary.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.domain.nextTriggerMillis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Daily reminders for the scheduler. Each reminder is one alarm that re-arms itself for the next day. */
object Reminders {
    const val CHANNEL_ID = "farm_reminders"
    private const val EXTRA_ID = "id"
    private const val EXTRA_TITLE = "title"
    private const val EXTRA_DETAILS = "details"
    private const val EXTRA_HOUR = "hour"
    private const val EXTRA_MINUTE = "minute"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(CHANNEL_ID, "Farm reminders", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Feed, water and other farm task reminders"
            nm.createNotificationChannel(channel)
        }
    }

    fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun intentFor(context: Context, id: Long) =
        Intent(context, ReminderReceiver::class.java)

    fun schedule(context: Context, id: Long, title: String, details: String, hour: Int, minute: Int) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val intent = intentFor(context, id).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_DETAILS, details)
            putExtra(EXTRA_HOUR, hour)
            putExtra(EXTRA_MINUTE, minute)
        }
        val pi = PendingIntent.getBroadcast(
            context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = nextTriggerMillis(hour, minute)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                // Exact alarms not allowed: still fires, but the phone may delay it by a few minutes.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(context: Context, id: Long) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            context, id.toInt(), intentFor(context, id),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) ?: return
        am.cancel(pi)
        pi.cancel()
    }

    internal fun show(context: Context, id: Long, title: String, details: String) {
        if (!canNotify(context)) return
        ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(details.ifBlank { "Time for this task" })
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        context.getSystemService(NotificationManager::class.java)?.notify(id.toInt(), n)
    }

    internal fun readExtras(i: Intent): Array<Any> = arrayOf<Any>(
        i.getLongExtra(EXTRA_ID, -1L),
        i.getStringExtra(EXTRA_TITLE) ?: "Farm task",
        i.getStringExtra(EXTRA_DETAILS) ?: "",
        i.getIntExtra(EXTRA_HOUR, 7),
        i.getIntExtra(EXTRA_MINUTE, 0)
    )
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val x = Reminders.readExtras(intent)
        val id = x[0] as Long
        if (id < 0) return
        val title = x[1] as String
        val details = x[2] as String
        val hour = x[3] as Int
        val minute = x[4] as Int
        Reminders.show(context, id, title, details)
        // Arm the same reminder again for tomorrow.
        Reminders.schedule(context, id, title, details, hour, minute)
    }
}

/** After a phone restart all alarms are gone, so set the saved reminders again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(app).dao().getSchedule()
                    .filter { it.reminderOn }
                    .forEach { Reminders.schedule(app, it.id, it.title, it.details, it.hour, it.minute) }
            } catch (e: Exception) {
                android.util.Log.e("FarmDiary", "reschedule after boot failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}
