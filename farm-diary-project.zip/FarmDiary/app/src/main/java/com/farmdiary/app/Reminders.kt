package com.farmdiary.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.provider.Settings
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.domain.ScheduleKind
import com.farmdiary.app.domain.nextReminderMillis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Daily reminders for the scheduler. Each reminder is one alarm that re-arms itself for the next day. */
object Reminders {
    // A channel keeps the sound it was first created with, so a new id is needed to add the sound.
    const val CHANNEL_ID = "farm_reminders_v2"
    private const val OLD_CHANNEL_ID = "farm_reminders"
    private const val TEST_ID = 2_000_000_000L
    private const val EXTRA_ID = "id"
    private const val EXTRA_TITLE = "title"
    private const val EXTRA_DETAILS = "details"
    private const val EXTRA_HOUR = "hour"
    private const val EXTRA_MINUTE = "minute"
    private const val EXTRA_KIND = "kind"
    private const val EXTRA_DOW = "dow"
    private const val EXTRA_DOM = "dom"

    fun soundUri(context: Context): Uri =
        Uri.parse("android.resource://${context.packageName}/${R.raw.reminder_chime}")

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.deleteNotificationChannel(OLD_CHANNEL_ID)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(CHANNEL_ID, "Farm reminders", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Feed, water and other farm task reminders (rings with a bell sound)"
            // Alarm usage so the bell is heard even when the phone is on silent or vibrate.
            channel.setSound(
                soundUri(context),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            channel.enableVibration(true)
            channel.vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 600)
            channel.enableLights(true)
            nm.createNotificationChannel(channel)
        }
    }

    /** Opens the phone's own settings for the reminder channel (to turn the sound on if it was switched off). */
    fun openChannelSettings(context: Context) {
        val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .putExtra(Settings.EXTRA_CHANNEL_ID, CHANNEL_ID)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            AppLog.e("cannot open channel settings", e)
        }
    }

    /** Shows a reminder right now, so the sound can be checked. */
    fun showTest(context: Context) =
        show(context, TEST_ID, "Test reminder", "If you hear the bell, your farm reminders are working.")

    fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun intentFor(context: Context, id: Long) =
        Intent(context, ReminderReceiver::class.java)

    fun schedule(
        context: Context, id: Long, title: String, details: String, hour: Int, minute: Int,
        kind: String = ScheduleKind.DAILY, dayOfWeek: Int = 1, dayOfMonth: Int = 1
    ) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val intent = intentFor(context, id).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_DETAILS, details)
            putExtra(EXTRA_HOUR, hour)
            putExtra(EXTRA_MINUTE, minute)
            putExtra(EXTRA_KIND, kind)
            putExtra(EXTRA_DOW, dayOfWeek)
            putExtra(EXTRA_DOM, dayOfMonth)
        }
        val pi = PendingIntent.getBroadcast(
            context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = nextReminderMillis(kind, hour, minute, dayOfWeek, dayOfMonth)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                // Exact alarms not allowed: still fires, but the phone may delay it by a few minutes.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(context: Context, id: Long) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            context, id.toInt(), intentFor(context, id),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) ?: return
        am.cancel(pi)
        pi.cancel()
    }

    internal fun show(context: Context, id: Long, title: String, details: String) {
        if (!canNotify(context)) return
        ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(details.ifBlank { "Time for this task" })
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        context.getSystemService(NotificationManager::class.java)?.notify(id.toInt(), n)
    }

    internal fun readExtras(i: Intent): Array<Any> = arrayOf<Any>(
        i.getLongExtra(EXTRA_ID, -1L),
        i.getStringExtra(EXTRA_TITLE) ?: "Farm task",
        i.getStringExtra(EXTRA_DETAILS) ?: "",
        i.getIntExtra(EXTRA_HOUR, 7),
        i.getIntExtra(EXTRA_MINUTE, 0),
        i.getStringExtra(EXTRA_KIND) ?: ScheduleKind.DAILY,
        i.getIntExtra(EXTRA_DOW, 1),
        i.getIntExtra(EXTRA_DOM, 1)
    )
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val x = Reminders.readExtras(intent)
        val id = x[0] as Long
        if (id < 0) return
        val title = x[1] as String
        val details = x[2] as String
        val hour = x[3] as Int
        val minute = x[4] as Int
        val kind = x[5] as String
        val dow = x[6] as Int
        val dom = x[7] as Int
        val when_ = "${ScheduleKind.leadText(kind)} at ${com.farmdiary.app.domain.formatTime(hour, minute)}"
        Reminders.show(context, id, title, if (details.isBlank()) when_ else "$when_. $details")
        // Arm the same reminder again for its next time.
        Reminders.schedule(context, id, title, details, hour, minute, kind, dow, dom)
    }
}

/** After a phone restart all alarms are gone, so set the saved reminders again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = context.applicationContext
        StockAlerts.scheduleDaily(app)
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(app).dao().getSchedule()
                    .filter { it.reminderOn }
                    .forEach { Reminders.schedule(app, it.id, it.title, it.details, it.hour, it.minute, it.kind, it.dayOfWeek, it.dayOfMonth) }
            } catch (e: Exception) {
                AppLog.e("reschedule after boot failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}
