package com.farmdiary.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {
    @Query("SELECT * FROM daily_report WHERE date = :date")
    suspend fun getReport(date: String): DailyReportEntity?

    @Query("SELECT * FROM farm_line WHERE reportDate = :date ORDER BY position")
    suspend fun getLines(date: String): List<FarmLineEntity>

    @Query("SELECT * FROM extra_item WHERE reportDate = :date ORDER BY position")
    suspend fun getExtras(date: String): List<ExtraItemEntity>

    @Insert
    suspend fun insertExtras(items: List<ExtraItemEntity>)

    @Query("DELETE FROM extra_item WHERE reportDate = :date")
    suspend fun deleteExtras(date: String)

    @Query("SELECT * FROM sale_line WHERE reportDate = :date ORDER BY position")
    suspend fun getSales(date: String): List<SaleLineEntity>

    @Insert
    suspend fun insertSales(items: List<SaleLineEntity>)

    @Query("DELETE FROM sale_line WHERE reportDate = :date")
    suspend fun deleteSales(date: String)

    @Query("SELECT * FROM daily_report WHERE date BETWEEN :start AND :end ORDER BY date")
    suspend fun getReportsBetween(start: String, end: String): List<DailyReportEntity>

    @Query("SELECT * FROM farm_line WHERE reportDate BETWEEN :start AND :end")
    suspend fun getLinesBetween(start: String, end: String): List<FarmLineEntity>

    @Query("SELECT * FROM extra_item WHERE reportDate BETWEEN :start AND :end")
    suspend fun getExtrasBetween(start: String, end: String): List<ExtraItemEntity>

    @Query("SELECT * FROM sale_line WHERE reportDate BETWEEN :start AND :end")
    suspend fun getSalesBetween(start: String, end: String): List<SaleLineEntity>

    @Query("SELECT * FROM egg_sale WHERE date = :date")
    suspend fun getEggSale(date: String): EggSaleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEggSale(sale: EggSaleEntity)

    @Query("SELECT * FROM egg_sale WHERE date BETWEEN :start AND :end")
    suspend fun getEggSalesBetween(start: String, end: String): List<EggSaleEntity>

    @Query("SELECT * FROM schedule_item ORDER BY hour, minute, id")
    suspend fun getSchedule(): List<ScheduleItemEntity>

    @Query("SELECT * FROM schedule_item ORDER BY hour, minute, id")
    fun observeSchedule(): Flow<List<ScheduleItemEntity>>

    @Insert
    suspend fun insertSchedule(items: List<ScheduleItemEntity>): List<Long>

    @Query("DELETE FROM schedule_item")
    suspend fun clearSchedule()

    @Query("SELECT * FROM account WHERE id = 1")
    suspend fun getAccount(): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccount(account: AccountEntity)

    @Query("SELECT * FROM daily_report ORDER BY date DESC")
    fun observeReports(): Flow<List<DailyReportEntity>>

    @Query("SELECT * FROM farm_stock WHERE id = 1")
    suspend fun getStock(): FarmStockEntity?

    @Query("SELECT * FROM farm_stock WHERE id = 1")
    fun observeStock(): Flow<FarmStockEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReport(report: DailyReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStock(stock: FarmStockEntity)

    @Insert
    suspend fun insertLines(lines: List<FarmLineEntity>)

    @Query("DELETE FROM farm_line WHERE reportDate = :date")
    suspend fun deleteLines(date: String)
}
