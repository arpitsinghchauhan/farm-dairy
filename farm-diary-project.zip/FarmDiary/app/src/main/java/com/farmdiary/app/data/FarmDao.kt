package com.farmdiary.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {
    @Query("SELECT * FROM daily_report WHERE date = :date")
    suspend fun getReport(date: String): DailyReportEntity?

    @Query("SELECT * FROM daily_report WHERE date < :date AND confirmed = 1 ORDER BY date DESC LIMIT 1")
    suspend fun getLatestConfirmedReportBefore(date: String): DailyReportEntity?

    @Query("SELECT * FROM daily_report WHERE date < :date ORDER BY date DESC LIMIT 1")
    suspend fun getLatestReportBefore(date: String): DailyReportEntity?

    @Query("SELECT * FROM farm_line WHERE reportDate = :date ORDER BY position")
    suspend fun getLines(date: String): List<FarmLineEntity>

    @Query("SELECT * FROM extra_item WHERE reportDate = :date ORDER BY position")
    suspend fun getExtras(date: String): List<ExtraItemEntity>

    @Insert
    suspend fun insertExtras(items: List<ExtraItemEntity>)

    @Query("DELETE FROM extra_item WHERE reportDate = :date")
    suspend fun deleteExtras(date: String)

    @Query("SELECT * FROM sale_line WHERE reportDate = :date ORDER BY position")
    suspend fun getSales(date: String): List<SaleLineEntity>

    @Insert
    suspend fun insertSales(items: List<SaleLineEntity>)

    @Query("DELETE FROM sale_line WHERE reportDate = :date")
    suspend fun deleteSales(date: String)

    @Query("SELECT * FROM daily_report WHERE date BETWEEN :start AND :end ORDER BY date")
    suspend fun getReportsBetween(start: String, end: String): List<DailyReportEntity>

    @Query("SELECT * FROM farm_line WHERE reportDate BETWEEN :start AND :end")
    suspend fun getLinesBetween(start: String, end: String): List<FarmLineEntity>

    @Query("SELECT * FROM extra_item WHERE reportDate BETWEEN :start AND :end")
    suspend fun getExtrasBetween(start: String, end: String): List<ExtraItemEntity>

    @Query("SELECT * FROM sale_line WHERE reportDate BETWEEN :start AND :end")
    suspend fun getSalesBetween(start: String, end: String): List<SaleLineEntity>

    @Query("SELECT * FROM egg_sale WHERE date = :date")
    suspend fun getEggSale(date: String): EggSaleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEggSale(sale: EggSaleEntity)

    @Query("SELECT * FROM egg_sale WHERE date < :date ORDER BY date DESC LIMIT 1")
    suspend fun getLatestEggSaleBefore(date: String): EggSaleEntity?

    @Query("SELECT * FROM egg_sale WHERE date BETWEEN :start AND :end")
    suspend fun getEggSalesBetween(start: String, end: String): List<EggSaleEntity>

    @Query("SELECT * FROM schedule_item ORDER BY hour, minute, id")
    suspend fun getSchedule(): List<ScheduleItemEntity>

    @Query("SELECT * FROM schedule_item ORDER BY hour, minute, id")
    fun observeSchedule(): Flow<List<ScheduleItemEntity>>

    @Insert
    suspend fun insertSchedule(items: List<ScheduleItemEntity>): List<Long>

    @Query("DELETE FROM schedule_item")
    suspend fun clearSchedule()

    @Query("SELECT * FROM feed_txn WHERE deleted = 0 ORDER BY date, createdAt")
    fun observeFeedTxns(): Flow<List<FeedTxnEntity>>

    @Query("SELECT * FROM feed_txn WHERE id = :id")
    suspend fun getFeedTxn(id: String): FeedTxnEntity?

    /** Includes deleted rows, so deletes can be shared with another phone. */
    @Query("SELECT * FROM feed_txn")
    suspend fun getAllFeedTxns(): List<FeedTxnEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFeedTxn(txn: FeedTxnEntity)

    @Query("SELECT * FROM daily_report ORDER BY date")
    suspend fun getAllReports(): List<DailyReportEntity>

    @Query("SELECT * FROM farm_line ORDER BY reportDate, position")
    suspend fun getAllLines(): List<FarmLineEntity>

    @Query("SELECT * FROM extra_item ORDER BY reportDate, position")
    suspend fun getAllExtras(): List<ExtraItemEntity>

    @Query("SELECT * FROM egg_sale ORDER BY date")
    suspend fun getAllEggSales(): List<EggSaleEntity>

    @Query("SELECT * FROM sale_line ORDER BY reportDate, position")
    suspend fun getAllSaleLines(): List<SaleLineEntity>

    @Query("SELECT * FROM bird_record ORDER BY date DESC, position")
    fun observeBirdRecords(): Flow<List<BirdRecordEntity>>

    @Query("SELECT * FROM bird_record WHERE date = :date ORDER BY position")
    suspend fun getBirdRecords(date: String): List<BirdRecordEntity>

    @Query("SELECT MAX(date) FROM bird_record WHERE date < :date")
    suspend fun getLatestBirdDateBefore(date: String): String?

    @Query("SELECT * FROM bird_record WHERE date BETWEEN :start AND :end ORDER BY date, position")
    suspend fun getBirdRecordsBetween(start: String, end: String): List<BirdRecordEntity>

    @Query("SELECT MAX(reportDate) FROM farm_line WHERE reportDate < :date AND dayNo > 0")
    suspend fun getLatestAgedLineDateBefore(date: String): String?

    @Query("SELECT * FROM bird_record ORDER BY date, position")
    suspend fun getAllBirdRecords(): List<BirdRecordEntity>

    @Query("DELETE FROM bird_record WHERE date = :date")
    suspend fun deleteBirdRecords(date: String)

    @Insert
    suspend fun insertBirdRecords(items: List<BirdRecordEntity>)

    @Query("SELECT * FROM account WHERE id = 1")
    suspend fun getAccount(): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccount(account: AccountEntity)

    @Query("SELECT * FROM daily_report ORDER BY date DESC")
    fun observeReports(): Flow<List<DailyReportEntity>>

    @Query("SELECT * FROM farm_stock WHERE id = 1")
    suspend fun getStock(): FarmStockEntity?

    @Query("SELECT * FROM farm_stock WHERE id = 1")
    fun observeStock(): Flow<FarmStockEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReport(report: DailyReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStock(stock: FarmStockEntity)

    @Insert
    suspend fun insertLines(lines: List<FarmLineEntity>)

    @Query("DELETE FROM farm_line WHERE reportDate = :date")
    suspend fun deleteLines(date: String)

    @Query("SELECT * FROM employee WHERE deleted = 0 ORDER BY createdAt")
    fun observeEmployees(): Flow<List<EmployeeEntity>>

    @Query("SELECT COUNT(*) FROM employee WHERE deleted = 0")
    suspend fun countEmployees(): Int

    @Query("SELECT * FROM employee WHERE id = :id")
    suspend fun getEmployee(id: String): EmployeeEntity?

    @Query("SELECT * FROM employee")
    suspend fun getAllEmployees(): List<EmployeeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmployee(e: EmployeeEntity)

    @Query("SELECT * FROM employee_payment WHERE deleted = 0 ORDER BY date DESC, createdAt DESC")
    fun observeEmployeePayments(): Flow<List<EmployeePaymentEntity>>

    @Query("SELECT * FROM employee_payment WHERE id = :id")
    suspend fun getEmployeePayment(id: String): EmployeePaymentEntity?

    @Query("SELECT * FROM employee_payment")
    suspend fun getAllEmployeePayments(): List<EmployeePaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmployeePayment(p: EmployeePaymentEntity)

    @Query("SELECT * FROM stock_day ORDER BY date DESC")
    fun observeStockDays(): Flow<List<StockDayEntity>>

    @Query("SELECT * FROM stock_day")
    suspend fun getAllStockDays(): List<StockDayEntity>

    @Query("SELECT * FROM stock_day WHERE date = :date")
    suspend fun getStockDay(date: String): StockDayEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStockDay(s: StockDayEntity)

    @Query("SELECT * FROM vendor ORDER BY createdAt")
    fun observeVendors(): Flow<List<VendorEntity>>

    @Query("SELECT * FROM vendor")
    suspend fun getAllVendors(): List<VendorEntity>

    @Query("SELECT * FROM vendor WHERE id = :id")
    suspend fun getVendor(id: String): VendorEntity?

    @Query("SELECT * FROM vendor WHERE category = :category AND deleted = 0")
    suspend fun getLiveVendors(category: String): List<VendorEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVendor(v: VendorEntity)

    @Query("SELECT * FROM special_discount ORDER BY date DESC, createdAt DESC")
    fun observeSpecialDiscounts(): Flow<List<SpecialDiscountEntity>>

    @Query("SELECT * FROM special_discount")
    suspend fun getAllSpecialDiscounts(): List<SpecialDiscountEntity>

    @Query("SELECT * FROM special_discount WHERE id = :id")
    suspend fun getSpecialDiscount(id: String): SpecialDiscountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSpecialDiscount(d: SpecialDiscountEntity)
}
