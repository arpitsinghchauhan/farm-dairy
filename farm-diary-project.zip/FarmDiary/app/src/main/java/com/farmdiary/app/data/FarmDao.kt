package com.farmdiary.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmDao {
    @Query("SELECT * FROM daily_report WHERE date = :date")
    suspend fun getReport(date: String): DailyReportEntity?

    @Query("SELECT * FROM farm_line WHERE reportDate = :date ORDER BY position")
    suspend fun getLines(date: String): List<FarmLineEntity>

    @Query("SELECT * FROM daily_report ORDER BY date DESC")
    fun observeReports(): Flow<List<DailyReportEntity>>

    @Query("SELECT * FROM farm_stock WHERE id = 1")
    suspend fun getStock(): FarmStockEntity?

    @Query("SELECT * FROM farm_stock WHERE id = 1")
    fun observeStock(): Flow<FarmStockEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReport(report: DailyReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStock(stock: FarmStockEntity)

    @Insert
    suspend fun insertLines(lines: List<FarmLineEntity>)

    @Query("DELETE FROM farm_line WHERE reportDate = :date")
    suspend fun deleteLines(date: String)
}
