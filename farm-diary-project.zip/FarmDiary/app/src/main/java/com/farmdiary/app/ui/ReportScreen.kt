package com.farmdiary.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.MAX_EXTRA_ITEMS
import com.farmdiary.app.domain.MAX_SALE_LINES

@Composable
fun ReportScreen(vm: FarmViewModel, onEggSell: () -> Unit, onBack: () -> Unit) {
    val date by vm.date.collectAsState()
    val form by vm.form.collectAsState()
    val stock by vm.stock.collectAsState()
    val errors by vm.errors.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val farmName by vm.farmName.collectAsState()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var askDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }
    LaunchedEffect(pdfUri) {
        pdfUri?.let { uri ->
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            } catch (e: ActivityNotFoundException) {
                // No PDF viewer installed; the file is still in Downloads.
            }
            vm.clearOpenPdf()
        }
    }

    val leave: () -> Unit = {
        if (form.dirty) {
            askDiscard = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = leave)

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved changes in this report.") },
            confirmButton = {
                TextButton(onClick = {
                    askDiscard = false
                    vm.reload()
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = {
                TextButton(onClick = { askDiscard = false }) { Text("Keep editing") }
            }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Daily Report", leave) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        if (form.date != date) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (farmName.isNotBlank()) {
                Text(farmName, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(form.date.format(displayDateFormat), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Sun)
                Text(
                    when {
                        form.confirmed && !form.dirty -> "Confirmed"
                        form.dirty -> "Not saved yet"
                        else -> "Not confirmed yet"
                    },
                    fontSize = 16.sp
                )
            }

            // ---------------- Expenditure ----------------
            SectionCard("Expenditure", "\uD83D\uDCB8") {
                form.lines.forEach { line ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = line.name,
                                onValueChange = { v -> vm.editLine(line.key) { it.copy(name = v) } },
                                label = { Text("Farm name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            if (form.lines.size > 1) {
                                IconButton(onClick = { vm.removeLine(line.key) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove ${line.name}")
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumField(
                                "Bags used", line.feedBags,
                                { v -> vm.editLine(line.key) { it.copy(feedBags = v) } },
                                Modifier.weight(1f)
                            )
                            NumField(
                                "Rate", line.feedRate,
                                { v -> vm.editLine(line.key) { it.copy(feedRate = v) } },
                                Modifier.weight(1f)
                            )
                        }
                        CalcRow("Amount", Calc.money(line.feedAmount))
                    }
                }
                OutlinedButton(onClick = { vm.addLine() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text("  Add farm / S.No.")
                }

                Text("Tray", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Trays used", form.trayQty, { v -> vm.edit { it.copy(trayQty = v) } }, Modifier.weight(1f), integer = true)
                    NumField("Rate", form.trayRate, { v -> vm.edit { it.copy(trayRate = v) } }, Modifier.weight(1f))
                }
                CalcRow("= bundles (1 bundle = ${Calc.TRAYS_PER_BUNDLE} trays)", "${Calc.fmt(Calc.bundles(form.trayUsed))} bundles")
                CalcRow("Tray amount", Calc.money(form.trayAmount))

                NumField("Labour (amount)", form.labour, { v -> vm.edit { it.copy(labour = v) } }, Modifier.fillMaxWidth())
                NumField("Light (amount)", form.light, { v -> vm.edit { it.copy(light = v) } }, Modifier.fillMaxWidth())

                form.extras.forEachIndexed { i, item ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = item.name,
                            onValueChange = { v -> vm.editExtra(item.key) { it.copy(name = v) } },
                            label = { Text("Item ${i + 1} (e.g. Diesel)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        NumField(
                            "Amount", item.amount,
                            { v -> vm.editExtra(item.key) { it.copy(amount = v) } },
                            Modifier.weight(0.8f)
                        )
                        IconButton(onClick = { vm.removeExtra(item.key) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove item ${i + 1}")
                        }
                    }
                }
                if (form.extras.size < MAX_EXTRA_ITEMS) {
                    OutlinedButton(onClick = { vm.addExtra() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add item (${form.extras.size}/$MAX_EXTRA_ITEMS)")
                    }
                } else {
                    Text("Maximum $MAX_EXTRA_ITEMS extra items added.", fontSize = 16.sp)
                }

                Text("Stone", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Quantity", form.stoneQty, { v -> vm.edit { it.copy(stoneQty = v) } }, Modifier.weight(1f))
                    NumField("Rate", form.stoneRate, { v -> vm.edit { it.copy(stoneRate = v) } }, Modifier.weight(1f))
                }
                CalcRow("Stone amount", Calc.money(form.stoneAmount))

                CalcRow("Total Expenditure", Calc.money(form.totalExpenditure), bold = true)
            }

            // ---------------- Income / Production ----------------
            SectionCard("Income (Egg Sale)", "💰") {
                if (form.totalIncome <= 0.0) {
                    CalcRow("Egg sale", "NIL (no egg sold)", bold = true)
                } else {
                    form.sales.forEachIndexed { i, sale ->
                        CalcRow(
                            "${sale.name.ifBlank { "Sale ${i + 1}" }}: ${sale.trays.ifBlank { "0" }} trays x ${sale.rate.ifBlank { "0" }}",
                            Calc.money(sale.amount)
                        )
                    }
                    CalcRow("Total sale (${Calc.fmt(form.totalTraysSold)} trays)", Calc.money(form.totalIncome), bold = true)
                    CalcRow("Cash received", Calc.money(Calc.parse(form.cashReceived)))
                    CalcRow("Online received", Calc.money(Calc.parse(form.onlineReceived)))
                    CalcRow(
                        "Balance to receive", Calc.money(form.balance),
                        bold = true, error = form.balance < -1e-9
                    )
                }
                Text(
                    "This comes from the Egg Sell screen for this date.",
                    fontSize = 16.sp,
                    color = TextLo
                )
                OutlinedButton(onClick = onEggSell, modifier = Modifier.fillMaxWidth()) {
                    Text("✏️  Open Egg Sell", fontSize = 18.sp)
                }
            }

            SectionCard("Production (trays)", "\uD83E\uDD5A") {
                form.lines.forEachIndexed { i, line ->
                    NumField(
                        "${line.name.ifBlank { "S.No. ${i + 1}" }} trays", line.trays,
                        { v -> vm.editLine(line.key) { it.copy(trays = v) } },
                        Modifier.fillMaxWidth()
                    )
                }
                CalcRow("Total trays", "${Calc.fmt(form.totalTrays)} trays", bold = true)
                CalcRow("= eggs (1 tray = ${Calc.EGGS_PER_TRAY} eggs)", "${Calc.fmt(form.totalEggs)} eggs")
            }

            SectionCard("Mortality (birds died)", "\uD83D\uDC14") {
                form.lines.forEachIndexed { i, line ->
                    NumField(
                        "${line.name.ifBlank { "S.No. ${i + 1}" }} birds died", line.mortality,
                        { v -> vm.editLine(line.key) { it.copy(mortality = v) } },
                        Modifier.fillMaxWidth(),
                        integer = true
                    )
                }
                CalcRow("Total birds died", "${Calc.fmt(form.totalMortality)} birds", bold = true)
            }

            SectionCard("Water Used", "\uD83D\uDCA7") {
                NumField(
                    "Tanks used (1 tank = ${Calc.LITERS_PER_TANK} litres)", form.waterTanks,
                    { v -> vm.edit { it.copy(waterTanks = v) } },
                    Modifier.fillMaxWidth()
                )
                CalcRow("= litres", "${Calc.fmt(form.waterLiters)} L", bold = true)
            }

            // ---------------- Feed stock check ----------------
            val available = stock.feedBags + form.confirmedFeedUsed
            val closing = available - form.feedUsed
            SectionCard("Feed Stock", "\uD83C\uDF3E") {
                CalcRow("Opening stock", "${Calc.fmt(available)} bags")
                CalcRow("Total used", "${Calc.fmt(form.feedUsed)} bags")
                CalcRow("Closing stock", "${Calc.fmt(closing)} bags", bold = true, error = closing < -1e-9)
                if (closing < -1e-9) {
                    Text(
                        "You used more feed than you have in stock.",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            val availTrays = stock.blankTrays + Math.round(form.confirmedTrayUsed).toInt()
            val closingTrays = availTrays - form.trayUsed
            SectionCard("Tray Stock", "\uD83E\uDDFA") {
                CalcRow("Opening stock", "${Calc.fmt(Calc.bundles(availTrays.toDouble()))} bundles")
                CalcRow("Used today", "${Calc.fmt(Calc.bundles(form.trayUsed))} bundles (${Calc.fmt(form.trayUsed)} trays)")
                CalcRow(
                    "Closing stock", "${Calc.fmt(Calc.bundles(closingTrays))} bundles",
                    bold = true, error = closingTrays < -1e-9
                )
                if (closingTrays < -1e-9) {
                    Text(
                        "You used more trays than you have in stock.",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "\u26A0\uFE0F") {
                    errors.forEach {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            OutlinedButton(
                onClick = { vm.saveDraft() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Save Report", fontSize = 20.sp) }
            GradientButton(
                text = "\u2705  Confirm Report",
                onClick = { vm.confirm() },
                modifier = Modifier.fillMaxWidth()
            )
            GradientButton(
                text = "\uD83D\uDCC4  Download PDF",
                onClick = { vm.downloadPdf() },
                enabled = form.confirmed && !form.dirty,
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
            if (!(form.confirmed && !form.dirty)) {
                Text("Press Confirm Report first, then you can download the PDF.", fontSize = 16.sp)
            }
        }
    }
}
