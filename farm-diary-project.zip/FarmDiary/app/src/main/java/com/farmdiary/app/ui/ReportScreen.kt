package com.farmdiary.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.MAX_EXTRA_ITEMS
import com.farmdiary.app.domain.MAX_SALE_LINES

@Composable
fun ReportScreen(vm: FarmViewModel, onEggSell: () -> Unit, onBack: () -> Unit) {
    val date by vm.date.collectAsState()
    val form by vm.form.collectAsState()
    val stock by vm.stock.collectAsState()
    val errors by vm.errors.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val farmName by vm.farmName.collectAsState()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var askDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }
    LaunchedEffect(pdfUri) {
        pdfUri?.let { uri ->
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            } catch (e: ActivityNotFoundException) {
                // No PDF viewer installed; the file is still in Downloads.
            }
            vm.clearOpenPdf()
        }
    }

    val leave: () -> Unit = {
        if (form.dirty) {
            askDiscard = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = leave)

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved changes in this report.") },
            confirmButton = {
                TextButton(onClick = {
                    askDiscard = false
                    vm.reload()
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = {
                TextButton(onClick = { askDiscard = false }) { Text("Keep editing") }
            }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Daily Report", leave) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        if (form.date != date) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (farmName.isNotBlank()) {
                Text(farmName, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            DatePill(form.date) { picked ->
                if (form.dirty) vm.notify("Please save the report before changing the date.") else vm.setDate(picked)
            }
            Text(
                when {
                    form.confirmed && !form.dirty -> "Confirmed"
                    form.dirty -> "Not saved yet"
                    else -> "Not confirmed yet"
                },
                fontSize = 16.sp
            )

            // ---------------- Top: egg rate and the age of each farm's birds ----------------
            SectionCard("Today", "\uD83D\uDCC5") {
                NumField("Egg rate today", form.eggRate, { v -> vm.edit { it.copy(eggRate = v) } }, Modifier.fillMaxWidth(0.5f))
            }

            // ---------------- Expenditure ----------------
            SectionCard("Expenditure", "\uD83D\uDCB8") {
                form.lines.forEach { line ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = line.name,
                                onValueChange = { v -> vm.editLine(line.key) { it.copy(name = v) } },
                                label = { Text("Farm name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumField(
                                "Bags used", line.feedBags,
                                { v -> vm.editLine(line.key) { it.copy(feedBags = v) } },
                                Modifier.weight(1f)
                            )
                            NumField(
                                "Rate", line.feedRate,
                                { v -> vm.editLine(line.key) { it.copy(feedRate = v) } },
                                Modifier.weight(1f)
                            )
                        }
                        CalcRow("Amount", Calc.money(line.feedAmount))
                    }
                }
                Text("Tray", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Trays used", form.trayQty, { v -> vm.edit { it.copy(trayQty = v) } }, Modifier.weight(1f), integer = true)
                    NumField("Rate", form.trayRate, { v -> vm.edit { it.copy(trayRate = v) } }, Modifier.weight(1f))
                }
                                CalcRow("Tray amount", Calc.money(form.trayAmount))

                NumField("Labour (amount)", form.labour, { v -> vm.edit { it.copy(labour = v) } }, Modifier.fillMaxWidth())
                NumField("Light (amount)", form.light, { v -> vm.edit { it.copy(light = v) } }, Modifier.fillMaxWidth())

                form.extras.forEachIndexed { i, item ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = item.name,
                            onValueChange = { v -> vm.editExtra(item.key) { it.copy(name = v) } },
                            label = { Text("Item ${i + 1}") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        NumField(
                            "Amount", item.amount,
                            { v -> vm.editExtra(item.key) { it.copy(amount = v) } },
                            Modifier.weight(0.8f)
                        )
                        IconButton(onClick = { vm.removeExtra(item.key) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove item ${i + 1}")
                        }
                    }
                }
                if (form.extras.size < MAX_EXTRA_ITEMS) {
                    OutlinedButton(onClick = { vm.addExtra() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add item (${form.extras.size}/$MAX_EXTRA_ITEMS)")
                    }
                } else {
                    Text("Maximum $MAX_EXTRA_ITEMS extra items added.", fontSize = 16.sp)
                }

                Text("Stone", fontWeight = FontWeight.SemiBold)
                if (form.stoneFromRecords) {
                    CalcRow("Quantity (total of Farm Records)", Calc.fmt(Calc.parse(form.stoneQty)))
                    NumField("Rate", form.stoneRate, { v -> vm.edit { it.copy(stoneRate = v) } }, Modifier.fillMaxWidth())
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("Quantity", form.stoneQty, { v -> vm.edit { it.copy(stoneQty = v) } }, Modifier.weight(1f))
                        NumField("Rate", form.stoneRate, { v -> vm.edit { it.copy(stoneRate = v) } }, Modifier.weight(1f))
                    }
                }
                CalcRow("Stone amount", Calc.money(form.stoneAmount))

                CalcRow("Total Expenditure", Calc.money(form.totalExpenditure), bold = true)
            }

            // ---------------- Income / Production ----------------
            SectionCard("Income", "💰") {
                if (form.totalIncome <= 0.0) {
                    CalcRow("Egg sale", "NIL (no egg sold)", bold = true)
                } else {
                    form.sales.forEachIndexed { i, sale ->
                        val label = "${sale.name.ifBlank { "Sale ${i + 1}" }}: ${sale.trays.ifBlank { "0" }} trays x ${Calc.EGGS_PER_TRAY} eggs x ${Calc.rateText(sale.effectiveRate)}"
                        CalcRow(label, Calc.money(sale.amount))
                    }
                    CalcRow("Total sale (${Calc.fmt(form.totalTraysSold)} trays)", Calc.money(form.totalIncome), bold = true)
                }
                if (form.totalIncome > 0.0 || form.hasSaleMoney) {
                    if (form.previous > 0.0) CalcRow("Previous balance", Calc.money(form.previous))
                    if (form.balance >= -1e-9) {
                        CalcRow("Balance to receive", Calc.money(form.balance), bold = true)
                    }
                }
                Text("Other income", fontWeight = FontWeight.SemiBold)
                form.otherIncome.forEachIndexed { i, item ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = item.name,
                            onValueChange = { v -> vm.editOtherIncome(item.key) { it.copy(name = v) } },
                            label = { Text("e.g. Litter, empty bags") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        NumField(
                            "Amount", item.amount,
                            { v -> vm.editOtherIncome(item.key) { it.copy(amount = v) } },
                            Modifier.weight(0.8f)
                        )
                        IconButton(onClick = { vm.removeOtherIncome(item.key) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove other income ${i + 1}")
                        }
                    }
                }
                if (form.otherIncome.size < MAX_EXTRA_ITEMS) {
                    OutlinedButton(onClick = { vm.addOtherIncome() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add other income")
                    }
                }
                if (form.otherIncome.isNotEmpty()) {
                    CalcRow("Other income total", Calc.money(form.otherIncomeTotal))
                    CalcRow("Total income", Calc.money(form.allIncome), bold = true)
                }
                OutlinedButton(onClick = onEggSell, modifier = Modifier.fillMaxWidth()) {
                    Text("✏️  Show details", fontSize = 18.sp)
                }
            }

            SectionCard("Production", "\uD83E\uDD5A") {
                form.lines.forEachIndexed { i, line ->
                    NumField(
                        "${line.name.ifBlank { "S.No. ${i + 1}" }} trays", line.trays,
                        { v -> vm.editLine(line.key) { it.copy(trays = v) } },
                        Modifier.fillMaxWidth()
                    )
                }
                CalcRow("Total", "${Calc.fmt(form.totalTrays)} trays", bold = true)
            }

            SectionCard("Mortality", "\uD83D\uDC14") {
                form.lines.forEachIndexed { i, line ->
                    NumField(
                        "${line.name.ifBlank { "S.No. ${i + 1}" }} birds died", line.mortality,
                        { v -> vm.editLine(line.key) { it.copy(mortality = v) } },
                        Modifier.fillMaxWidth(),
                        integer = true
                    )
                }
                CalcRow("Total", "${Calc.fmt(form.totalMortality)} birds", bold = true)
            }

            // ---------------- Stock left (only the number that is left) ----------------
            val manualDays by vm.stockDays.collectAsState()
            // A hand-written stock record only applies to an earlier date. Today's stock is the live stock, less what this report uses.
            val manualRow = manualDays.firstOrNull { it.date == form.date.toString() }
                ?.takeIf { form.date.isBefore(java.time.LocalDate.now()) }
            val manual = if (form.stockApplied) null else manualRow
            val feedLeft = if (manual != null && manual.feedLeft >= 0) manual.feedLeft else form.feedBase(stock.feedBags) - form.feedUsed
            val trayLeft = if (manual != null && manual.trayLeft >= 0) manual.trayLeft else form.trayBase(stock.blankTrays) - Math.round(form.trayUsed).toInt()
            val eggStock = if (manual != null && manual.eggTrays >= 0) manual.eggTrays
                else form.eggLeft(stock.eggTrays) ?: manualRow?.eggTrays?.takeIf { it >= 0 }
            SectionCard("Stock Left", "\uD83D\uDCE6") {
                CalcRow("Feed", "${Calc.fmt(feedLeft)} bags", bold = true, error = feedLeft < -1e-9)
                CalcRow("Tray bundles", "${Calc.fmt(Calc.bundles(trayLeft.toDouble()))} bundles", bold = true, error = trayLeft < 0)
                if (eggStock != null) CalcRow("Egg trays", "$eggStock trays", bold = true)
                if (feedLeft < -1e-9) {
                    Text(
                        "You used more feed than you have in stock.",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                if (trayLeft < 0) {
                    Text(
                        "You used more trays than you have in stock.",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix", "\u26A0\uFE0F") {
                    errors.forEach {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            OutlinedButton(
                onClick = { vm.saveDraft() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Save Report", fontSize = 20.sp) }
            GradientButton(
                text = "\u2705  Confirm Report",
                onClick = { vm.confirm() },
                modifier = Modifier.fillMaxWidth()
            )
            GradientButton(
                text = "\uD83D\uDCC4  Download PDF",
                onClick = { vm.downloadPdf() },
                enabled = form.confirmed && !form.dirty,
                brush = MintBrush,
                modifier = Modifier.fillMaxWidth()
            )
            if (!(form.confirmed && !form.dirty)) {
                Text("Press Confirm Report first, then you can download the PDF.", fontSize = 16.sp)
            }
        }
    }
}
