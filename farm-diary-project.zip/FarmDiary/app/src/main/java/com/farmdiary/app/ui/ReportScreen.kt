package com.farmdiary.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.farmdiary.app.FarmViewModel
import com.farmdiary.app.domain.Calc
import com.farmdiary.app.domain.MAX_EXTRA_ITEMS

@Composable
fun ReportScreen(vm: FarmViewModel, onBack: () -> Unit) {
    val date by vm.date.collectAsState()
    val form by vm.form.collectAsState()
    val stock by vm.stock.collectAsState()
    val errors by vm.errors.collectAsState()
    val message by vm.message.collectAsState()
    val pdfUri by vm.openPdf.collectAsState()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var askDiscard by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }
    LaunchedEffect(pdfUri) {
        pdfUri?.let { uri ->
            try {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            } catch (e: ActivityNotFoundException) {
                // No PDF viewer installed; the file is still in Downloads.
            }
            vm.clearOpenPdf()
        }
    }

    val leave: () -> Unit = {
        if (form.dirty) {
            askDiscard = true
        } else {
            onBack()
        }
    }
    BackHandler(onBack = leave)

    if (askDiscard) {
        AlertDialog(
            onDismissRequest = { askDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved changes in this report.") },
            confirmButton = {
                TextButton(onClick = {
                    askDiscard = false
                    vm.reload()
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = {
                TextButton(onClick = { askDiscard = false }) { Text("Keep editing") }
            }
        )
    }

    Scaffold(
        topBar = { FarmTopBar("Daily Report", leave) },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        if (form.date != date) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(form.date.format(displayDateFormat), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = FarmRed)
                Text(
                    when {
                        form.confirmed && !form.dirty -> "Confirmed"
                        form.dirty -> "Not saved yet"
                        else -> "Not confirmed yet"
                    },
                    fontSize = 16.sp
                )
            }

            // ---------------- Expenditure ----------------
            SectionCard("Expenditure") {
                form.lines.forEach { line ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = line.name,
                                onValueChange = { v -> vm.editLine(line.key) { it.copy(name = v) } },
                                label = { Text("Farm name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            if (form.lines.size > 1) {
                                IconButton(onClick = { vm.removeLine(line.key) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove ${line.name}")
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumField(
                                "Bags used", line.feedBags,
                                { v -> vm.editLine(line.key) { it.copy(feedBags = v) } },
                                Modifier.weight(1f)
                            )
                            NumField(
                                "Rate", line.feedRate,
                                { v -> vm.editLine(line.key) { it.copy(feedRate = v) } },
                                Modifier.weight(1f)
                            )
                        }
                        CalcRow("Amount", Calc.money(line.feedAmount))
                    }
                }
                OutlinedButton(onClick = { vm.addLine() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Text("  Add farm / S.No.")
                }

                Text("Tray", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Quantity", form.trayQty, { v -> vm.edit { it.copy(trayQty = v) } }, Modifier.weight(1f))
                    NumField("Rate", form.trayRate, { v -> vm.edit { it.copy(trayRate = v) } }, Modifier.weight(1f))
                }
                CalcRow("Tray amount", Calc.money(form.trayAmount))

                NumField("Labour (amount)", form.labour, { v -> vm.edit { it.copy(labour = v) } }, Modifier.fillMaxWidth())
                NumField("Light (amount)", form.light, { v -> vm.edit { it.copy(light = v) } }, Modifier.fillMaxWidth())

                form.extras.forEachIndexed { i, item ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = item.name,
                            onValueChange = { v -> vm.editExtra(item.key) { it.copy(name = v) } },
                            label = { Text("Item ${i + 1} (e.g. Diesel)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        NumField(
                            "Amount", item.amount,
                            { v -> vm.editExtra(item.key) { it.copy(amount = v) } },
                            Modifier.weight(0.8f)
                        )
                        IconButton(onClick = { vm.removeExtra(item.key) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove item ${i + 1}")
                        }
                    }
                }
                if (form.extras.size < MAX_EXTRA_ITEMS) {
                    OutlinedButton(onClick = { vm.addExtra() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("  Add item (${form.extras.size}/$MAX_EXTRA_ITEMS)")
                    }
                } else {
                    Text("Maximum $MAX_EXTRA_ITEMS extra items added.", fontSize = 16.sp)
                }

                Text("Stone", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Quantity", form.stoneQty, { v -> vm.edit { it.copy(stoneQty = v) } }, Modifier.weight(1f))
                    NumField("Rate", form.stoneRate, { v -> vm.edit { it.copy(stoneRate = v) } }, Modifier.weight(1f))
                }
                CalcRow("Stone amount", Calc.money(form.stoneAmount))

                CalcRow("Total Expenditure", Calc.money(form.totalExpenditure), bold = true)
            }

            // ---------------- Income / Production ----------------
            SectionCard("Income") {
                NumField("Egg Sell (amount, 0 if NIL)", form.eggSell, { v -> vm.edit { it.copy(eggSell = v) } }, Modifier.fillMaxWidth())
                CalcRow("Total Income", Calc.money(form.totalIncome), bold = true)
            }

            SectionCard("Production (eggs)") {
                form.lines.forEachIndexed { i, line ->
                    NumField(
                        "${line.name.ifBlank { "S.No. ${i + 1}" }} eggs", line.eggs,
                        { v -> vm.editLine(line.key) { it.copy(eggs = v) } },
                        Modifier.fillMaxWidth(),
                        integer = true
                    )
                }
                CalcRow("Total eggs", "${Calc.fmt(form.totalEggs)} eggs", bold = true)
                CalcRow("= trays (1 tray = ${Calc.EGGS_PER_TRAY})", Calc.fmt(Calc.eggsToTrays(form.totalEggs)))
            }

            // ---------------- Feed stock check ----------------
            val available = stock.feedBags + form.confirmedFeedUsed
            val closing = available - form.feedUsed
            SectionCard("Feed Stock") {
                CalcRow("Opening stock", "${Calc.fmt(available)} bags")
                CalcRow("Total used", "${Calc.fmt(form.feedUsed)} bags")
                CalcRow("Closing stock", "${Calc.fmt(closing)} bags", bold = true, error = closing < -1e-9)
                if (closing < -1e-9) {
                    Text(
                        "You used more feed than you have in stock.",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (errors.isNotEmpty()) {
                SectionCard("Please fix") {
                    errors.forEach {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            OutlinedButton(
                onClick = { vm.saveDraft() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Save Report", fontSize = 20.sp) }
            Button(
                onClick = { vm.confirm() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Confirm Report", fontSize = 20.sp) }
            Button(
                onClick = { vm.downloadPdf() },
                enabled = form.confirmed && !form.dirty,
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Download PDF", fontSize = 20.sp) }
            if (!(form.confirmed && !form.dirty)) {
                Text("Press Confirm Report first, then you can download the PDF.", fontSize = 16.sp)
            }
        }
    }
}
