package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.domain.FeedMakerCalc
import com.farmdiary.app.domain.MixItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** Feed Maker: the feed composition (kept on this phone), the bags used for each farm, and the result. */
class FeedMakerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _items = MutableStateFlow(
        FeedMakerCalc.decode(prefs.getString("mix_items", "") ?: "").ifEmpty { listOf(MixItem()) }
    )
    val items: StateFlow<List<MixItem>> = _items.asStateFlow()

    private val _share = MutableStateFlow(prefs.getString("mix_share", "100") ?: "100")
    /** Percent of the feed made on the farm; the rest is bought full feed. */
    val share: StateFlow<String> = _share.asStateFlow()

    private val _round = MutableStateFlow(prefs.getBoolean("mix_round", false))
    val round: StateFlow<Boolean> = _round.asStateFlow()

    private val _bags = MutableStateFlow(
        (prefs.getString("mix_bags", "") ?: "").split("\n").filter { it.contains("\t") }
            .associate { it.substringBefore("\t") to it.substringAfter("\t") }
    )
    /** Bags used, by farm name. */
    val bags: StateFlow<Map<String, String>> = _bags.asStateFlow()

    val farms: StateFlow<List<String>> = repo.observeBirdRecords()
        .map { rows ->
            val latest = rows.maxByOrNull { it.date }?.date
            val names = if (latest == null) emptyList() else rows.filter { it.date == latest }.sortedBy { it.position }.map { it.name.trim() }.filter { it.isNotEmpty() }
            names.ifEmpty { (1..prefs.getInt("farm_count", 2).coerceIn(1, 5)).map { "S.No. $it" } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("S.No. 1", "S.No. 2"))

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()
    fun clearMessage() { _message.value = null }
    fun clearOpenPdf() { _openPdf.value = null }

    private fun saveItems() { prefs.edit().putString("mix_items", FeedMakerCalc.encode(_items.value)).apply() }

    fun editItem(index: Int, item: MixItem) {
        _items.value = _items.value.mapIndexed { i, x -> if (i == index) item else x }
        saveItems()
    }

    fun addItem() {
        if (_items.value.size >= FeedMakerCalc.MAX_ITEMS) return
        _items.value = _items.value + MixItem()
    }

    fun removeItem(index: Int) {
        _items.value = _items.value.filterIndexed { i, _ -> i != index }.ifEmpty { listOf(MixItem()) }
        saveItems()
    }

    fun setShare(v: String) {
        if (v.length > 6 || !v.all { it.isDigit() || it == '.' }) return
        _share.value = v
        prefs.edit().putString("mix_share", v).apply()
    }

    fun setRound(v: Boolean) {
        _round.value = v
        prefs.edit().putBoolean("mix_round", v).apply()
    }

    fun setBags(farm: String, v: String) {
        _bags.value = _bags.value + (farm to v)
        prefs.edit().putString("mix_bags", _bags.value.entries.joinToString("\n") { it.key.replace('\n', ' ').replace('\t', ' ') + "\t" + it.value }).apply()
    }

    fun downloadPdf(perFarm: List<Pair<String, com.farmdiary.app.domain.MixResult>>) {
        val farmName = prefs.getString("farm_name", "") ?: ""
        val share = com.farmdiary.app.domain.Calc.parse(_share.value).coerceIn(0.0, 100.0)
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) { PdfExporter.createFeedMaker(getApplication(), perFarm, share, _round.value, farmName, LocalDate.now()) }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}
