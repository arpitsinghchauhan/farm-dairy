package com.farmdiary.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.farmdiary.app.data.AppDatabase
import com.farmdiary.app.data.FarmRepository
import com.farmdiary.app.domain.FeedMakerCalc
import com.farmdiary.app.domain.FeedMakerStore
import com.farmdiary.app.domain.MixItem
import com.farmdiary.app.domain.MixRecord
import com.farmdiary.app.domain.MixTemplate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** Feed Maker: the feed composition (kept on this phone), the bags used for each farm, and the result. */
class FeedMakerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FarmRepository(AppDatabase.get(app))
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _items = MutableStateFlow(
        FeedMakerCalc.decode(prefs.getString("mix_items", "") ?: "").ifEmpty { listOf(MixItem()) }
    )
    val items: StateFlow<List<MixItem>> = _items.asStateFlow()

    private val _share = MutableStateFlow(prefs.getString("mix_share", "100") ?: "100")
    /** Percent of the feed made on the farm; the rest is bought full feed. */
    val share: StateFlow<String> = _share.asStateFlow()

    private val _fullPrice = MutableStateFlow(prefs.getString("mix_full_price", "") ?: "")
    /** Price of one 50 kg bag of bought full feed. */
    val fullPrice: StateFlow<String> = _fullPrice.asStateFlow()

    fun setFullPrice(v: String) {
        if (v.length > 8 || !v.all { it.isDigit() || it == '.' }) return
        _fullPrice.value = v
        prefs.edit().putString("mix_full_price", v).apply()
    }

    private val _templates = MutableStateFlow(FeedMakerStore.decodeTemplates(prefs.getString("mix_templates", "") ?: ""))
    /** Compositions saved with a title (gear icon). */
    val templates: StateFlow<List<MixTemplate>> = _templates.asStateFlow()

    private val _records = MutableStateFlow(FeedMakerStore.decodeRecords(prefs.getString("mix_records", "") ?: ""))
    /** Every saved daily record, in the order saved. */
    val records: StateFlow<List<MixRecord>> = _records.asStateFlow()

    private val _recordDate = MutableStateFlow(LocalDate.now())
    /** The date a record is saved under. */
    val recordDate: StateFlow<LocalDate> = _recordDate.asStateFlow()
    fun setRecordDate(d: LocalDate) { _recordDate.value = d }

    private val _templateName = MutableStateFlow(prefs.getString("mix_template_name", "") ?: "")
    /** Title of the template last picked or saved. */
    val templateName: StateFlow<String> = _templateName.asStateFlow()

    private fun saveTemplates() { prefs.edit().putString("mix_templates", FeedMakerStore.encodeTemplates(_templates.value)).apply() }
    private fun saveRecords() { prefs.edit().putString("mix_records", FeedMakerStore.encodeRecords(_records.value)).apply() }

    /** Saves the composition on screen with a title. A template with the same title is replaced. Returns an error text or null. */
    fun saveTemplate(title: String): String? {
        if (!FeedMakerStore.validTitle(title)) return "Write a name (up to ${FeedMakerStore.MAX_TITLE} letters)."
        val name = title.trim().replace('\n', ' ').replace('\t', ' ')
        val problems = FeedMakerCalc.validate(_items.value)
        if (problems.isNotEmpty()) return problems.first()
        val t = MixTemplate(name, _items.value.filter { it.name.isNotBlank() || it.percent.isNotBlank() }, _share.value, _round.value, _fullPrice.value)
        val others = _templates.value.filter { !it.title.equals(name, ignoreCase = true) }
        if (others.size >= FeedMakerStore.MAX_TEMPLATES) return "You can keep up to ${FeedMakerStore.MAX_TEMPLATES} templates. Remove one first."
        _templates.value = others + t
        saveTemplates()
        _templateName.value = name
        prefs.edit().putString("mix_template_name", name).apply()
        _message.value = "Saved as \"$name\". Pick it again from the gear icon."
        return null
    }

    /** Puts a saved template on screen. */
    fun useTemplate(t: MixTemplate) {
        _items.value = t.items.ifEmpty { listOf(MixItem()) }
        saveItems()
        setShare(t.share)
        setRound(t.round)
        setFullPrice(t.fullPrice)
        _templateName.value = t.title
        prefs.edit().putString("mix_template_name", t.title).apply()
        _message.value = "\"${t.title}\" is ready."
    }

    fun removeTemplate(title: String) {
        _templates.value = _templates.value.filter { it.title != title }
        saveTemplates()
    }

    /** Suggested name for the next record of the chosen date. */
    fun suggestRecordTitle(): String = FeedMakerStore.nextTitle(_records.value, _recordDate.value.toString())

    /** Saves what is on screen as a record of the chosen date (a day can have several). Returns an error text or null. */
    fun saveRecord(title: String, farmBags: List<Pair<String, String>>): String? {
        if (!FeedMakerStore.validTitle(title)) return "Write a name (up to ${FeedMakerStore.MAX_TITLE} letters)."
        val problems = FeedMakerCalc.validate(_items.value)
        if (problems.isNotEmpty()) return problems.first()
        val r = MixRecord(
            id = java.util.UUID.randomUUID().toString(), date = _recordDate.value.toString(),
            title = title.trim().replace('\n', ' ').replace('\t', ' '),
            items = _items.value.filter { it.name.isNotBlank() || it.percent.isNotBlank() },
            share = _share.value, round = _round.value, fullPrice = _fullPrice.value,
            bags = farmBags.filter { com.farmdiary.app.domain.Calc.parse(it.second) > 0.0 }
        )
        if (r.bags.isEmpty()) return "Write the bags used for at least one farm."
        if (_records.value.size >= FeedMakerStore.MAX_RECORDS) return "Too many records are saved. Remove old ones first."
        _records.value = _records.value + r
        saveRecords()
        _message.value = "Record \"${r.title}\" saved for ${r.date}."
        return null
    }

    fun removeRecord(id: String) {
        _records.value = _records.value.filter { it.id != id }
        saveRecords()
    }

    /** One PDF with every saved record, day by day. */
    fun downloadRecordsPdf() {
        val farmName = prefs.getString("farm_name", "") ?: ""
        val list = _records.value
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) { PdfExporter.createFeedMakerRecords(getApplication(), list, farmName, LocalDate.now()) }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }

    private val _round = MutableStateFlow(prefs.getBoolean("mix_round", false))
    val round: StateFlow<Boolean> = _round.asStateFlow()

    private val _bags = MutableStateFlow(
        (prefs.getString("mix_bags", "") ?: "").split("\n").filter { it.contains("\t") }
            .associate { it.substringBefore("\t") to it.substringAfter("\t") }
    )
    /** Bags used, by farm name. */
    val bags: StateFlow<Map<String, String>> = _bags.asStateFlow()

    val farms: StateFlow<List<String>> = repo.observeBirdRecords()
        .map { rows ->
            val latest = rows.maxByOrNull { it.date }?.date
            val names = if (latest == null) emptyList() else rows.filter { it.date == latest }.sortedBy { it.position }.map { it.name.trim() }.filter { it.isNotEmpty() }
            names.ifEmpty { (1..prefs.getInt("farm_count", 2).coerceIn(1, 5)).map { "S.No. $it" } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("S.No. 1", "S.No. 2"))

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _openPdf = MutableStateFlow<Uri?>(null)
    val openPdf: StateFlow<Uri?> = _openPdf.asStateFlow()
    fun clearMessage() { _message.value = null }
    fun clearOpenPdf() { _openPdf.value = null }

    private fun saveItems() { prefs.edit().putString("mix_items", FeedMakerCalc.encode(_items.value)).apply() }

    fun editItem(index: Int, item: MixItem) {
        _items.value = _items.value.mapIndexed { i, x -> if (i == index) item else x }
        saveItems()
    }

    fun addItem() {
        if (_items.value.size >= FeedMakerCalc.MAX_ITEMS) return
        _items.value = _items.value + MixItem()
    }

    fun removeItem(index: Int) {
        _items.value = _items.value.filterIndexed { i, _ -> i != index }.ifEmpty { listOf(MixItem()) }
        saveItems()
    }

    fun setShare(v: String) {
        if (v.length > 6 || !v.all { it.isDigit() || it == '.' }) return
        _share.value = v
        prefs.edit().putString("mix_share", v).apply()
    }

    fun setRound(v: Boolean) {
        _round.value = v
        prefs.edit().putBoolean("mix_round", v).apply()
    }

    fun setBags(farm: String, v: String) {
        _bags.value = _bags.value + (farm to v)
        prefs.edit().putString("mix_bags", _bags.value.entries.joinToString("\n") { it.key.replace('\n', ' ').replace('\t', ' ') + "\t" + it.value }).apply()
    }

    fun downloadPdf(perFarm: List<Pair<String, com.farmdiary.app.domain.MixResult>>) {
        val farmName = prefs.getString("farm_name", "") ?: ""
        val share = com.farmdiary.app.domain.Calc.parse(_share.value).coerceIn(0.0, 100.0)
        viewModelScope.launch {
            val uri = withContext(Dispatchers.IO) { PdfExporter.createFeedMaker(getApplication(), perFarm, share, _round.value, farmName, LocalDate.now()) }
            if (uri == null) {
                _message.value = "Unable to create PDF. Please try again."
            } else {
                _message.value = "PDF saved in your Downloads folder."
                _openPdf.value = uri
            }
        }
    }
}
